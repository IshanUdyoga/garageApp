import * as React from 'react';
import { Modal,StatusBar, Text, View, StyleSheet,Dimensions,TouchableOpacity,Image,AsyncStorage,ScrollView,FlatList,ImageBackground,TextInput,Keyboard,LayoutAnimation,UIManager } from 'react-native';


import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons';
import * as firebase from 'react-native-firebase';
import stringsoflanguages from '../../lng/stringsoflanguages';

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width

let deviceSH = Dimensions.get('screen').height;
let bottomNavBarH = deviceSH - deviceHeight;

 export default class MsgBox extends React.Component {

  constructor(props) {

    super(props);
    this.keyboardPop = this.keyboardPop.bind(this);
        this.state={
            text:'',
            cmtModal:false,
            data:[],
            refreshing:false,
            SELID:'',
            CUSID:'',
            ORID:'',
            viewHeight:null,
            headerImagePath:'',

            msgKey:'',
            isEnterNick:false,
            nickname:''
                }


            }


    componentDidMount () {


    }

  componentWillMount(){

  }



  keyboardPop = (event) => {
   // this.scroller.scrollTo({y: 0})
  };


getTime(){
  time = new Date();

  hour = time.getHours(); 
 
    if(hour <= 11)
    {
 
      TimeType = 'am';
 
    }
    else{
 
      TimeType = 'pm';
 
    }
 
 
    if( hour > 12 )
    {
      hour = hour - 12;
    }
 
    if( hour == 0 )
    {
        hour = 12;
    } 
 
 
    minutes = time.getMinutes();
 
    if(minutes < 10)
    {
      minutes = '0' + minutes.toString();
    }
 
 
    seconds = time.getSeconds();
 
    if(seconds < 10)
    {
      seconds = '0' + seconds.toString();
    }

    fullTime = hour.toString() + ':' + minutes.toString() + ' ' + TimeType.toString();


    return (fullTime)
}

onChatPress(){
  AsyncStorage.setItem('msgNickName',this.state.nickname)
  this.setState({isEnterNick:false,})
  
}

  mainFunc=(msgKey)=>{
    this.setState({msgKey:msgKey,refreshing:true,cmtModal:true})
    
    AsyncStorage.getItem("msgNickName").then((value) => {
      if(value !== null){
        this.fetchData(msgKey)
        this.setState({nickname:value})
      }else{
          this.fetchData(msgKey)
          this.setState({isEnterNick:true})
      }

    })
    .then(res => {

    });

  }



  fetchData (uid){

      this.dataVal= firebase.database().ref('messages/'+uid+"/msgs");
      this.dataVal.on('value', snapshot => {

        const arr = [];
  
        snapshot.forEach((doc) => {
          arr.push({
            key:doc.key,
            name:doc.toJSON().userName,
            comment:doc.toJSON().msgData,
            time:doc.toJSON().time,
            type:doc.toJSON().type,
          })
      
        })
 
          this.setState({data:arr,refreshing:false})
            
        
      });
  }




  sendMessage(){
var currentTime =this.getTime()
const {msgKey,text,nickname} = this.state

if(text === ""){
  alert('Empty Message !')
}else{
    firebase.database().ref('messages/'+msgKey+"/msgs").push({
    userName:nickname,
    msgData:text,
    time:currentTime,
    type:'user'
  }).then((data)=>{
       
    this.setState({text:''})
    //Keyboard.dismiss()
    

  }).catch((error)=>{
    alert(error)

  })

}
}




close(){
    this.setState({ cmtModal: false,data:[],nickname:'' })
    this.dataVal.off();
}



emptymsgFun(){
  if(this.state.refreshing){
    return(<View style={styles.emptyListPAD}>
            <Text style={styles.emptyTXT}>{stringsoflanguages.home.loading}</Text>
            <Icon name="ios-refresh" style={styles.EmtyIco} />
            </View>
            )
  }else{

      return(<View style={styles.emptyListPAD}>
            <Text style={styles.emptyTXT}>No Messages..</Text>
            <Icon name="ios-alert" style={styles.EmtyIco} />
            </View>)
  }
}

find_dimesions(layout){
  const {x, y, width, height} = layout;
 
  this.scrollView.scrollToEnd({animated: true});
}




  render() {
    return (
        <Modal visible={this.state.cmtModal} animationType={'slide'} >
         
        <View style={styles.container} >


          <View style={styles.cmntPad} onLayout={(event) => { this.find_dimesions(event.nativeEvent.layout) }}>
                <FlatList
              
                ListEmptyComponent={this.emptymsgFun()}
                ref={ref => this.scrollView = ref}
                onContentSizeChange={(contentWidth, contentHeight)=>{        
                  this.scrollView.scrollToEnd({animated: true});
              }}

        style={styles.root}
        data={this.state.data}
        extraData={this.state}
        keyExtractor={(item)=>{
          return item.key;
        }}
        renderItem={(item) => {
          const Notification = item.item;
          return(
            <View style={[styles.Flatcontainer,{justifyContent: Notification.type === 'user' ? 'flex-end' : 'flex-start'}]}>
              <View style={Notification.type === 'user' ? styles.contentUser : styles.contentAdmin}>
                <View style={styles.contentHeader}>
                  <Text  style={styles.name}>{Notification.name}</Text>
                  <Text style={styles.time}>
                  {Notification.time}
                  </Text>
                </View>
                <Text rkType='primary3 mediumLine'>{Notification.comment}</Text>
              </View>
            </View>
          );
        }}/>

                </View> 
          



                <View style={styles.commentInputBox} >
            
            <View style={styles.cmntPad1} >
               

                     <View style={styles.cmntRow1}>
                         <TextInput
                                style={styles.textInputSS}
                                onChangeText={(text) => this.setState({text})}
                                value={this.state.text}
                                placeholder="Add message ... "
                                placeholderTextColor="#cecece"
                                
                            />
                        </View>

                    <TouchableOpacity  style={styles.cmntRow2} onPress={()=> this.sendMessage()}>
                            <Icon name="ios-send" style={styles.iconSend}/>        
                        </TouchableOpacity>

            </View>

          </View>


              {this.state.isEnterNick ? 
                <View style={styles.enterNickCon} >
                
                <View style={styles.enterNickConSub}>
                                  <TextInput
                                    placeholder="Enter Nick Name"
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    value={this.state.nickname}
                                    maxLength={7}
                                    autoCorrect={false}
                                    autoCapitalize="none"
                                    onChangeText={nickname => this.setState({ nickname })}
                                />
                                <TouchableOpacity style={styles.chatBtn} onPress={()=> this.onChatPress()}>
                                <Text style={styles.btnTxt}>Chat</Text></TouchableOpacity>
                  </View>
                </View>
               : <View/>}



            <View style={styles.closeHeading} >

                    <View style={styles.HeadRaw2}>
                            <Text  style={styles.UserName}>Hi {this.state.nickname} how can I help ?</Text>
                    </View>


                    <View style={styles.HeadRaw3}>
                            <TouchableOpacity style={styles.ttBtn} onPress ={() =>this.close()}>
                            <Icon name="ios-close" style={styles.iconClose}/>
                                </TouchableOpacity>
                    </View>
            

            </View>



          



           


            

        </View>
      
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
      flex:1,
    justifyContent: 'center',
    alignItems:'center',
    
  },
  imagePad:{
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: hp('4%'),
  },
 


pad2:{
    position:'absolute',
  
},

fontTT:{
    color:'#4dcbf9',
    fontSize: hp('3%'),
},

ttBtn:{
   
    justifyContent: 'center',
    alignItems: 'center',
},

iconClose:{
    color:'#fff',
    fontSize:hp('10%'),
},

closeHeading:{
    position:'absolute',
    top:0,
    width:'100%',
    height:hp('12%'),
    backgroundColor: '#2cba5b',
    flexDirection: 'row',
    //justifyContent: 'flex-end',
    alignItems: 'center',
    

},


HeadRaw1:{
height:'100%',
width:'20%',
justifyContent: 'center',
alignItems:'center'
},

HeadRaw2:{
    height:'100%',
    width:'80%',
    justifyContent: 'center',
    paddingLeft:wp('5%')
    },

    HeadRaw3:{
        justifyContent: 'center',
        alignItems: 'center',
        height:'100%',
        width:'20%'
        },

        profilePad:{
            height:hp('8%'),
            width:hp('8%'),
            borderRadius:hp('16%'),
            backgroundColor: '#ddd',
            overflow: 'hidden',
        },

commentInputBox:{
    position:'absolute',
    bottom:0
},

cmntPad1:{
    height:hp('10%'),
    width:wp('100%'),
    backgroundColor:'#fff',
    flexDirection:'row',
    borderTopWidth: 1,
    borderColor:'#ddd'
},

cmntRow1:{
    height:'100%',
    width:wp('80%'),
    justifyContent: 'center',
    alignItems:'flex-end',
},
cmntRow2:{
    height:'100%',
    width:wp('20%'),
    justifyContent: 'center',
    alignItems:'center',
},
textInputSS:{
    height: '70%',
    width:'95%',
    borderRadius:hp('5%'),
    paddingHorizontal: wp('3%'),
     borderColor: '#ddd',
      borderWidth: 1,
      backgroundColor:'#f7f7f7'
},

iconSend:{
    color:'#35daff',
    fontSize:hp('7%'),
    transform: [{ rotate: '45deg'}]

},

UserName:{
    color:'#fff',
    fontSize:hp('2.7%'),

},
UserOrderId:{
    color:'#fff',
    fontSize:hp('1.8%'),

},



cmntPad:{

width:'100%',
height:'100%',
paddingTop:hp('15%'),
paddingBottom:hp('10%')
},




root: {
    backgroundColor: "#ffffff",
    // paddingTop:hp('15%'),
    // paddingBottom: hp('20%'),
  },
  Flatcontainer: {
    paddingHorizontal: wp('4%'),
    paddingVertical: hp('2%'),
    flexDirection: 'row',
  },
  contentAdmin: {
    borderTopLeftRadius: hp('2%'),
    borderTopRightRadius: hp('2%'),
    borderBottomRightRadius: hp('2%'),
    padding: hp('2%'),
    backgroundColor: '#ffdbc1',
    maxWidth: wp('50%'),
  },
  contentUser: {
    borderTopLeftRadius: hp('2%'),
    borderTopRightRadius: hp('2%'),
    borderBottomLeftRadius: hp('2%'),
    padding: hp('2%'),
    backgroundColor: '#b5dcff',
    maxWidth: wp('50%'),
  },
  contentHeader: {
    flexDirection: 'row',
    //justifyContent: 'space-between',
    marginBottom: hp('0.1%')
  },
  separator: {
    height: 1,
    backgroundColor: "#CCCCCC"
  },
  image:{
    width:hp('6.7%'),
    height:hp('6.7%'),
    borderRadius:hp('12.14'),
    marginLeft:wp('5%')
  },
  time:{
    fontSize:hp('1.7%'),
    color:"#808080",
    paddingLeft:wp('3%')
  },
  name:{
    fontSize:hp('2.4%'),
    fontWeight:"bold",
  },

  thumbImage:{
      height:'100%',
      width:'100%',
  },


  emptyListPAD:{
    height:deviceHeight/1.7,
    width:wp('100%'),
    justifyContent:'center',
    alignItems:'center',
  },

  emptyTXT:{
    fontWeight:'bold',
    fontSize:hp('2.5%'),
    color:'#898989'
  },

  EmtyIco:{
    marginTop: hp('1%'),
    fontSize:hp('5%'),
    color:'#898989'
  },

  enterNickCon:{
    position:'absolute',
    marginTop:hp('12%'),
    height:'100%',
    width:'100%',
  },

  enterNickConSub:{
    height:'100%',
    width:'100%',
    backgroundColor: '#6df299',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },

  input:{
    height: hp('8%'),
    width:'90%',
    paddingLeft: wp('5%'),
    fontSize:hp('3.3%'),
    fontFamily: 'seg_light',
    color:'#383838',
    backgroundColor:'#fff',
    borderRadius:hp('1%')
    
  },

  chatBtn:{
    height: hp('8%'),
    borderRadius:hp('8%'),
    width:'90%',
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#4c4c4c',
    marginTop:hp('2%'),
    marginBottom:hp('2%')
  },

  btnTxt:{
    color:'#fff',
    fontSize:hp('2%')
  }

});