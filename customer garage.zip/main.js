import React from 'react';
import { AppRegistry, StyleSheet, Text, View,AsyncStorage } from 'react-native';
import { createStackNavigator } from 'react-navigation';
import { TabNavigator } from 'react-navigation'
import {
  StackNavigator, 
 } from 'react-navigation'; 


import Loading from'./src/screen/login/Loading';
//import Home from'./src/screen/home';
import ResetPass from'./src/screen/login/restpass';
import Confirmcode from'./src/screen/login/confirmcode';
import Setnewpw from './src/screen/login/setnewpw'
import Login from'./src/screen/login/login';
import Register from'./src/screen/login/register';
import FooterTab from'./src/screen/main/footerTab';

import Sort_filter from'./src/screen/main/other_screens/sort_filter';
import Product_list from'./src/screen/main/other_screens/product_list';



const Main = StackNavigator({

  Loading: { screen: Loading },
  Login: { screen: Login },
  Register: { screen: Register },
  FooterTab:{screen:FooterTab},

  ResetPass:{screen:ResetPass},
  Confirmcode:{screen:Confirmcode},
  Setnewpw:{screen:Setnewpw},

  Product_list:{screen:Product_list},
  Sort_filter:{screen:Sort_filter},
 
 // Home: { screen: Home },


},
{
  headerMode: 'none',
},)

export default Main;

