import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions,
  FlatList,
  Image,
  TouchableOpacity,
  LayoutAnimation,
  UIManager,
  BackHandler,
  ActivityIndicator,
  AsyncStorage
} from 'react-native';
import { withNavigationFocus } from 'react-navigation';
import {CheckBox} from 'native-base'
import Header from '../../main/header'
import Product_View from '../../main/other_screens/product_view'
import Product_compare from '../../main/other_screens/product_compare'
import Cat_filter_modal from '../../main/other_screens/cat_filter_modal'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Drawer from '../drawer'
import Icon from 'react-native-ionicons';
import sort from 'fast-sort';
import * as firebase from 'react-native-firebase';

UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);
//age,gender_value,smk_value,paym_tm,sum_insured,annual_premium
 class Product_list extends Component {

    constructor(props) {
        super(props);
        this.drawer = React.createRef();
        this.prod_view = React.createRef();
        this.prod_comp = React.createRef();

        var ageVal=0;
        var gender_valueVal=1;
        var smk_valueVal=1;
        var benefit_valueVAl=1;
        var deductible_valueVAl =1;
        var paym_tmVal = '10';
        var sum_insuredVal = null;
        var annual_premiumVal = null;

        var county_val = null;
        var childAge_val =null;
        var chile_no_val = null;
        var retireAge_val =null

        if (this.props.navigation.state.params) {
          const { params } = this.props.navigation.state;
          ageVal=params.age;
          gender_valueVal=params.gender_value;
          smk_valueVal = params.smk_value;
          benefit_valueVAl = params.benefit_value;
          deductible_valueVAl = params.deductible_value;
          paym_tmVal= params.paym_tm_s_val;
          sum_insuredVal=params.sum_insured;
          annual_premiumVal=params.annual_premium;

          county_val=params.grp2_s_value,
          childAge_val=params.childAge,
          chile_no_val=params.no_child,
          retireAge_val = params.retireAge


      }



     
        this.state = {
          is_modal_visible:false,
          refreshing:true,
          all_product:[],
          all_main_cat:[],
          all_sub_cat:[],

          header_tab_val:'all',

          age:ageVal == null ? 0 : ageVal,
          gender_value:gender_valueVal == null ? 1 : gender_valueVal,
          smk_value:smk_valueVal == null ? 1 : smk_valueVal,
          benefit_value:benefit_valueVAl,
          deductible_value:deductible_valueVAl,
          paym_tm:paym_tmVal == null ? '10' : paym_tmVal,
          sum_insured:sum_insuredVal ,
          annual_premium:annual_premiumVal,
          grp2_s_value:county_val,
          itemPickcount:0,
          no_child:chile_no_val,
          childAge:childAge_val,
          retireAge:retireAge_val,

      
          Selected_Item:[],
          picked_p_id:[],

          ProimagePath:'',
          userName:'',
          loginTXT:'Login',
          login_btn_active:false,
          isOpen:false,

          sortVal:'1',
          isLoggedIn:false,
        };
      }
     
      componentDidMount() {
        this.fetchData()

        AsyncStorage.getItem('isLoggedIn').then((value) => {
                if(value === 'true'){
                  this.setState({isLoggedIn:true,loginTXT:'Sign-out'})
                }else{
                  this.setState({isLoggedIn:false,loginTXT:'Login'})
                }
                  
              })
              .then(res => {
                  
              });
      }


      th_sp(val){
        //separate number with comma
        try{
         return(val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
        }catch(e){
          return('')
        }
      }


      componentWillReceiveProps(nextProps) {
        if(this.props.isFocused && nextProps.isFocused){
          //console.log('not running anything')
          
        }
        
        if(this.props.isFocused && !nextProps.isFocused){
         // console.log('ufocus')
        
        }
        
        if(!this.props.isFocused && nextProps.isFocused){
        //  console.log('focus')

        }
            
      }



    openModal=(val)=>{
        this.setState({is_modal_visible:true})
    
    }

    fetchData (){
      this.setState({refreshing:true,isLoading:true})
      const ref= firebase.database().ref('app_data/items');
      ref.once('value', snapshot => {
      
      const items = [];
        
      snapshot.forEach((doc) => {
          items.push({
            key:doc.key,
            isSelect:false,
            ...doc.toJSON(),
          })
        })
    
      this.setState({all_product:items})
      
    
      });
    }





////////////////////////////////////////////////////////////////////////////////
          filterData(){
            const { sortVal,age,gender_value,smk_value,paym_tm,grp2_s_value,no_child,childAge,retireAge,sum_insured,annual_premium,header_tab_val,benefit_value,deductible_value }   = this.state;
            const cat_id=  this.props.screenProps.cat_id
            var genVal;
            var smkVal;
            var bnftVal;
            var total_r_arr_len=[0];
            var filArray=[];

            if(gender_value == 1){
              genVal = "male";
            }else{
              genVal = "female";
            }

            if(smk_value == 1){
              smkVal = "smoking";
            }else{
              smkVal = "non_smoking";
            }

            if(benefit_value == 1){
              bnftVal = "basic";
            }else{
              bnftVal = "smm";
            }


            filArray = this.state.all_product.filter(function(itemx){
              var PaymentArr = itemx.p_payment_term != null ?  itemx.p_payment_term.split(",") : [];
              var countryArr = itemx.grp2_cntry_or_other != null ?  itemx.grp2_cntry_or_other.split(",") : [];
              var noChildArr = itemx.no_child != null ?  itemx.no_child.split(",") : [];
              var isPayMentContain = PaymentArr.includes(paym_tm);
              var isCountry = countryArr.includes(grp2_s_value);
              var isNoChild = noChildArr.includes(no_child); 
              var showAll = false ;
              var GtoThouStoTwen = false ;
              var greaterVal = false ;

           
           
              
              if(deductible_value == 1){
                showAll = true
              }else if(deductible_value == 2){
                GtoThouStoTwen = itemx.prod_deductible >= 10000 && itemx.prod_deductible <= 20000 ? true : false
              }else if(deductible_value == 3){
                greaterVal = itemx.prod_deductible >= 20001 ? true : false
              }

              //This is the main filter function for all the product data please get a full idea of the system before you change this.
              return (itemx.p_lower_age  == age || itemx.p_lower_age == null)
                    && (genVal === itemx.p_gender || itemx.p_gender === "male/female" || itemx.p_gender == null)
                    && (itemx.p_smoking_st === smkVal || itemx.p_smoking_st === "non_smoking/smoking" || itemx.p_smoking_st == null)
                    && (isPayMentContain || PaymentArr.length === 0)
                    && (isCountry || countryArr.length === 0)
                    && (isNoChild || noChildArr.length === 0)
                    && (itemx.child_age == childAge || itemx.child_age == null)
                    && (itemx.retire_Age == retireAge || itemx.retire_Age == null)
                    && ( itemx.p_sum_ins == sum_insured || sum_insured == null || itemx.p_sum_ins == null)
                    && ( itemx.p_ann_pre == annual_premium || annual_premium == null || itemx.p_ann_pre == null)
                    && (itemx.prod_benefit == bnftVal || itemx.prod_benefit === "basic/smm" || itemx.prod_benefit == null)
                    && (itemx.p_prod_type === header_tab_val || itemx.p_prod_type == null)
                    && (itemx.categories_cat_id == cat_id)
                    && (itemx.prod_deductible == null || showAll || GtoThouStoTwen || greaterVal)
            })

        if(cat_id === '1' || cat_id === '7' || cat_id === '9'){
          if(sortVal === '1'){
            return(filArray)
           }else if(sortVal === '2'){
             return(sort(filArray).desc(u => this.get_tr_val_for_Sort(0,u.filter_val_2)))
           }else if(sortVal === '3'){
            return(sort(filArray).desc(u => this.get_tr_val_for_Sort(1,u.filter_val_2)))
          }else if(sortVal === '4'){
            return(sort(filArray).desc(u => this.get_tr_val_for_Sort(2,u.filter_val_2)))
          }else if(sortVal === '5'){
            return(sort(filArray).desc(u => this.get_tr_val_for_Sort(3,u.filter_val_2)))
          }
           else if(sortVal === '6'){
             return(sort(filArray).desc(u => parseFloat(u.filter_val_3)))
           }
        }else if(cat_id === '3' || cat_id === '11'){
  
          if(sortVal === '1'){
            return(filArray)
           }else if(sortVal === '2'){
             return(sort(filArray).desc(u => parseFloat(u.filter_val_1)))
           }else if(sortVal === '3'){
             return(sort(filArray).desc(u =>parseFloat(u.filter_val_2)))
           }else if(sortVal === '4'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_3)))
          }
        }else if(cat_id === '5' || cat_id === '6' || cat_id === '8'){
  
          if(sortVal === '1'){
            return(filArray)
           }else if(sortVal === '2'){
             if(cat_id === '8'){
              return(sort(filArray).asc(u => parseFloat(u.p_ann_pre)))
             }else{
              return(sort(filArray).desc(u => parseFloat(u.p_ann_pre)))
             }
           }else if(sortVal === '3'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_2)))
           }else if(sortVal === '4'){
            return(sort(filArray).desc(u =>parseFloat(u.filter_val_1)))
          }
        }else if(cat_id === '4' || cat_id === '12' || cat_id === '2' ){
  
          if(sortVal === '1'){
            return(filArray)
           }else if(sortVal === '2'){
             return(sort(filArray).desc(u => parseFloat(u.p_ann_pre)))
           }else if(sortVal === '3'){
             return(sort(filArray).desc(u =>parseFloat(u.filter_val_1)))
           }else if(sortVal === '4'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_2)))
          }else if(sortVal === '5'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_3)))
          }
        }else if(cat_id === '10'){
  
          if(sortVal === '1'){
            return(filArray)
           }else if(sortVal === '2'){
             return(sort(filArray).asc(u => parseFloat(u.p_ann_pre)))
           }else if(sortVal === '3'){
             return(sort(filArray).desc(u =>parseFloat(u.filter_val_1)))
           }else if(sortVal === '4'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_2)))
          }else if(sortVal === '5'){
            return(sort(filArray).desc(u => parseFloat(u.filter_val_3)))
          }
        }else{
          return(filArray)
        }
          
      }


    sortFunc=(val)=>{
            this.setState({sortVal:val})
    }
////////////////////////////////////////////////////////////////////////////////


    get_tr_val_for_Sort(index,values){
      var PaymentArr = values != null ? values.split(",") : '';
            if(typeof PaymentArr[index] === 'undefined') {
              return(0)
          }
          else {
            return(PaymentArr[index])
          }
    }

///////////////////////////////////////////////////////////////////
          getPay_tm_val(index,values){
            var PaymentArr = values != null ? values.split(",") : '';
                  if(typeof PaymentArr[index] === 'undefined') {
                    return('')
                }
                else {
                  return(PaymentArr[index])
                }
          }


          get_total_rn_val(index,values){
            var PaymentArr = values != null ? values.split(",") : '';
                  if(typeof PaymentArr[index] === 'undefined') {
                    return('')
                }
                else {
                  return(PaymentArr[index])
                }
          }




          itemSelect=(item)=>{
            
            
                if(item.isSelect){
                  LayoutAnimation.configureNext(LayoutAnimation.Presets.linear);
                    this.setState({
                      all_product: this.state.all_product.map(el => (el.id === item.id ? Object.assign({}, el, { isSelect:false }) : el)),
                      itemPickcount:this.state.itemPickcount - 1
                    });

                    
                      var array = [];
                      array = this.state.picked_p_id;

                      var index = array.indexOf(item.p_uid);
                      if (index > -1) {
                        array.splice(index, 1);
                      }

                     this.setState({picked_p_id:array})
                    

                  }else{
                    if(this.state.itemPickcount > 2 ){
                      alert('Only 3 items can compare !')
                    }else{
                      LayoutAnimation.configureNext(LayoutAnimation.Presets.linear);
                      this.setState({
                        all_product: this.state.all_product.map(el => (el.id === item.id ? Object.assign({}, el, { isSelect:true }) : el)),
                        itemPickcount:this.state.itemPickcount + 1
                      });

                      this.state.picked_p_id.push(item.p_uid)
                    }
              }
           
          }


          open_product_view(item){
            this.setState({Selected_Item:item,})
            this.prod_view.current.open(item.p_uid,this.props.screenProps.cat_id);
          }

          open_prod_comp(){
            var prod_ids = this.state.picked_p_id
            if(this.state.isLoggedIn){
              this.prod_comp.current.open(prod_ids);
            }else{
              this.props.navigation.navigate('Login');
            }
            
          }


          compareButton(){
            if(this.state.itemPickcount > 1){
                  return(
                  <TouchableOpacity style={styles.comp_btn} onPress={()=> this.open_prod_comp()}>
                  <Image source={{ uri: `asset:/images/img_icons/ico_filter_2.png`}} style={styles.btn_icon_St} />
                  <Text style={styles.btnMsg}>Add to Compare</Text>
                  </TouchableOpacity>
                        )
            }else{
              return(<View/>)
            }
          }



          toggleDrawer=()=>{
            if(this.state.isOpen){
               this.drawer.current.closeDrawer();
              
            }else{
               this.drawer.current.openDrawer();
              
        
            }
        }


        prod_list_data(item){
          const cat_id=  '1'
            if(cat_id === '1' || cat_id === '7' || cat_id === '9'){
              return(
                <View style={styles.detail_row2}>
                <View style={styles.paym_tm_col1}>
                    <View style={styles.paym_year_txt_pad}>
                    <Text style={styles.paym_year_txt}>Year</Text>
                      </View>

                      <View style={styles.paym_year_txt2_pad}>
                      <Text style={styles.paym_year_txt}>Total Return</Text>
                        </View>
                </View>

                <View  style={styles.paym_tm_col2}>
                    <View style={styles.paym_year_value_pad}>
                            <View style={styles.values_St}>
                              <Text style={styles.valueTXT}>{this.get_total_rn_val(0,item.filter_val_1)}</Text>
                              </View>


                              <View  style={styles.values_St}>
                              <Text style={styles.valueTXT}>{this.get_total_rn_val(1,item.filter_val_1)}</Text>
                              </View>

                              <View  style={styles.values_St}>
                              <Text style={styles.valueTXT}>{this.get_total_rn_val(2,item.filter_val_1)}</Text>
                              </View>


                              <View  style={styles.values_St}>
                              <Text style={styles.valueTXT}>{this.get_total_rn_val(3,item.filter_val_1)}</Text>
                              </View>

                    </View>

                    <View style={styles.paym_year_value_pad2}>
                    <View style={styles.values_St}>
                                <Text style={styles.precntTXT}>{this.getPay_tm_val(0,item.filter_val_2)}</Text>
                              </View>


                              <View  style={styles.values_St}>
                              <Text style={styles.precntTXT}>{this.getPay_tm_val(1,item.filter_val_2)}</Text>
                              </View>

                              <View  style={styles.values_St}>
                              <Text style={styles.precntTXT}>{this.getPay_tm_val(2,item.filter_val_2)}</Text>
                              </View>


                              <View  style={styles.values_St}>
                              <Text style={styles.precntTXT}>{this.getPay_tm_val(3,item.filter_val_2)}</Text>
                              </View>
                    </View>

                </View>

                <View  style={styles.paym_tm_col3}>

                <View  style={styles.sep_icon_St}>
                </View>

                <View style={styles.break_txt_pad}>
                    <Text style={styles.paym_year_txt}>Break-even</Text>
                      </View>

                      <View style={styles.break_txt_pad2}>
                      <Text style={styles.paym_year_txt}>{item.filter_val_3} year</Text>
                        </View>
                </View>

        </View>
              )
            }else if(cat_id === '2' || cat_id === '10'){
              return(<View style={styles.detail_row2_other}>
                <View style={[styles.life_first_cols,{paddingLeft:wp('1%')}]}>
                <Text style={styles.CI_font} numberOfLines={1}>Total Return of Cash</Text>
                <Text style={styles.CI_font}>Value @20 year</Text>
                <Text style={styles.CI_font}>{item.filter_val_1}%</Text>
                </View>

                <View style={styles.life_first_cols}>
                <Text style={styles.CI_font} numberOfLines={1}>Total Return of Death</Text>
                <Text style={styles.CI_font}>Benefits @10 year</Text>
                <Text style={styles.CI_font}>{item.filter_val_2}%</Text>
                </View>


                <View style={styles.life_first_cols}>
                <Text style={styles.CI_font} numberOfLines={1}>Total Return of Death</Text>
                <Text style={styles.CI_font}>Benefits @20 year</Text>
                <Text style={styles.CI_font}>{item.filter_val_3}%</Text>
                </View>

                <View style={[styles.life_last_col,{flex:0.2}]}>
                <Text style={styles.CI_font}>Annual</Text>
                <Text style={styles.CI_font}>Premium :</Text>
                <Text style={styles.CI_font}>USD{this.th_sp(item.p_ann_pre)}</Text>
                </View>

            </View>)
            }else if(cat_id === '3' || cat_id === '11'){
              return(<View style={styles.detail_row2_other}>
                  <View style={styles.life_first_cols}>
                  <Text style={styles.life_font}>Total Income</Text>
                  <Text style={styles.life_font}>${this.th_sp(item.filter_val_1)}</Text>
                  </View>

                  <View style={styles.life_first_cols}>
                  <Text style={styles.life_font}>Total Return</Text>
                  <Text style={styles.life_font}>@65 age</Text>
                  <Text style={styles.life_font}>{item.filter_val_2}%</Text>
                  </View>


                  <View style={styles.life_first_cols}>
                  <Text style={styles.life_font}>Total Return</Text>
                  <Text style={styles.life_font}>@85 age</Text>
                  <Text style={styles.life_font}>{item.filter_val_3}%</Text>
                  </View>

                  {/* <View style={styles.life_last_col}>
                  <Text style={styles.life_font}>Annual</Text>
                  <Text style={styles.life_font}>Premium :</Text>
                  <Text style={styles.life_font}>USD{item.p_ann_pre}</Text>
                  </View> */}

              </View>)
            }else if(cat_id === '4' || cat_id === '12'){
              return(<View style={styles.detail_row2_other}>
                  <View style={[styles.life_first_cols,{paddingLeft:wp('1%')}]}>
                  <Text style={styles.CI_font} numberOfLines={1}>Total Return of Cash</Text>
                  <Text style={styles.CI_font}>Value @25 year</Text>
                  <Text style={styles.CI_font}>{item.filter_val_1}%</Text>
                  </View>

                  <View style={styles.life_first_cols}>
                  <Text style={styles.CI_font} numberOfLines={1}>Total Return of Major</Text>
                  <Text style={styles.CI_font}>Benefits @10 year</Text>
                  <Text style={styles.CI_font}>{item.filter_val_2}%</Text>
                  </View>


                  <View style={styles.life_first_cols}>
                  <Text style={styles.CI_font} numberOfLines={1}>Total Return of Major</Text>
                  <Text style={styles.CI_font}>Benefits @15 year</Text>
                  <Text style={styles.CI_font}>{item.filter_val_3}%</Text>
                  </View>

                  <View style={[styles.life_last_col,{flex:0.2}]}>
                  <Text style={styles.CI_font}>Annual</Text>
                  <Text style={styles.CI_font}>Premium :</Text>
                  <Text style={styles.CI_font}>USD{this.th_sp(item.p_ann_pre)}</Text>
                  </View>

              </View>)
            }else if(cat_id === '5' || cat_id === '6' || cat_id === '8'){
              return(<View style={styles.detail_row2_other}>
                  <View style={styles.life_first_cols}>
                  <Text style={[styles.life_font,{textAlign:'center'}]}>Maximum Annual Limited</Text>
                  <Text style={styles.life_font}>${this.th_sp(item.filter_val_1)}</Text>
                  </View>

                  <View style={styles.life_first_cols}>
                  <Text style={styles.life_font}>{cat_id === '5' || cat_id  === '8' ? 'Surgery Benefit' : 'Lifetime Limit'}</Text>
                  <Text style={styles.life_font}>${this.th_sp(item.filter_val_2)}</Text>
                  </View>


                  <View style={[styles.life_last_col,{flex:0.32}]}>
                  <Text style={styles.life_font}>Annual</Text>
                  <Text style={styles.life_font}>Premium :</Text>
                  <Text style={styles.life_font}>USD{this.th_sp(item.p_ann_pre)}</Text>
                  </View>

              </View>)
            }
          
        }



      emptyComp(){
        if(this.state.refreshing){
          return(
            <View style={styles.loading}>
                 <Text style={styles.emptyTXT}>Please Wait..</Text>
                 <ActivityIndicator size="small" color="#777" />
            </View>)
        }else{
          return(
            <View style={styles.loading}>
                 <Text style={styles.emptyTXT}>No Data..</Text>
                  <Icon name="ios-alert" style={styles.EmtyIco} />
            </View>)
        }
        
      }



     


  render() {
    const cat_id=  this.props.screenProps.cat_id
    return (
      <View style={styles.container}>
   <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} screen={'prod_list'} 
   openModal={this.openModal} sortVal={this.state.sortVal}  sortFunc={this.sortFunc} cat_id={cat_id}/>
          
          <View style={styles.compareBtn}>
                <View style={styles.colside}>
                  <Text style={styles.prodTxt}>Products</Text>
                </View>
                <View style={styles.colmid}>
                  
                </View>
                <View style={styles.colside}>
                </View>
         </View>
         {this.compareButton()}

       <View style={styles.list_cont}>
       <FlatList 
                          
                          data={this.state.all_product}

                          keyExtractor={(item, index) => item.id}

                            ListEmptyComponent={this.emptyComp()}
                          //contentContainerStyle={styles.main_cat_LIST}



                          renderItem={({ item, index }) =>

                                <TouchableOpacity style={styles.main_prod_item_pad} onPress={()=>this.open_product_view(item)}>
                                  <View style={styles.mainRow1}>

                                    <View style={styles.imgCon}>
                                          <Image style={[styles.prodImg,{opacity:item.p_img_url == null ? 0.5 : 1}]} 
                                          source={{uri : item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : item.p_img_url}} />
                                      </View>

                                      <View style={styles.detailsCon}>
                                            <View style={styles.detail_row1}>
                                                  <View style={styles.detail_row1_col1}>
                                                  <Text style={styles.titleTXT} numberOfLines={1}>{item.p_name}</Text>

                                                  <Text style={styles.desTXT} numberOfLines={2}>{item.p_description}</Text>
                                                  </View>

                                                  <View style={styles.detail_row1_col2}>
                                                        <CheckBox checked={item.isSelect} onPress={()=> this.itemSelect(item)}/>
                                                        <Text style={styles.ratingTXT}>{item.prod_rating}</Text>
                                                    </View>
                                              </View>

                                             
                                        </View>
                                    </View>

                                    <View  style={styles.mainRow2}>

                                          {this.prod_list_data(item)}
                                    </View>


                                </TouchableOpacity>

                        }
                      refreshing={this.state.refreshing}
                       //onRefresh={() => this.handleRefresh()}
                        />
      
      </View>




       <Cat_filter_modal 

       _this={this} 
       visible={this.state.is_modal_visible} 
       all_main_cat={this.state.all_main_cat}
       all_sub_cat={this.state.all_sub_cat}

      
       />


        {/* <Sort_filter_modal 

        _this={this} 
        visible={this.state.is_sort_filter_modal} 
        all_main_cat={this.state.all_main_cat}
        all_sub_cat={this.state.all_sub_cat}

        sort_by={this.state.sort_by}
        age={this.state.age}
        /> */}



          <Product_View 
          ref={this.prod_view}

          Selected_Item = {this.state.Selected_Item} 
          itemSelect={this.itemSelect}
          cat_id = {this.props.screenProps.cat_id}
          age={this.state.age}
          gender_value={this.state.gender_value}
          smk_value={this.state.smk_value}
          paym_tm={this.state.paym_tm}
          sum_insured ={this.state.sum_insured}
          annual_premium= {this.state.annual_premium}
          />

          <Product_compare 
          ref={this.prod_comp}
          />
     
          <Drawer _this={this} isOpen={this.state.isOpen} ProimagePath={''}  userName={''} ref={this.drawer}  screen={'prod_list'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} />
          
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#fbfbfc',
  },
  list_cont:{
    flex:1,
    width:'100%',
    //marginTop: hp('5%'),
  },

  main_prod_item_pad:{
      height:hp('21%'),
      width:'100%',
      alignItems: 'center',
      backgroundColor: '#fff',
      paddingTop:hp('2%'),
      paddingBottom:hp('1%'),
      borderTopWidth: 0.5,
  },

  mainRow1:{
      flex:0.55,
      flexDirection:'row',
      width:'100%',
  },

  mainRow2:{
    flex:0.45,
    width:'100%',
    justifyContent: 'center',
},

  imgCon:{
    width:hp('18%'),
    height:hp('9%'),
    marginHorizontal: wp('2%'),
    backgroundColor: '#ddd',
  },

  detailsCon:{
    flex:1,
  },

  detail_row1:{
    flex:1,
    flexDirection:'row',
  },

  detail_row2:{
    flex:0.5,
    flexDirection:'row',
    height:'100%',

  },

  detail_row2_other:{
    flex:1,
    flexDirection:'row',
    height:'100%',
  },

  titleTXT:{
    fontSize:hp('2.5%'),
   // marginLeft:-('5%'),
    color:'#333',
   // fontFamily: 'seg_sem_light',
  },

  detail_row1_col1:{
    flex:0.8,
  },

  detail_row1_col2:{
    flex:0.2,
  },

  desTXT:{
    fontSize:hp('2%'),
    color:'#6d6d6d',
    paddingTop:-('2%'),
    fontFamily: 'seg_light',
  },

  paym_tm_col1:{
    flex:0.25,
    
  },

  paym_tm_col2:{
    flex:0.5,
  },

  paym_tm_col3:{
    flex:0.25,
    justifyContent: 'center',
  },

  paym_year_txt_pad:{
    flex:0.5,
    justifyContent: 'center',
    alignItems:'flex-end',
    paddingBottom: hp('2%'),
  },

  paym_year_txt2_pad:{
    flex:0.5,
    justifyContent: 'center',
    alignItems:'flex-end',
    
  },

  paym_year_txt:{
    fontSize:hp('1.7%')
  },

  paym_year_value_pad:{
    flex:0.5,
    flexDirection:'row',
    alignItems: 'center',
  },


  paym_year_value_pad2:{
    flex:0.5,
    flexDirection:'row',
    alignItems: 'center',
    paddingTop: hp('2%'),
    

  },
  

  values_St:{
    flex:1,
    justifyContent: 'center',
    alignItems:'center'
  },

  valueTXT:{
    fontSize:hp('2%'),
  },

  precntTXT:{
    fontSize:hp('2%'),
    color:'red'
  },

  break_txt_pad:{
    flex:0.5,
    justifyContent: 'center',
    paddingLeft:wp('2%')
  },

  break_txt_pad2:{
    flex:0.5,
    justifyContent: 'center',
    paddingTop: hp('2%'),
    paddingLeft:wp('2%')
  },

  prodImg:{
    height:'100%'
  },
  comp_btn:{
    flexDirection:'row',
    width:wp('43%'),
    height:hp('5%'),
    marginTop:-hp('2%'),
    borderRadius: hp('0.5%'),
    marginBottom:hp('1.5%'),
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#3eda72',
  },

  ratingTXT:{
    fontSize:hp('3%'),
    marginTop: wp('2%'),
    marginLeft: wp('2%'),
    color:'#11CE4D'
  },

  life_first_cols:{
    flex:0.32,
    height:'100%',
    alignItems: 'center',
  },

  life_last_col:{
    flex:0.32,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'red',
  },

  life_font:{
    fontSize:hp('1.7%'),
    color:'red'
  },

  CI_font:{
    fontSize:hp('1.5%'),
    color:'red'
  },

  loading:{
    height:hp('50%'),
    width:'100%',
    justifyContent: 'center',
    alignItems:'center',
  },

  emptyTXT:{
    fontWeight:'bold',
    fontSize:hp('2.5%'),
    color:'#898989',
    marginBottom: hp('1%'),
  },

  EmtyIco:{
    fontSize:hp('5%'),
    color:'#898989'
  },

  compareBtn:{
      width:'100%',
      height:hp('5%'),
      flexDirection:'row'
  },

  colmid:{
    flex:0.4,
  },

  colside:{
    flex:0.3,
    justifyContent: 'center',
  },

  prodTxt:{
    fontSize:hp('2.5%'),
    fontFamily:'seg_sem_bold',
    color:'#333',
    marginTop:-hp('0.5%'),
    paddingLeft: wp('2.5%'),
  },

  btnMsg:{
    color:'#fff',
    fontSize:hp('2%'),
    marginLeft:wp('1%')
  },

  btn_icon_St:{
    height:hp('5%'),
    width:hp('5%'),
    marginLeft:-wp('1%')
  },

  sep_icon_St:{
    height:hp('5%'),
    width:wp('0.3%'),
    position:'absolute',
    left:0,
    backgroundColor: '#666'
  }

});


export default withNavigationFocus(Product_list);