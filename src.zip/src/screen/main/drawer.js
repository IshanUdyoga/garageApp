import * as React from 'react';
import {FlatList,AsyncStorage, ActivityIndicator,Text, View, StyleSheet,Dimensions,Animated,TouchableOpacity,Share,Easing,ScrollView,Linking } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import stringsoflanguages from '../lng/stringsoflanguages';
import LangSelect from '../main/langSelectModal';
import RNRestart from 'react-native-restart';
import logo from '../../img/logo.png';
import Image from 'react-native-scalable-image';
import Icon from 'react-native-ionicons';
//import { AccessToken, LoginManager,GraphRequest,GraphRequestManager } from 'react-native-fbsdk';

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width

let deviceH = Dimensions.get('screen').height;
let bottomNavBarH = deviceH - deviceHeight;

export default class Drawer extends React.Component {


    constructor (props) {

        super(props);


        this.state = {
            fadeBody:new Animated.Value(0),
            left:new Animated.Value(-deviceWidth/3),
            leftPro:new Animated.Value(-wp('60%')),
            isAboutOpen:false,
            upmodal:false,
            isLoggedIn:'false',
            loginTXT:'',
            LangSelect:false,
            is_toggled:false,
            lang:'EN',
            loading:false
           
        };

    }

    

    componentDidMount(){
  
      AsyncStorage.getItem("isLangSelected").then((value) => {
        if(value !== null){
          this.setState({lang:value.toUpperCase()})
        }

      })
      .then(res => {
          
      });
  } 



  openPickerCam(){
    ImagePicker.openCamera({
      width: 400,
      height: 400,
      cropping: true,
    }).then(image => {
      this.props._this.setState({ProimagePath:image.path,})
      this.setState({upmodal:false})
      this.upload()
    });
}

openPickerLib(){
      ImagePicker.openPicker({
        width: 400,
        height: 400,
        cropping: true
      }).then(image => {
        this.props._this.setState({ProimagePath:image.path})
        this.setState({upmodal:false})
        this.upload()
      });
}


clearImage(){

  ImagePicker.clean().then(() => {
  }).catch(e => {
  });
}


upload(){

    AsyncStorage.getItem("userID").then((value) => {
      this.uploadImageTowebBuyer(value)
        })
        .then(res => {
            
        });

}



uploadImageTowebBuyer(buyerId){
  const imagePath   = this.props.ProimagePath ;
  const parts = imagePath.split('/')


  this.props._this.setState({isProLoad:true})

        


          const sessionId = new Date().getTime();

          const formData = new FormData();
    formData.append('image', {
      uri: imagePath,
      name: parts[parts.length - 1],
      type: 'image/jpeg'
    });
    formData.append('Content-Type', 'image/jpeg');
    formData.append('buyerId', buyerId);

    fetch('https://prescrib.smartlogic.lk/php-api/uploadImageProPicBuyer.php',{
        method: 'POST',
        headers: {
            'Content-Type': 'multipart/form-data',
          },
          body: formData
      })
      .then((response) => response.json())
      .then((responseJson) => {
        // console.log(responseJson); 
         alert('Profile Photo Uploaded !');
                       
         this.props._this.setState({isProLoad:false}) 
         AsyncStorage.setItem('ProPicUrl', responseJson)
        

        })
        .catch((error) => {
            

            alert('Photo Upload Error Try Again !');
                       
            this.props._this.setState({isProLoad:false}) 

          });
    

  
  


}      

    


  openDrawer=()=>{
      this.props._this.setState({isOpen:true})
      Animated.sequence([
      Animated.timing(    
        this.state.fadeBody,  
        {
        
          toValue: 1,
          duration: 400,      
        }
      ),

      Animated.timing(    
        this.state.left,  
        {
          easing: Easing.out(Easing.circle),
          toValue: 0,
          duration: 500,   
        }
      )

    ]).start();


  }


  closeDrawer=()=>{

    Animated.spring(    
      this.state.leftPro,  
      {
      
        toValue: -wp('60%'),
       // duration: 400,
      }
    ).start(); 
   

    Animated.timing(    
        this.state.fadeBody,  
        {
          toValue: 0,
          duration: 200,      
        }
      ).start();  

      Animated.spring(    
        this.state.left,  
        {
        
          toValue: -deviceWidth/1.5,
         // duration: 400,
        }
      ).start(); 

      setTimeout(() => {this.props._this.setState({isOpen:false})}, 200)
      this.setState({isAboutOpen:false})

      
      
  }











loginFunc(){
  AsyncStorage.getItem("isLoggedIn").then((value) => {
    if(value === 'true'){
      this.closeDrawer()
      alert('Logged Out')
      AsyncStorage.multiRemove(['userID','userType','isLoggedIn','userName','loginType']);
      RNRestart.Restart();

    }else{
      this.closeDrawer()
      this.props._this.props.navigation.navigate('Login')
    }
})
.then(res => {
    
});

}








toggle_drop(){
  if(this.state.is_toggled){
      this.setState({is_toggled:false})
  }else{
    this.setState({is_toggled:true})
  }
}


navgate_to = async(id,pay_term,grp2_cntry_or_other) =>{
    this.closeDrawer()
    await this.props._this.props.screenProps.setCatId(id)
    this.props._this.props.navigation.push('Sort_filter',{id,pay_term,grp2_cntry_or_other})
}


promisedSetState = (newState) => {
  return new Promise((resolve) => {
      this.setState(newState, () => {
          resolve()
      });
  });
}


LL(){
  if(this.state.loading){
    return(<View style ={styles.Load} >

     <View style={styles.LoadSub}>
     <ActivityIndicator size="large"  color='#fff'/>
       </View>

  </View>)
  }else{
    return(<View />)
  }
}



  render() {
        return (
            <Animated.View  style={[styles.container,{height:this.props.isOpen ? '100%' : '0%',opacity:this.state.fadeBody}]}>
                    <TouchableOpacity style={{width:'100%',height:'100%'}} onPress = {() => this.closeDrawer() }>


                        </TouchableOpacity>



                           
                        <Animated.View  style={[styles.drawPad,{left:this.state.left,backgroundColor: '#2CBA5B'}]}>
                           
                             <TouchableOpacity style={styles.backIconCon} onPress = {() => this.closeDrawer()} ><Icon name='ios-arrow-back' style={styles.icoSt} /></TouchableOpacity>

                        <View style={styles.items}>
                           <View style={styles.draw_header_pad}>

                           </View>

                            <View style={styles.draw_logo_pad}>
                            {/* <Image
                                                            style={styles.pro_img}
                                                            width={wp('25%')}
                                                            source={logo}
                                                        /> */}
                                                   <Image
                                                     height={hp('16%')}
                                                      source={{ uri: `asset:/images/img_icons/menu_logo.png`}}
                                                      />
                            </View>

                            <View style={styles.bottom_view}>
                                    <ScrollView >
                              <View style={[styles.drop_down_pad]} >

                                              <TouchableOpacity style={[styles.drop_down_header,{backgroundColor: this.state.is_toggled ? '#33bf62' : 'rgba(0, 0, 0, 0)',}]} onPress={()=> this.toggle_drop()}>
                                                  <View style={styles.drop_down_col1}>
                                                              <Image
                                                                                  height={hp('6%')}
                                                                                  style={styles.ico_st}
                                                                                  source={{ uri: `asset:/images/img_icons/network_ico.png`}}
                                                                              />
                                                  </View >

                                                  <View style={styles.drop_down_col2}>
                                                                <Text style={styles.myL_txt}>Categories</Text>
                                                  </View>

                                                  <View style={styles.drop_down_col3}>

                                                 {this.state.is_toggled ? <Icon name='ios-arrow-down' style={styles.drop_down}/> : <Icon name='ios-arrow-forward' style={styles.drop_down}/>}

                                                  </View>
                                              </TouchableOpacity>


                                              <View style={styles.drop_down_body}>
                                              {this.state.is_toggled ? 
                                              <FlatList 
                        
                                                          data={this.props._this.props.screenProps.cat_data}

                                                          keyExtractor={(item, index) => item.sell_uid}
                                                        
                                                        contentContainerStyle={styles.cat_flat}



                                                          renderItem={({ item, index }) =>

                                                                <View style={styles.cat_st} onPress={()=> this.navgate_to(item.cat_id,item.pay_terms,item.grp2_cntry_or_other)}>
                                                                  <View style={styles.at_bd}>
                                                                  <Icon name='ios-radio-button-off' style={styles.drop_down}/>
                                                                  <Text style={styles.cat_txt} >{item.cat_name}</Text>
                                                                    </View>
                                                                </View>

                                                        }
                                                      //refreshing={this.state.refreshing}
                                                      // onRefresh={() => this.handleRefresh()}
                                                        />
                                                        : <View/>} 
                                              </View>

                                              <View style={styles.advi_con}>
                                              {/* <View style={styles.drop_down_col1}>
                                                              <Image
                                                                                  height={hp('6%')}
                                                                                  style={styles.ico_st}
                                                                                  source={{ uri: `asset:/images/img_icons/ico_compass.png`}}
                                                                              />
                                                  </View >

                                                  <View style={styles.drop_down_col2}>
                                                                <Text style={styles.myL_txt}>Advisor Corner</Text>
                                                  </View> */}
                                              </View>
                              </View>

                              
                                          <View style={styles.btm_pad}>
                                              <View style={styles.row_1}>
                                                  <View style={styles.row_1_col_1}>
                                                  <Text style={styles.pro_txt} numberOfLines={1}>Hirunika</Text>
                                                  </View>

                                                  <View style={styles.row_1_col_2}>
                                                        <View style={styles.pro_con}>
                                                        <Image
                                                                                    height={hp('10%')}
                                                                                    source={{ uri: `asset:/images/img_icons/profile.png`}}
                                                                                />
                                                        </View>
                                                  </View>
                                              </View>

                                              <TouchableOpacity style={styles.row_2}>
                                                <View style={styles.drop_down_col1}>
                                                                <Image
                                                                                    height={hp('6%')}
                                                                                    style={styles.ico_st}
                                                                                    source={{ uri: `asset:/images/img_icons/setting_ico.png`}}
                                                                                />
                                                    </View >

                                                    <View style={styles.drop_down_col2}>
                                                                  <Text style={styles.myL_txt}>My Account</Text>
                                                    </View>
                                              </TouchableOpacity>

                                              <TouchableOpacity style={styles.row_3}>
                                              <View style={styles.drop_down_col1}>
                                                                <Image
                                                                                    height={hp('6%')}
                                                                                    style={styles.ico_st}
                                                                                    source={{ uri: `asset:/images/img_icons/about_ico.png`}}
                                                                                />
                                                    </View >

                                                    <View style={styles.drop_down_col2}>
                                                                  <Text style={styles.myL_txt}>Setting</Text>
                                                    </View>
                                              </TouchableOpacity>

                                              <TouchableOpacity style={styles.row_4}>
                                              {/* <TouchableOpacity style={styles.lang} onPress = {() => this.setState({LangSelect:true}) }>
                                        <View style={{alignItems: 'center',}}>
                                        <Text style={styles.lngST}>{this.state.lang}</Text>
                                                          </View>
                                          </TouchableOpacity>

                                          <TouchableOpacity onPress = {() => this.loginFunc() }><Text style={{fontSize:hp('3%'),color:'#fff'}}>{this.props.loginTXT}</Text></TouchableOpacity>
                                              */}

                                                      <View style={styles.drop_down_col1}>
                                                                <Image
                                                                                    height={hp('6%')}
                                                                                    style={styles.ico_st}
                                                                                    source={{ uri: `asset:/images/img_icons/ico_compass.png`}}
                                                                                />
                                                    </View >

                                                    <View style={styles.drop_down_col2}>
                                                                  <Text style={styles.myL_txt}>About Us</Text>
                                                    </View>
                                                </TouchableOpacity>


                                               <View style={styles.row_5}>
                                                  <TouchableOpacity style={styles.btm_col_1} onPress = {() => this.loginFunc()}>
                                                  <Text style={{fontSize:hp('2.5%'),color:'#fff'}}>{this.props.loginTXT}</Text>
                                                  </TouchableOpacity>

                                                  <View style={styles.btm_col_2} onPress = {() => this.setState({LangSelect:true}) }>
                                                  <Text style={styles.lngST}>{this.state.lang}</Text>
                                                  </View>

                                              </View>

                                          </View>


                                          
                                    </ScrollView>

                              </View>

                            </View>
                        </Animated.View>
                            
                            
                          <LangSelect visible={this.state.LangSelect} _this ={this} screen={"drawer"}/>
            </Animated.View>
          );
     
   
  }
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    width:'100%',
  backgroundColor: 'rgba(0, 0, 0, 0.74)',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  drawPad:{
    position: 'absolute',
    height:'100%',
    width:'65%',
    
  },
  items:{
    flex:1,
      width:'100%',
      alignItems: 'center',
  },
  colorTXT:{
      color:'#fff',
      fontSize:hp('2.2%'),
      fontFamily:'WorkSans-Light'
  },

  ProImgTXT:{
    marginTop: hp('0.6%'),
    color:'#fff',
    fontSize:hp('2.2%'),
    fontFamily:'WorkSans-Light',
    marginBottom:hp('8%')
  },

  tPad:{
      width:'85%',
      paddingVertical:hp('2%'),
      paddingHorizontal: wp('1%'),
      borderWidth: 1,
      borderColor: '#fff',
      borderRadius:hp('4%') ,
      marginBottom: deviceHeight/20,
      justifyContent: 'center',
      alignItems: 'center',
  },
  aboutPad:{
    position: 'absolute',
    top: hp('30%'),
    

  },
  aboutPP:{
    height:hp('52%'),
    width:wp('50%'),
    borderRadius: hp('3%'),
    backgroundColor:'rgba(30, 186, 185, 0.86)',
    alignItems: 'center',
  },
  proPic:{
    height:hp('15%'),
    width:hp('15%'),
    borderRadius:hp('30%'),
    backgroundColor:'#fff',
    marginTop: hp('3%'),
    justifyContent: 'center',
    alignItems: 'center',
  },

  soImg1:{
    height:hp('7%'),
    width:hp('7%'),
    marginRight:wp('2.5%'),
    borderWidth:2,
    borderColor: '#7fdb5e',
    borderRadius:hp('14%')
  },

  soImg2:{
    height:hp('7%'),
    width:hp('7%'),
    borderWidth:2,
    borderColor: '#7fdb5e',
    borderRadius:hp('14%')
  },
  LogoMe:{
    height:hp('14.5%'),
    width:hp('14.5%'),
    

  },

  logo:{
    position: 'absolute',
    bottom:hp('7%'),
    width:'100%'
    //left:wp('5%')
  },


  LogoImg:{
    resizeMode: 'contain',
    width:hp('12%'),
    borderRadius:hp('2%'),
    opacity:0.8

  },


  arrow:{
    position: 'absolute',
    right:0,
    top:hp('5%'),
    marginRight:-wp('7.1%')
  },

  arrowIco:{
    fontSize:hp('6%'),
    color:'rgba(63, 156, 255, 0.86)'

  },

  ProPic:{
  
  },

  proPicimgPad:{
    height:hp('14%'),
    width:hp('14%'),
    borderRadius:hp('28%'),
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  proPicimg:{
    height:hp('13%'),
    width:hp('13%'),
    borderRadius:hp('26%'),
  },

  lang:{
    position: 'absolute',
    bottom:'7%',
    width:'100%'
  },

  lngST:{
    fontSize:hp('2.5%'),
    color:'#fff',
    fontFamily:'seg_light',

  },


  draw_header_pad:{
    height:'10%',
    width:'100%',
    //backgroundColor: '#ddd',
  },


  draw_logo_pad:{
    height:'20%',
    width:'100%',
    alignItems:'center',
  },

  drop_down_pad:{
    width:'100%',
   // backgroundColor: '#ddd',
  },


  drop_down_header:{
    //flex:1,
    flexDirection:'row',
    height:hp('8%'),
    width:'100%',
    
  },

  drop_down_body:{
    width:'100%',
    backgroundColor:'#28AF55'
  },

  bottom_view:{
    height:'70%',
    width:'100%',
  },
  btm_pad:{
    height:'100%',
    width:'100%',

    //backgroundColor: '#7777',
  },

  row_1:{
    flexDirection: 'row',
    height:hp('20%'),
    width:'100%',
  },

  row_1_col_1:{
    flex:0.55,
    height:'100%',
    justifyContent: 'flex-end',
  },

  row_1_col_2:{
    flex:0.45,
    justifyContent: 'flex-end',
    alignItems: 'center',
    //backgroundColor: '#666',
  },

  pro_img:{
  },

  row_2:{
    flexDirection: 'row',
    height:hp('7%'),
    width:'100%',
    //backgroundColor: 'red',
  },

  row_3:{
    flexDirection: 'row',
    height:hp('7%'),
    width:'100%',
    //backgroundColor: '#ddd',
  },

  row_4:{
    flexDirection: 'row',
    height:hp('7%'),
    width:'100%',
   // backgroundColor: 'red',
  },

  row_5:{
    flexDirection: 'row',
    height:hp('6%'),
    width:'100%',
  },

  btm_col_1:{
  flex:0.5,
  paddingLeft:wp('4%'),
  justifyContent:'center'
  },
  btm_col_2:{
  flex:0.5,
  alignItems: 'flex-end',
  paddingRight:wp('4%'),
  justifyContent:'center'
  },

  drop_down_col1:{
    flex:0.2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  drop_down_col2:{
    flex:0.6,
    justifyContent: 'center',
  },

  drop_down_col3:{
    flex:0.2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  cat_flat:{
width:'100%',
backgroundColor: '#28af55',

  },

  cat_st:{
    paddingVertical:hp('2%'),
    width:'80%',
    marginBottom:hp('1%'),
    marginLeft: wp('10%'),
  },

  at_bd:{
    flexDirection:'row'
  },

  cat_img:{
    height:10,
    width:10
  },

  drop_down:{
    color:'#fff',
    fontSize:hp('3%')
  },

  Load:{
    position:'absolute',
  },

  LoadSub:{
    height:hp('100%'),
    width:window.width,
    backgroundColor:'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',

  },
  lang:{
    position: 'absolute',
    bottom:hp('7%'),
    width:'100%'
  },

  lngST:{
    fontSize:hp('3%'),
    color:'#fff',
    fontFamily:'WorkSans-Light',

  },

  backIconCon:{
    position: 'absolute',
    left:wp('3%'),
    top:hp('1%')
  },
  icoSt:{
    color:'#fff',
    fontSize:hp('6%')
  },

  ico_st:{
    
  }
  ,

  myL_txt:{
    color:'#fff',
    fontSize:hp('2.5%'),
    fontFamily:'seg_sem_light',
  },

  advi_con:{
    flexDirection:'row',
    height:hp('8%'),
    width:'100%',
  },

  cat_txt:{
    color:'#fff',
    fontSize:hp('2.2%'),
    marginLeft:wp('2%')
  },

  pro_txt:{
    fontSize:hp('3.5%'),
    color:'#fff',
    fontFamily:'seg_sem_light',
    marginLeft:wp('4%')
  },
  pro_con:{
    height:hp('10%'),
    width:hp('10%'),
    borderRadius:hp('10%'),
    borderWidth:1,
    borderColor:'#fff',
    justifyContent: 'center',
    alignItems: 'center',
  }

});
