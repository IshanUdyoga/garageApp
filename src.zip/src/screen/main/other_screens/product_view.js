import * as React from 'react';
import {processColor,Scrollview,Slider,StatusBar, Text, View, StyleSheet,Dimensions,TouchableOpacity,Image,AsyncStorage,ScrollView,FlatList,ImageBackground,TextInput,Keyboard,LayoutAnimation,UIManager } from 'react-native';
import Modal from "react-native-modal";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons'
import Line_Chart from '../charts/line_Chart'
import Pie_Chart from '../charts/pie_Chart'
import Meter_chart from '../charts/meter_chart'
import Multi_line_chart from '../charts/multi_line_chart'
import update from 'immutability-helper';
import Toast, {DURATION} from 'react-native-easy-toast'
import Policy_slider from '../components/policy_slider'
import Btm_detail_menu from '../components/btm_detail_menu'


let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width



export default class Product_view extends React.Component {

  constructor(props) {

    super(props);
   
    

    this.state = {
      policy_year:10,
      meter_val:0,
      product_view:false,
      refreshing:true,
      prod_data:[],
      policy_data:[],
      prod_id:'',
      cat_id:'',

      total_surr_val:'-',
      guar_cash_val:'-',
      non_guar_cash_val:'-',
      total_return:'-',
      total_de_benifit:'-',
      irr:'-',

      data:{
            $set: {
                  dataSets: [{
                    values: [{x: 4, y: 8}, {x: 5, y: 5}, {x: 6, y: 5}, {x: 7, y: 8}], label: 'A', config: { color: processColor('red'),drawFilled: true,fillColor: processColor('red'), },
                  }, {
                    values: [{x: 4, y: 105}, {x: 5, y: 90}, {x: 6, y: 130}, {x: 7, y: 100}], label: 'B',config: { color: processColor('blue'),drawFilled: true,fillColor: processColor('blue'), }
                  }, ],
                }
          }
    }

            }


    componentDidMount () {


    }

    th_sp(val){
      //separate number with comma
      try{
       return(val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
      }catch(e){
        return('')
      }
    }



itemSelect(){
      this.props.itemSelect(this.props.Selected_Item)
      this.setState({ product_view: false })
 }



open=(prod_id,cat_id)=>{
      this.setState({prod_id,cat_id,product_view: true })
      this.fetch_prod_data(prod_id)
}

close=()=>{
    this.filter_data(10)
    this.setState({
      total_surr_val:'-',
      guar_cash_val:'-',
      non_guar_cash_val:'-',
      total_return:'-',
      total_de_benifit:'-',
      irr:'-',
      product_view: false,
      policy_year:10
    })

     
}


fetch_prod_data= async(prod_id)=>{
      this.setState({refreshing:true})
      fetch(`http://192.168.9.103:80/garage/get_policy_prod_data.php?prod_id=${prod_id}`, {
        method: 'GET'
          })
          .then((response) => response.json())
          .then((responseJson) => {
                
          if(responseJson !== 'No'){
            this.setState({prod_data:responseJson,refreshing:false})
            this.filter_data(10)
            this.set_chart_data(responseJson)
          }else{
            this.setState({prod_data:[],refreshing:false}) 
          }
           
          })
          .catch((error) => {
            alert('Something went wrong please check your internet connection !')
              this.setState({refreshing:false})
          });

          
}

set_Policy=(val)=>{
      this.setState({policy_year:val})
}

filter_data=(val)=>{
 var arr=[] 
 arr = this.state.prod_data.filter(function(itemx){return itemx.policy_year == val;}) 

      this.get_savings_values(arr[0])
 
}

show_toast=(val)=>{
if(val === 'add'){
      this.refs.toast.show('Added to Bookmark');
}else{
      this.refs.toast.show('Removed from Bookmark');
}
}

get_savings_values(arr){
     // alert(arr.total_surren_amt)
      try{if(arr.total_surren_amt === undefined || arr.total_surren_amt == null){ this.setState({total_surr_val:'-'}) }else{ this.setState({total_surr_val:'$' + arr.total_surren_amt}) } }catch(e){ this.setState({total_surr_val:'-'})}

            try{ if(arr.guaran_amt === undefined || arr.guaran_amt == null){ this.setState({guar_cash_val:'-'}) }else{  this.setState({guar_cash_val:'$' + arr.guaran_amt}) } }catch(e){ this.setState({guar_cash_val:'-'}) }

                  try{ if(arr.nonguaran_amt === undefined || arr.nonguaran_amt == null){ this.setState({non_guar_cash_val:'-'}) }else{ this.setState({non_guar_cash_val:'$' + arr.nonguaran_amt}) } }catch(e){ this.setState({non_guar_cash_val:'-'}) }

                        try{ if(arr.total_return === undefined || arr.total_return == null){ this.setState({total_return:'-'}) }else{ this.setState({total_return:arr.total_return + '%'}) } }catch(e){ this.setState({total_return:'-'}) }


                              try{ if(arr.total_death_benefit === undefined || arr.total_death_benefit == null){ this.setState({total_de_benifit:'-'}) }else{ this.setState({total_de_benifit:arr.total_death_benefit + '%'}) } }catch(e){ this.setState({total_de_benifit:'-'}) }

                                    try{ if(arr.irr_amt === undefined || arr.irr_amt == null){  this.setState({irr:'-'}) }else{ this.setState({irr:arr.irr_amt + '%'}) } }catch(e){ this.setState({irr:'-'})  }
}



get_chart_values = async () =>{
      var data_arr_irr = []
      var data_arr_gar_surr = []
      var data_arr_non_surr = []
      var arr_length = 120
      var i;
      var a= 1;
           for(i=0; i < arr_length ; i++){
           var lbl_val = a;
           var arr = this.state.prod_data.filter(function(itemx){return itemx.age == lbl_val;})
           if(arr.length !== 0){
                 const val_irr = {x: lbl_val, y: parseFloat(arr[0].irr_amt)}
                 const val_surr = {x: lbl_val, y: parseFloat(arr[0].guaran_amt)}
                 const val_non_surr = {x: lbl_val, y: parseFloat(arr[0].nonguaran_amt)}
                 
                 data_arr_irr.push(val_irr)
                 data_arr_gar_surr.push(val_surr)
                 data_arr_non_surr.push(val_non_surr)
           }else{
           }
            a++
       }
       return [data_arr_irr,data_arr_gar_surr,data_arr_non_surr]
}


set_chart_data =async (responseJson) =>{
   // alert(responseJson.length)
    
   var chart_vals = await this.get_chart_values()
   var irr_values = chart_vals[0]
   var surr_values = chart_vals[1]
   var non_surr_values = chart_vals[2]
     
          this.setState(
            update(this.state, {
              data: {
                $set: {
                  dataSets: [{
                        values: non_surr_values, label: 'Non-guaranteed',config: { color: processColor('blue'),drawFilled: true,fillColor: processColor('blue'), }
                               },
                               {
                              values: surr_values, label: 'Guaranteed',config: { color: processColor('yellow'),drawFilled: true,fillColor: processColor('yellow'), }
                                           },
                        {
                        values: irr_values, label: 'IRR', config: { color: processColor('red'),drawFilled: true,fillColor: processColor('red'),fillAlpha: 99, },
                      },  ],
                }
              }
            })
          ); 
}


components_view(){
 const {cat_id,Selected_Item} = this.props
 if(cat_id === '1'){
        return(
          <ScrollView style={{width:'100%'}}>
            <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
                <View style={styles.faded_container}>
                  <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                        <Icon name='ios-arrow-back' style={styles.icon_style} />
                  </TouchableOpacity>

                  <View style={styles.title_container}>
                      <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
                  </View>


                  <View style={styles.plan_container}>
                        <View style={styles.highlight_txt_container}>
                              <View style={styles.txt_highlight_row_1}>
                                <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                                </View>

                                <View style={styles.txt_highlight_other_rows}>
                                <Text style={styles.plansTxts}>1. Inherit your wealth</Text>

                                <Text style={styles.plansTxts}>2. Grow potential wealth</Text>

                                <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>

                                <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                              </View>
                
                        </View>
                  </View>


                </View>
            </ImageBackground>



            <View style={styles.body_container}>
                <View style={styles.body_con_main}>
                        <View style={styles.body_header}>
                              <View style={styles.body_h_1}>
                                    {/* <View style={styles.sub_rows}>
                                      <Text>Age: {this.props.age} </Text>
                                    </View> */}

                                    <View style={styles.sub_rows}>
                                    <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                                    <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                                    </View>

                                    <View style={styles.sub_rows}>
                                    <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                                    <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                                    </View>

                                    <View style={styles.sub_rows}>
                                        <Image source={{ uri: `asset:/images/img_icons/insu.png`}} style={styles.title_icon_St} />
                                        <Text style={styles.btmTXT}>Insured Age: {this.props.age + this.state.policy_year}</Text>
                                        </View>
                              </View>

                              <View style={styles.body_h_2}>
                                        <View style={styles.sub_rows}>
                                        <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                        <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                        </View>

                                        <View style={styles.sub_rows}>
                                        <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                        <Text style={styles.btmTXT} numberOfLines={1}>Annual Premium: ${this.th_sp(this.props.annual_premium)}</Text>
                                        </View>
                              </View>
                        </View>

                        <View style={styles.body_bottom}>


                                  <View style={styles.btm_m_row2}>
                                        <View style={{flex:0.6}}>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Total Surrender Value</Text>    
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Guaranteed Cash Value</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Non-guaranteed Cash Value</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Total Return</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Death Benifit</Text>
                                          </View>

                                          <View style={[styles.btm_m_row_sub,{backgroundColor:'#fff9ba'}]}>
                                          <Text style={styles.table_txt}>IRR</Text>
                                          </View>

                                        </View>


                                        <View style={{flex:0.4}}>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>{this.th_sp(this.state.total_surr_val)}</Text>    
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>{this.th_sp(this.state.guar_cash_val)}</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>{this.th_sp(this.state.non_guar_cash_val)}</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>{this.state.total_return}</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>{this.state.total_de_benifit}</Text>
                                          </View>

                                          <View style={[styles.btm_m_row_sub2,{backgroundColor:'#fff37a'}]}>
                                                <Text style={styles.table_txt}>{this.state.irr}</Text>
                                          </View>

                                          </View>

                                        
                                  </View>
                        </View>


                        <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>



                        <View style={{marginBottom:hp('2%')}}>
                        <Multi_line_chart  chart_data = {this.state.data} isRightYEnabled={true}/>         
                        </View>


                       

                </View>
            </View>

            <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
        </ScrollView>
        )
 }else if(cat_id === '2'){
  return(
    <ScrollView style={{width:'100%'}}>
      <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
          <View style={styles.faded_container}>
            <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                  <Icon name='ios-arrow-back' style={styles.icon_style} />
            </TouchableOpacity>

            <View style={styles.title_container}>
                <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
            </View>


            <View style={styles.plan_container}>
                  <View style={styles.highlight_txt_container}>
                        <View style={styles.txt_highlight_row_1}>
                          <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                          </View>

                          <View style={styles.txt_highlight_other_rows}>
                          <Text style={styles.plansTxts}>1. Inherit your wealth</Text>

                          <Text style={styles.plansTxts}>2. Grow potential wealth</Text>

                          <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>

                          <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                        </View>
          
                  </View>
            </View>


          </View>
      </ImageBackground>



      <View style={styles.body_container}>
          <View style={styles.body_con_main}>
                  <View style={styles.body_header}>
                        <View style={styles.body_h_1}>
                              {/* <View style={styles.sub_rows}>
                                <Text>Age: {this.props.age} </Text>
                              </View> */}

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/insu.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Insured Age: 65</Text>
                                  </View>
                        </View>

                        <View style={styles.body_h_2}>
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                  </View>

                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Sum Insured: USD${this.th_sp(this.props.sum_insured)}</Text>
                                  </View>

                                  

                        </View>
                  </View>

                  <View style={styles.body_bottom}>


                            <View style={styles.btm_m_row2}>
                                  <View style={{flex:0.6}}>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Surrender Value</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total return of Surrender Value</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Death Benifit</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Return of Death Benifit</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub,{backgroundColor:'#fff9ba'}]}>
                                    <Text style={styles.table_txt}>IRR of Death Benifit</Text>
                                    </View>


                                  </View>


                                  <View style={{flex:0.4}}>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub2,{backgroundColor:'#fff37a'}]}>
                                           <Text style={styles.table_txt}>5000</Text>
                                    </View>

                                  </View>

                                  
                            </View>
                  </View>

                  <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>

                  

                            {/* <View style={styles.btm_m_row4}>
                            <TouchableOpacity style={styles.comp_btn} onPress={()=> this.itemSelect()}><Text>Compare</Text></TouchableOpacity >
                            </View> */}



          </View>
      </View>

      <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
  </ScrollView>
  )
 }else if(cat_id === '3'){
  return(
    <ScrollView style={{width:'100%'}}>
      <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
          <View style={styles.faded_container}>
            <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                  <Icon name='ios-arrow-back' style={styles.icon_style} />
            </TouchableOpacity>

            <View style={styles.title_container}>
                <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
            </View>


            <View style={styles.plan_container}>
                  <View style={styles.highlight_txt_container}>
                        <View style={styles.txt_highlight_row_1}>
                          <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                          </View>

                          <View style={styles.txt_highlight_other_rows}>
                          <Text style={styles.plansTxts}>1. Inherit your wealth</Text>

                          <Text style={styles.plansTxts}>2. Grow potential wealth</Text>

                          <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>

                          <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                        </View>
          
                  </View>
            </View>


          </View>
      </ImageBackground>



      <View style={styles.body_container}>
          <View style={styles.body_con_main}>
                  <View style={styles.body_header}>
                        <View style={styles.body_h_1}>
                              {/* <View style={styles.sub_rows}>
                                <Text>Age: {this.props.age} </Text>
                              </View> */}

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/insu.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Insured Age: 65</Text>
                                  </View>
                        </View>

                        <View style={styles.body_h_2}>
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                  </View>

                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Sum Insured: USD${this.props.sum_insured}</Text>
                                  </View>
                        </View>
                  </View>

                  <View style={styles.body_bottom}>


                            <View style={styles.btm_m_row2}>
                                  <View style={{flex:0.6}}>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Guaranteed income</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Income</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Guaranteed Surrender value</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Surrender value</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Death Benifit</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total Return</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub,{backgroundColor:'#fff9ba'}]}>
                                    <Text style={styles.table_txt}>IRR of Total Return</Text>
                                    </View>


                                  </View>


                                  <View style={{flex:0.4}}>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub2,{backgroundColor:'#fff37a'}]}>
                                           <Text style={styles.table_txt}>5000</Text>
                                    </View>

                                  </View>

                                  
                            </View>
                  </View>


                       <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>

                            {/* <View style={styles.btm_m_row4}>
                            <TouchableOpacity style={styles.comp_btn} onPress={()=> this.itemSelect()}><Text>Compare</Text></TouchableOpacity >
                            </View> */}



          </View>
      </View>
      <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
    
  </ScrollView>
  )
 }else if(cat_id === '4'){
  return(
    <ScrollView style={{width:'100%'}}>
      <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
          <View style={styles.faded_container}>
            <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                  <Icon name='ios-arrow-back' style={styles.icon_style} />
            </TouchableOpacity>

            <View style={styles.title_container}>
                <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
            </View>


            <View style={styles.plan_container}>
                  <View style={styles.highlight_txt_container}>
                        <View style={styles.txt_highlight_row_1}>
                          <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                          </View>

                          <View style={styles.txt_highlight_other_rows}>
                          <Text style={styles.plansTxts}>1. Inherit your wealth</Text>

                          <Text style={styles.plansTxts}>2. Grow potential wealth</Text>

                          <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>

                          <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                        </View>
          
                  </View>
            </View>


          </View>
      </ImageBackground>



      <View style={styles.body_container}>
          <View style={styles.body_con_main}>
                  <View style={styles.body_header}>
                        <View style={styles.body_h_1}>
                              {/* <View style={styles.sub_rows}>
                                <Text>Age: {this.props.age} </Text>
                              </View> */}

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/insu.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Insured Age: 65</Text>
                                  </View>
                        </View>

                        <View style={styles.body_h_2}>
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                  </View>

                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Sum Insured: USD${this.props.sum_insured}</Text>
                                  </View>
                        </View>
                  </View>

                  <View style={styles.body_bottom}>


                            <View style={styles.btm_m_row2}>
                                  <View style={{flex:0.6}}>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Guaranteed major Illness/death benefit</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Non-guaranteed major Illness/death
                                                                                      benefit</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total major Illness/death benefit</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Total return of major Illness/death
                                                                                        benefit </Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub,{backgroundColor:'#fff9ba'}]}>
                                    <Text style={styles.table_txt}>IRR of major illness/death benefit</Text>
                                    </View>


                                  </View>


                                  <View style={{flex:0.4}}>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub2,{backgroundColor:'#fff37a'}]}>
                                           <Text style={styles.table_txt}>5000</Text>
                                    </View>

                                  </View>

                                  
                            </View>
                  </View>

                  <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>

                            {/* <View style={styles.btm_m_row4}>
                            <TouchableOpacity style={styles.comp_btn} onPress={()=> this.itemSelect()}><Text>Compare</Text></TouchableOpacity >
                            </View> */}



          </View>
      </View>

      <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
  </ScrollView>
  )
 }else if(cat_id === '5'){
  return(
    <ScrollView style={{width:'100%'}}>
      <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
          <View style={styles.faded_container}>
            <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                  <Icon name='ios-arrow-back' style={styles.icon_style} />
            </TouchableOpacity>

            <View style={styles.title_container}>
                <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
            </View>


            <View style={styles.plan_container}>
                  <View style={styles.highlight_txt_container}>
                        <View style={styles.txt_highlight_row_1}>
                          <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                          </View>

                          <View style={styles.txt_highlight_other_rows}>
                          <Text style={styles.plansTxts}>1. Inherit your wealth</Text>

                          <Text style={styles.plansTxts}>2. Grow potential wealth</Text>

                          <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>

                          <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                        </View>
          
                  </View>
            </View>


          </View>
      </ImageBackground>



      <View style={styles.body_container}>
          <View style={styles.body_con_main}>
                  <View style={[styles.body_header,{height:hp('10%'),alignItems: 'center',}]}>
                        <View style={[styles.body_h_1,{}]}>
                              {/* <View style={styles.sub_rows}>
                                <Text>Age: {this.props.age} </Text>
                              </View> */}

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                              </View>

                              <View style={styles.sub_rows}>
                              <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                              <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                              </View>
                        </View>

                        <View style={styles.body_h_2}>
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                  </View>

                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>Sum Insured: USD${this.props.sum_insured}</Text>
                                  </View>


                        </View>
                  </View>

                  <View style={[styles.body_bottom,{marginBottom:hp('3%')}]}>

                  <View style={styles.btm_m_row2}>
                                  <View style={{flex:0.6}}>

                                  <View style={[styles.btm_m_row_sub,{backgroundColor:'#d3f7ff'}]}>
                                    <Text style={styles.table_txt}>Maximum Limit (Per year)</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub,{backgroundColor:'#d3f7ff'}]}>
                                    <Text style={styles.table_txt}>Lifetime Limit</Text>
                                    </View>


                                  </View>


                                  <View style={{flex:0.4}}>

                                   
                                  <View style={[styles.btm_m_row_sub2,{backgroundColor:'#bcf2ff'}]}>
                                           <Text style={styles.table_txt}>5000</Text>
                                    </View>

                                    <View style={[styles.btm_m_row_sub2,{backgroundColor:'#bcf2ff'}]}>
                                           <Text style={styles.table_txt}>5000</Text>
                                    </View>

                                  </View>

                                  
                            </View>


                            <Text style={styles.title_St}>Hospital Benifit</Text>

                            <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                  <View style={{flex:0.6}}>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Room & board</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Miscellaneous hospital service</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Intensive Care</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Private Nursing </Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                    <Text style={styles.table_txt}>In-patient Physican’ s fees</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                    <Text style={styles.table_txt}>In-patient Specialist’s Fees</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                    <Text style={styles.table_txt}>Companion Bed</Text>
                                    </View>


                                  </View>


                                  <View style={{flex:0.4}}>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>


                                  </View>

                                  </View>

                                  <Text style={styles.title_St}>Surgical Benefit:</Text>

                            <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                  <View style={{flex:0.6}}>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Surgeon and attendance fees</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Anaesthetist’ s fees</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Operating Theatres Fees</Text>
                                    </View>

                                  </View>


                                  <View style={{flex:0.4}}>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    <View style={styles.btm_m_row_sub2}>
                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                    </View>

                                    </View>

                           
                            </View>



                            <Text style={styles.title_St}>Other Medical Benefit:</Text>

                                  <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                        <View style={{flex:0.6}}>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Cancer Treatment and Kidney Dialysis</Text>    
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Daily post-surgery home nursing benefit</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Pre-admission and Post-hospitalisation Out-patient Care</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                                <Text style={styles.table_txt}>Emergency Out-patient Benefit for Accident</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Chiropractor / Physiotherapist Consultation</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Mental or nervous disorder benefit</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub}>
                                          <Text style={styles.table_txt}>Long term treatment for chemotherapy (including targeted therapy), radiotherapy and dialysis</Text>
                                          </View>

                                        </View>


                                        <View style={{flex:0.4}}>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>

                                          <View style={styles.btm_m_row_sub2}>
                                                <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                          </View>


                                        </View>

                                        </View>



                                        <Text style={styles.title_St}>Other Benefits:</Text>

                                        <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                              <View style={{flex:0.6}}>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Top-up subsidy benefit</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Compassionate death benefit</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Accidental death benefit</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Blood donation benefit</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Medical accident and incident extension benefit</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub}>
                                                      <Text style={styles.table_txt}>Worldwide emergency assistance services</Text>    
                                                </View>


                                              </View>


                                              <View style={{flex:0.4}}>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={styles.btm_m_row_sub2}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                </View>


                                        </View>




                                        {/* <Text style={styles.title_St}>Other Benefits:</Text> */}

                                          <View style={[styles.btm_m_row2,{marginTop:hp('3%')}]}>
                                                <View style={{flex:0.6,}}>

                                                <View style={[styles.btm_m_row_sub,{backgroundColor: '#ddeaff'}]}>
                                                      <Text style={[styles.table_txt,{fontWeight:'bold'}]}>Maximum Limit (per year)</Text>    
                                                </View>

                                                </View>


                                                <View style={{flex:0.4}}>

                                                <View style={[styles.btm_m_row_sub2,{backgroundColor: '#b2d1ff'}]}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                </View>


                                          </View>


                                          <Text style={styles.title_St}>Supplemental Major Medical Benefits Rider (SMM)</Text>

                                          <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                                <View style={{flex:0.6}}>

                                                <View style={[styles.btm_m_row_sub,{backgroundColor: '#ffb68e'}]}>
                                                      <Text style={styles.table_txt}>Maximum Limit (per year)</Text>    
                                                </View>

                                                <View style={[styles.btm_m_row_sub,{backgroundColor: '#ffb68e'}]}>
                                                      <Text style={styles.table_txt}>Lifetime Limit</Text>    
                                                </View>

                                                </View>


                                                <View style={{flex:0.4}}>

                                                <View style={[styles.btm_m_row_sub2,{backgroundColor: '#ffa472'}]}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                <View style={[styles.btm_m_row_sub2,{backgroundColor: '#ffa472'}]}>
                                                      <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                </View>

                                                </View>


                                          </View>


                                        



                  </View>
     

               

          </View>
      </View>

      <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
  </ScrollView>
  )
 }else if(cat_id === '6'){
      return(
        <ScrollView style={{width:'100%'}}>
          <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
              <View style={styles.faded_container}>
                <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                      <Icon name='ios-arrow-back' style={styles.icon_style} />
                </TouchableOpacity>
    
                <View style={styles.title_container}>
                    <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
                </View>
    
    
                <View style={styles.plan_container}>
                      <View style={styles.highlight_txt_container}>
                            <View style={styles.txt_highlight_row_1}>
                              <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                              </View>
    
                              <View style={styles.txt_highlight_other_rows}>
                              <Text style={styles.plansTxts}>1. Inherit your wealth</Text>
    
                              <Text style={styles.plansTxts}>2. Grow potential wealth</Text>
    
                              <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>
    
                              <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                            </View>
              
                      </View>
                </View>
    
    
              </View>
          </ImageBackground>
    
    
    
          <View style={styles.body_container}>
              <View style={styles.body_con_main}>
                      <View style={[styles.body_header,{height:hp('10%'),alignItems: 'center',}]}>
                            <View style={[styles.body_h_1,{}]}>
                                  {/* <View style={styles.sub_rows}>
                                    <Text>Age: {this.props.age} </Text>
                                  </View> */}
    
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                                  </View>
    
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                                  </View>
                            </View>
    
                            <View style={styles.body_h_2}>
                                      <View style={styles.sub_rows}>
                                      <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                      <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                      </View>
    
                                      <View style={styles.sub_rows}>
                                      <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                      <Text style={styles.btmTXT}>Sum Insured: USD${this.props.sum_insured}</Text>
                                      </View>
    
    
                            </View>
                      </View>
    
                      <View style={[styles.body_bottom,{ marginBottom:hp('3%')}]}>
    
                      <View style={styles.btm_m_row2}>
                                      <View style={{flex:0.6}}>
    
                                      <View style={[styles.btm_m_row_sub,{backgroundColor:'#d3f7ff'}]}>
                                        <Text style={styles.table_txt}>Maximum Limit (Per year)</Text>
                                        </View>
    
                                        <View style={[styles.btm_m_row_sub,{backgroundColor:'#d3f7ff'}]}>
                                        <Text style={styles.table_txt}>Lifetime Limit</Text>
                                        </View>
    
    
                                      </View>
    
    
                                      <View style={{flex:0.4}}>
    
                                       
                                      <View style={[styles.btm_m_row_sub2,{backgroundColor:'#bcf2ff'}]}>
                                               <Text style={styles.table_txt}>5000</Text>
                                        </View>
    
                                        <View style={[styles.btm_m_row_sub2,{backgroundColor:'#bcf2ff'}]}>
                                               <Text style={styles.table_txt}>5000</Text>
                                        </View>
    
                                      </View>
    
                                      
                                </View>
    
    
                                <Text style={styles.title_St}>Hospital Benifit</Text>
    
                                <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                      <View style={{flex:0.6}}>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Room & board</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Miscellaneous hospital service</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Intensive Care</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Private Nursing </Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                        <Text style={styles.table_txt}>In-patient Physican’ s fees</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                        <Text style={styles.table_txt}>In-patient Specialist’s Fees</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                        <Text style={styles.table_txt}>Companion Bed</Text>
                                        </View>
    
    
                                      </View>
    
    
                                      <View style={{flex:0.4}}>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
    
                                      </View>
    
                                      </View>
    
                                      <Text style={styles.title_St}>Surgical Benefit:</Text>
    
                                <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                      <View style={{flex:0.6}}>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Surgeon and attendance fees</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Anaesthetist’ s fees</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Operating Theatres Fees</Text>
                                        </View>
    
                                      </View>
    
    
                                      <View style={{flex:0.4}}>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        </View>
    
                               
                                </View>
    
    
    
                                <Text style={styles.title_St}>Other Medical Benefit:</Text>
    
                                      <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                            <View style={{flex:0.6}}>
    
                                              <View style={styles.btm_m_row_sub}>
                                                    <Text style={styles.table_txt}>Cancer Treatment and Kidney Dialysis</Text>    
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                                    <Text style={styles.table_txt}>Daily post-surgery home nursing benefit</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                                    <Text style={styles.table_txt}>Pre-admission and Post-hospitalisation Out-patient Care</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                                    <Text style={styles.table_txt}>Emergency Out-patient Benefit for Accident</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Chiropractor / Physiotherapist Consultation</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Mental or nervous disorder benefit</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Long term treatment for chemotherapy (including targeted therapy), radiotherapy and dialysis</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>HIV / AIDS treatment benefit</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Reconstructive surgery benefit</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Stroke rehabilitation benefit</Text>
                                              </View>
    
                                            </View>
    
    
                                            <View style={{flex:0.4}}>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>

                                              <View style={styles.btm_m_row_sub2}>
                                                    <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                              </View>
    
    
                                            </View>
    
                                            </View>
    
    
    
                                            <Text style={styles.title_St}>Other Benefits:</Text>
    
                                            <View style={[styles.btm_m_row2,{marginTop:hp('0%')}]}>
                                                  <View style={{flex:0.6}}>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Top-up subsidy benefit</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Compassionate death benefit</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Accidental death benefit</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Blood donation benefit</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Medical accident and incident extension benefit</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub}>
                                                          <Text style={styles.table_txt}>Worldwide emergency assistance services</Text>    
                                                    </View>
    
    
                                                  </View>
    
    
                                                  <View style={{flex:0.4}}>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    <View style={styles.btm_m_row_sub2}>
                                                          <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                                    </View>
    
                                                    </View>
    
    
                                            </View>
    
    
    
    
                      </View>
         
                      
                   
    
              </View>
          </View>
    
          <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
      </ScrollView>
      )
     }else if(cat_id === '7'){
      return(
        <ScrollView style={{width:'100%'}}>
          <ImageBackground style={styles.header_container}  source={{uri:Selected_Item.p_img_url == null ? 'https://cdn1.iconfinder.com/data/icons/social-17/48/photos2-512.png' : Selected_Item.p_img_url}} >
              <View style={styles.faded_container}>
                <TouchableOpacity style={styles.back_icon} onPress={()=> this.close()}>
                      <Icon name='ios-arrow-back' style={styles.icon_style} />
                </TouchableOpacity>
    
                <View style={styles.title_container}>
                    <Text style={styles.title_style} numberOfLines={1}>{Selected_Item.p_name}</Text>
                </View>
    
    
                <View style={styles.plan_container}>
                      <View style={styles.highlight_txt_container}>
                            <View style={styles.txt_highlight_row_1}>
                              <Text style={styles.txt_h_row1}>PLAN HIGHLIGHTS:</Text>
                              </View>
    
                              <View style={styles.txt_highlight_other_rows}>
                              <Text style={styles.plansTxts}>1. Inherit your wealth</Text>
    
                              <Text style={styles.plansTxts}>2. Grow potential wealth</Text>
    
                              <Text style={styles.plansTxts}>3. Easy Withdrawal</Text>
    
                              <Text style={styles.plansTxts}>4. Flexible cash access</Text>
                            </View>
              
                      </View>
                </View>
    
    
              </View>
          </ImageBackground>
    
    
    
          <View style={styles.body_container}>
              <View style={styles.body_con_main}>
                      <View style={styles.body_header}>
                            <View style={styles.body_h_1}>
                                  {/* <View style={styles.sub_rows}>
                                    <Text>Age: {this.props.age} </Text>
                                  </View> */}
    
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: this.props.gender_value === 1 ? 'asset:/images/img_icons/male.png' : 'asset:/images/img_icons/female.png'}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>{this.props.gender_value === 1 ? 'Male' : 'Female'}</Text>
                                  </View>
    
                                  <View style={styles.sub_rows}>
                                  <Image source={{ uri: `asset:/images/img_icons/smoking.png`}} style={styles.title_icon_St} />
                                  <Text style={styles.btmTXT}>{this.props.smk_value === 1 ? 'Smoking' : 'Non-Smoking'}</Text>
                                  </View>

                                  <View style={styles.sub_rows}>
                                      <Image source={{ uri: `asset:/images/img_icons/insu.png`}} style={styles.title_icon_St} />
                                      <Text style={styles.btmTXT}>Insured Age: 65</Text>
                                      </View>
                            </View>
    
                            <View style={styles.body_h_2}>
                                      <View style={styles.sub_rows}>
                                      <Image source={{ uri: `asset:/images/img_icons/payments.png`}} style={styles.title_icon_St} />
                                      <Text style={styles.btmTXT}>Payment Terms: {this.props.paym_tm} Years</Text>
                                      </View>
    
                                      <View style={styles.sub_rows}>
                                      <Image source={{ uri: `asset:/images/img_icons/sumins.png`}} style={styles.title_icon_St} />
                                      <Text style={styles.btmTXT}>Sum Insured: USD${this.props.sum_insured}</Text>
                                      </View>
    
                            </View>
                      </View>
    
                      <View style={styles.body_bottom}>
    
    
                                <View style={styles.btm_m_row2}>
                                      <View style={{flex:0.6}}>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Total Surrender Value</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Guaranteed Cash Value</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Non-guaranteed cash value</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Total Return</Text>
                                        </View>

                                        <View style={styles.btm_m_row_sub}>
                                              <Text style={styles.table_txt}>Total Death Benefit</Text>
                                        </View>
    
                                        <View style={[styles.btm_m_row_sub,{backgroundColor:'#fff9ba'}]}>
                                        <Text style={styles.table_txt}>IRR</Text>
                                        </View>
    
    
                                      </View>
    
    
                                      <View style={{flex:0.4}}>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>    
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>

                                        <View style={styles.btm_m_row_sub2}>
                                              <Text style={styles.table_txt}>10000 ~ 2555</Text>
                                        </View>
    
                                        <View style={[styles.btm_m_row_sub2,{backgroundColor:'#fff37a'}]}>
                                               <Text style={styles.table_txt}>5000</Text>
                                        </View>
    
                                      </View>
    
                                      
                                </View>
                      </View>
    
                           
                           
                        <Pie_Chart  />
    
                           <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>

                        <Meter_chart  meter_val = {this.state.meter_val}/>
      
    
                                    <View style={[styles.btm_m_row3,{marginBottom:hp('3%')}]}>
                                                <View style={styles.btm_m_col}>

                                                </View>

                                                <View style={styles.btm_m_col2}>
                                                <Text  style={styles.policy_txt}>At the {this.state.meter_val}th Policy</Text>
                                                      <Slider
                                                      style={{ width: '100%' }}
                                                      step={5}
                                                      minimumValue={0}
                                                      maximumValue={100}
                                                      value={this.state.meter_val}
                                                      onValueChange={val => this.setState({ meter_val: val })}
                                                      //onSlidingComplete={ val => this.getVal(val)}
                                                      />   

                                                      <Text style={styles.drag_txt} numberOfLines={1} >Drag the button to review the performance at different policy year</Text>        
                                                </View>

                                                <View style={styles.btm_m_col}>

                                                </View>
                                          </View>
    
                                {/* <View style={styles.btm_m_row4}>
                                <TouchableOpacity style={styles.comp_btn} onPress={()=> this.itemSelect()}><Text>Compare</Text></TouchableOpacity >
                                </View> */}
    
              </View>
          </View>
          
          <Btm_detail_menu prod_uid={this.state.prod_id} cat_id={this.state.cat_id } show_toast={this.show_toast}/>
      </ScrollView>
      )
     }

}




  render() {
    return (
        <Modal style = {{  margin: 0 }} isVisible={this.state.product_view} 
            animationIn={'slideInRight'} animationOut={'slideOutLeft'} hasBackdrop={false} onRequestClose={()=>this.close()}>
         
        <View style={styles.container} >
          {this.components_view()}
          <Toast ref="toast"/>
        </View>
      
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems:'center',
    backgroundColor:'#fff'
  },

  textHeading: { 
      color: '#7a7a7a',
      fontFamily: 'ERASDEMI',
   fontSize: hp('4.5%'), 
   textAlign: 'center' 
},

  img: { 
    width: hp('10%'), 
    height: hp('10%'), 
    marginTop: hp('4.5%')
},

  elementContainer: {
    width: '100%',
    marginTop: hp('4.5%'),
    alignItems: 'center',
  },

  text: 
  { 
    color: '#7a7a7a',
  fontSize: hp('3.5%') ,
  fontFamily: 'ERASDEMI',
},

  saparator: {
    height: 0.5,
    width: '60%',
    backgroundColor: '#C2C2C2',
    marginTop: hp('1.7%'),
  },

  header_container:{
    height:hp('23%'),
    width:'100%',
    backgroundColor: '#ddd',
  },

  body_container:{
    width:'100%',
    paddingHorizontal: wp('5%'),
    backgroundColor: '#F4F4F4',
  },


  body_con_main:{
      height:'100%',
      width:'100%',
      flex:1,
      backgroundColor: '#fff',
      borderRadius: hp('1%'),
      marginTop: hp('3%'),
      paddingHorizontal:wp('2%'),
      paddingTop: hp('2%'),
  },

  faded_container:{
    height:'100%',
    width:'100%',
    alignItems: 'center',
    backgroundColor:'rgba(255, 255, 255, 0.80)'
  },

  back_icon:{
    position:'absolute',
    justifyContent: 'center',
    paddingLeft:wp('3%'),
    left:0,
    height:hp('8%'),
    width:hp('8%'),
  },
  title_container:{
    position:'absolute',
    width:'85%',
    alignItems:'center',
    top:'15%'
  },

  title_style:{
  fontSize:hp('3.5%'),
  color:'#888'
  },

  plan_container:{
    position:'absolute',
    bottom:0,
    width:'50%',
    height:'58%',
    backgroundColor: '#EB7CA5',
    borderTopRightRadius: hp('1%'),
    borderTopLeftRadius: hp('1%'),
    opacity:0.8
  },

  highlight_txt_container:{
    height:'100%',
    width:'100%',
    flex:1
  },

  txt_highlight_row_1:{
    flex:0.27,
    justifyContent: 'center',
    alignItems: 'center',
  },

  txt_highlight_other_rows:{
    flex:0.73,
    paddingLeft: wp('8%'),
    color:'#fff'
  },
  plansTxts:{
    fontSize:hp('1.5%'),
   color:'#fff',
  },
  txt_h_row1:{
    fontSize:hp('2%'),
    fontWeight: 'bold',
  },

  icon_style:{
    color:'#666',
    fontSize:hp('5%')
  },

  body_header:{
    height:hp('13%'),
    flexDirection: 'row',
  },

  body_h_1:{
    flex:0.35,
    

  },
  body_h_2:{
    flex:0.65,
  },

  body_bottom:{
  
  },

  sub_rows:{
    flex:0.33,
    flexDirection:'row',
    alignItems: 'center',
  },

  btm_m_row1:{
      flex:0.13,
      justifyContent: 'center',
      alignItems: 'center',
  },

  btm_m_row2:{
    flex:0.63,
    flexDirection:'row',
    //backgroundColor: '#ddd',
    marginTop:hp('2%')
  },

  btm_m_row3:{
    height:hp('12%'),
    flexDirection:'row',
    marginVertical: hp('2%'),
  },

  btm_m_row4:{
    height:hp('8%'),
    justifyContent: 'center',
    alignItems: 'center',
  },

  btm_m_con:{
    flex:0.5
  },


  btm_m_row_sub:{
    height:hp('7%'),
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#F1F1F1',
    marginBottom: hp('0.5%'),
},

btm_m_row_sub2:{
  height:hp('7%'),
  justifyContent: 'center',
  alignItems:'center',
  backgroundColor: '#E0DEDE',
  marginBottom: hp('0.5%'),
},

ins_txt:{
  fontSize:hp('2.5%'),
  fontWeight:'bold'
},

btm_m_col:{
  flex:0.1
},

btm_m_col2:{
  flex:0.8,
  justifyContent: 'center',
  alignItems:'center'
 
},

btm_m_col:{
  flex:0.1
},


drag_txt:{
  color:'red',
  fontSize:hp('1.5%'),
  textAlign:'center'
},

comp_btn:{
  height:'80%',
  width:'60%',
  justifyContent: 'center',
  alignItems: 'center',
  backgroundColor: '#5BD390',
  borderRadius:hp('1%')
},

btmTXT:{
  fontSize:hp('2%')
},

title_icon_St:{
  height:hp('4.5%'),
  width:hp('4.5%')
},

table_txt:{
  fontSize:hp('1.8%'),
  textAlign:'center'
},

title_St:{
  fontSize:hp('3%'),
  fontWeight:'bold',
  marginTop:hp('2%'),
  marginBottom:hp('1%')
},

lineCC:{
      marginTop:hp('2%'),
    marginBottom:hp('5%')  
},

policy_txt:{
      fontSize:hp('2%')
  }

 

});
