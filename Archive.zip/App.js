import * as React from 'react';
import { Text, View, StyleSheet,AsyncStorage } from 'react-native';
import Main from './Main'


 //AsyncStorage.clear()
export default class App extends React.Component {

  constructor(props) {
    super(props);
 
    this.state = {
      color:'#ddd',
      cat_data:[],
      cat_id:0,
      msgKey:''
    };
  }

  setColor =(color)=>{
    this.setState({color:color})
  }

  setCatData =(cat_data)=>{
    this.setState({cat_data:cat_data})
  }
 
  setCatId =(cat_id)=>{
    this.setState({cat_id:cat_id})
  }

  setMsgKey =(msgKey)=>{
    this.setState({msgKey:msgKey})
  }

  render() {
    return (
     <Main 
     screenProps={{
       ...this.state,
       setColor:this.setColor,
       setCatData:this.setCatData,
       setCatId:this.setCatId,
       setMsgKey:this.setMsgKey,
    }} 
    
      />
    );
  }
}