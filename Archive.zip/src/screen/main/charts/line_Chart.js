import * as React from 'react';
import { Text, View, StyleSheet,Dimensions } from 'react-native';
import {
  LineChart,
  BarChart,
  PieChart,
  ProgressChart,
  ContributionGraph
} from 'react-native-chart-kit'

const screenWidth = Dimensions.get('window').width

const data = {
  labels: ['5', '6', '7', '8', '9', '10','11','12','13','14','15','16','17','18','19','20','21','22'],
  datasets: [{
    data: [
      50,
      20,
      2,
      86,
      71,
      100
    ]
  }]
}

const chartConfig = {
  backgroundGradientFrom: '#1E2923',
  backgroundGradientTo: '#08130D',
  color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,
  strokeWidth: 2 // optional, default 3
}

export default class Line_Chart extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <LineChart
  data={this.props.chart_data}
  width={screenWidth-60}
  height={220}
  chartConfig={chartConfig}
/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
