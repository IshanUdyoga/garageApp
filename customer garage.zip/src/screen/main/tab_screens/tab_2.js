import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Animated,
  Alert,
  ScrollView,
  StatusBar,
  Dimensions,
  FlatList
} from 'react-native';

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width
import sort from 'fast-sort';

import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

import {Content, Accordion , ActionSheet, Button ,Header , Card,Thumbnail, Tab, Tabs, Left,CardItem,DatePicker,  Form, Item, Picker,Badge, Fab ,Body, Icon, Right,ListItem,List, CheckBox, Footer, FooterTab} from "native-base";

export default class Tab_2 extends Component {


  constructor (props) {

    super(props);


    this.state = {
        fadeBody:new Animated.Value(0),
        left:new Animated.Value(-deviceWidth/3),
        leftPro:new Animated.Value(-wp('60%')),
        PendingReply:false,
        is_toggled:false,
        loading:false, 
        question:'',
        user_name:'',
        time:'',
        image:'',
        uid:''

       
    };

}

SetValues(item){

      this.setState({PendingReply:true, user_name:item.user_name, question:item.question, time:item.time, image:item.img_url,uid:item.user_id})

}


  render() {
    return (
      <View style={styles.container}>
                      <FlatList 
                          style={{width:'100%'}}
                          
                          //data={this.props.req_data}

                         data={sort(this.props.res_data).desc(u => u.key)}

                         keyExtractor={(item, index) => item.key}

                          //ListEmptyComponent={this.emptymsgFun()}
                          //contentContainerStyle={styles.main_cat_LIST}
                          renderItem={({ item, index }) =>
                           <List >
                                  <ListItem avatar >
                                        <Left>
                                          <Thumbnail source={{uri : item.img_url}} />
                                        </Left>
                                        <Body>
                                          <Text style={styles.textsadeep}>{item.user_name}</Text>
                                          <Text note>{item.reply}</Text>
                                        </Body>
                                        <Right>
                                          <Text note>{item.time}</Text>
                                        </Right>
                                      </ListItem>
                            </List>
                           
                        }
                      //refreshing={this.state.refreshing}
                      // onRefresh={() => this.handleRefresh()}
                        />




      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  body:{
    flex:1
  },
  scrollSS:{
    width:'100%',
  },

});