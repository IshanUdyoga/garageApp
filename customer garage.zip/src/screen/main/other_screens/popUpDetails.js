import * as React from 'react';
import { StatusBar, Text, View, StyleSheet,Dimensions,TouchableOpacity,Image,AsyncStorage,ScrollView,FlatList,ImageBackground,TextInput,Keyboard,LayoutAnimation,UIManager } from 'react-native';
import Modal from "react-native-modal";

import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons';
import * as firebase from 'react-native-firebase';
import stringsoflanguages from '../../lng/stringsoflanguages';

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width

let deviceSH = Dimensions.get('screen').height;
let bottomNavBarH = deviceSH - deviceHeight;


var ITEM_WIDTH = wp('65%')
var offSET = wp('11.5%')

 export default class PopUpDetails extends React.Component {

  constructor(props) {

    super(props);
        this.state={
            text:'',
            cmtModal:false,
            readMoreMdl:false,
            data:[],
            refreshing:false,

            cat_id:'',
            cat_name:'',
            briefing_title:'',
            briefing_descrip_1:'',
            briefing_descrip_2:'',
            briefing_descrip_3:'',
            briefing_descrip_4:'',
            images:[],

            isEnterNick:false,
            nickname:'',
            img_url:'',
            img_title:'',
            img_des:''

                }


            }


    componentDidMount () {


    }

  componentWillMount(){

  }

th_sp(val){
  //separate number with comma
  try{
   return(val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
  }catch(e){
    return('')
  }
}


  mainFunc=(cat_id,cat_name,briefing_title,briefing_descrip_1,briefing_descrip_2,briefing_descrip_3,briefing_descrip_4)=>{
    this.setState({
      cat_id,
      cat_name,
      briefing_title,
      briefing_descrip_1,
      briefing_descrip_2,
      briefing_descrip_3,
      briefing_descrip_4,
      refreshing:true,
      cmtModal:true})
    
      this.fetchData(cat_id)

  }



  fetchData (cat_id){

    fetch(`http://192.168.9.103:80/garage/get_briefing.php?cat_id=${cat_id}`, {
              method: 'GET'
           })
           .then((response) => response.json())
           .then((responseJson) => {

             if(responseJson !== 'No'){
             
                 this.setState({images:responseJson,refreshing:false})
                 

             }else{
              this.setState({refreshing:false})
              
             }
     
              
           })
           .catch((error) => {
     
            alert('Something went wrong please check your internet connection !')
            this.setState({refreshing:false})
           });
   
  }







close(){
    this.setState({ cmtModal: false,images:[],readMoreMdl:false })
   
}



emptymsgFun(){
  if(this.state.refreshing){
    return(<View style={styles.emptyListPAD}>
            <Text style={styles.emptyTXT}>{stringsoflanguages.home.loading}</Text>
            <Icon name="ios-refresh" style={styles.EmtyIco} />
            </View>
            )
  }else{

      return(<View style={styles.emptyListPAD}>
            <Text style={styles.emptyTXT}>No Images..</Text>
            <Icon name="ios-alert" style={styles.EmtyIco} />
            </View>)
  }
}


oprenReadMore(img_url,img_title,img_des){
  this.setState({img_url,img_title,img_des,readMoreMdl:true})
}


navigate(){
  this.setState({ cmtModal: false,images:[] })
  this.props.Navi_brfi_to_filt()
}


flatlist_comp(){
  const cat_id = this.state.cat_id

  if(cat_id === '9'){
    return(
      <View style={styles.cal_this}>
      <FlatList 
                        
                        data={this.state.images}

                        keyExtractor={(item, index) => item.id}

                        horizontal={true}

                        ListEmptyComponent={this.emptymsgFun()}

                        contentContainerStyle={styles.cal_this_flat}

                        //snapToAlignment={'center'}
                          
                        initialNumToRender={1}

                        initialScrollIndex={this.state.images.length > 1 ? 1 : null }

                        showsHorizontalScrollIndicator={false}

                        getItemLayout={(data, index) => (
                          {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                        )}

                        renderItem={({ item, index }) =>

                        <View style={styles.cal_this_item_body}>

                        <View style={styles.row_1}>
                        <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                        </View>

                          <View style={styles.row_2}>
                                   <Image
                                          style={styles.cal_this_img}
                                          source={{uri : item.img_url}}
                                      />
                          </View>

                          <View style={styles.row_3}>
                          <Text style={styles.img_des} numberOfLines={3}>{item.img_des}</Text>
                          </View>

                          <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
             
                            <Text style={styles.btn_title}>Read more</Text>
                        
                          </TouchableOpacity>

                          
                        </View>
                        
                      }
                      
                      />
                        </View>

   
    )
  }else if(cat_id === '11'){
    return(
      <View>
        <View style={[styles.retire_lable,{marginTop:hp('1.5%')}]}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>US & Canada</Text>
                  </View>
          </View>
      <View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
        <FlatList 
                          
                          data={this.state.images.filter(function(itemx){return itemx.gp_type == '1'})}
  
                          keyExtractor={(item, index) => item.id}
  
                          horizontal={true}
  
                          ListEmptyComponent={this.emptymsgFun()}
  
                          contentContainerStyle={styles.cal_this_flat}
  
                          //snapToAlignment={'center'}
                            
                          initialNumToRender={1}
  
                          initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '1'}).length  > 1 ? 1 : null }
  
                          showsHorizontalScrollIndicator={false}
  
                          getItemLayout={(data, index) => (
                            {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                          )}
  
                          renderItem={({ item, index }) =>
  
                          <View style={styles.cal_this_item_body}>
  
                          <View style={styles.row_1}>
                          <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                          </View>
  
                            <View style={styles.row_2}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >Property Value (1000 Sq. ft) : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Living Expense per month : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>

                               
                            </View>
  
                            <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
               
                              <Text style={styles.btn_title}>Read more</Text>
                          
                            </TouchableOpacity>
  
                            
                          </View>
                          
                        }
                        
                        />
                        </View>






         <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Australia & New Zealand</Text>
                </View>
          </View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '2'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '2'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                    <View style={styles.row_2}>
                             <Image
                                    style={styles.cal_this_img}
                                    source={{uri : item.img_url}}
                                />
                    </View>

                    <View style={[styles.row_3,{paddingLeft:wp('2%')}]}>
                    <View style={{flexDirection:'row'}}>
                          <Text style={styles.img_des_retir} >Property Value (1000 Sq. ft) : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                          </View>

                          <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                          <Text style={styles.img_des_retir} >Living Expense per month : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                          </View>

                       
                    </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>



          <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Asian City</Text>
                </View>
          </View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '3'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '3'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                    <View style={styles.row_2}>
                             <Image
                                    style={styles.cal_this_img}
                                    source={{uri : item.img_url}}
                                />
                    </View>

                    <View style={[styles.row_3,{paddingLeft:wp('2%')}]}>
                    <View style={{flexDirection:'row'}}>
                          <Text style={styles.img_des_retir} >Property Value (1000 Sq. ft) : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                          </View>

                          <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                          <Text style={styles.img_des_retir} >Living Expense per month : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                          </View>

                       
                    </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>


          <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Mainland China</Text>
                </View>
          </View>
    

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '4'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '4'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                    <View style={styles.row_2}>
                             <Image
                                    style={styles.cal_this_img}
                                    source={{uri : item.img_url}}
                                />
                    </View>

                    <View style={[styles.row_3,{paddingLeft:wp('2%')}]}>
                    <View style={{flexDirection:'row'}}>
                          <Text style={styles.img_des_retir} >Property Value (1000 Sq. ft) : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                          </View>

                          <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                          <Text style={styles.img_des_retir} >Living Expense per month : </Text>
                          <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                          </View>

                       
                    </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>

                </View>
  
     
      )

    
  }else if(cat_id === '12'){
    return(
      <View style={[styles.cal_this,{height:hp('55%')}]}>
        <FlatList 
                          
                          data={this.state.images}
  
                          keyExtractor={(item, index) => item.id}
  
                          horizontal={true}
  
                          ListEmptyComponent={this.emptymsgFun()}
  
                          contentContainerStyle={styles.cal_this_flat}
  
                          //snapToAlignment={'center'}
                            
                          initialNumToRender={1}
  
                          initialScrollIndex={this.state.images.length > 1 ? 1 : null }
  
                          showsHorizontalScrollIndicator={false}
  
                          getItemLayout={(data, index) => (
                            {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                          )}
  
                          renderItem={({ item, index }) =>
  
                          <View style={styles.cal_this_item_body}>
  
                          <View style={[styles.row_1,{flex:0.13}]}>
                          <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                          </View>
  
                            <View style={[styles.row_2,{flex:0.35}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{flex:0.4,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >Diagnosis fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Treatment fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Rehabilitation fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_3)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Lack of income during {"\n"}the treatment years : </Text>
                                  <Text style={[styles.img_des_val,{marginTop: hp('2%'),}]} >${this.th_sp(item.image_value_4)}</Text>
                                  </View>

                               
                            </View>
  
                            <TouchableOpacity style={[styles.row_4,{flex:0.12}]} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
               
                              <Text style={styles.btn_title}>Read more</Text>
                          
                            </TouchableOpacity>
  
                            
                          </View>
                          
                        }
                        
                        />
  
  </View>
      )

    
  }else if(cat_id === '10'){
    return(
      <View style={[styles.cal_this,{height:hp('35%')}]}>
      <FlatList 
                        
                        data={this.state.images}

                        keyExtractor={(item, index) => item.id}

                        horizontal={true}

                        ListEmptyComponent={this.emptymsgFun()}

                        contentContainerStyle={styles.cal_this_flat}

                        //snapToAlignment={'center'}
                          
                        initialNumToRender={1}

                        initialScrollIndex={this.state.images.length > 1 ? 1 : null }

                        showsHorizontalScrollIndicator={false}

                        getItemLayout={(data, index) => (
                          {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                        )}

                        renderItem={({ item, index }) =>

                        <View style={styles.cal_this_item_body}>

                        <View style={styles.row_1}>
                        <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                        </View>

                          <View style={[styles.row_2,{flex:0.5}]}>
                                   <Image
                                          style={styles.cal_this_img}
                                          source={{uri : item.img_url}}
                                      />
                          </View>

                          <View style={[styles.row_3,{flex:0.17,paddingLeft:wp('2%')}]}>

                                <View style={{flexDirection:'row'}}>
                                <Text style={styles.img_des_retir} >Average loan amount : </Text>
                                <Text style={styles.img_des_val} >{item.image_value_1} millions</Text>
                                </View>

                             
                          </View>

                          <TouchableOpacity style={[styles.row_4,{flex:0.18}]} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
             
                            <Text style={styles.btn_title}>Read more</Text>
                        
                          </TouchableOpacity>

                          
                        </View>
                        
                      }
                      
                      />
                      </View>

                      
      )

    
  }else if(cat_id === '7'){
    return(
      <View>
        <View style={[styles.retire_lable,{marginTop:hp('1.5%')}]}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>US</Text>
                  </View>
          </View>
      <View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
        <FlatList 
                          
                          data={this.state.images.filter(function(itemx){return itemx.gp_type == '1'})}
  
                          keyExtractor={(item, index) => item.id}
  
                          horizontal={true}
  
                          ListEmptyComponent={this.emptymsgFun()}
  
                          contentContainerStyle={styles.cal_this_flat}
  
                          //snapToAlignment={'center'}
                            
                          initialNumToRender={1}
  
                          initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '1'}).length  > 1 ? 1 : null}
  
                          showsHorizontalScrollIndicator={false}
  
                          getItemLayout={(data, index) => (
                            {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                          )}
  
                          renderItem={({ item, index }) =>
  
                          <View style={styles.cal_this_item_body}>
  
                          <View style={styles.row_1}>
                          <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                          </View>
  
                            <View style={[styles.row_2,{flex:0.40}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>
                                  <Text style={styles.img_des_retir} >(with 5% Inflation)</Text>

                               
                            </View>
  
                            <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
               
                              <Text style={styles.btn_title}>Read more</Text>
                          
                            </TouchableOpacity>
  
                            
                          </View>
                          
                        }
                        
                        />
                        </View>






         <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>UK</Text>
                </View>
          </View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '2'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '2'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                  <View style={[styles.row_2,{flex:0.40}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                  </View>
  
                            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>
                                  <Text style={styles.img_des_retir} >(with 5% Inflation)</Text>

                               
                            </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>



          <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Canada</Text>
                </View>
          </View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '3'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '3'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                  <View style={[styles.row_2,{flex:0.40}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>
                                  <Text style={styles.img_des_retir} >(with 5% Inflation)</Text>

                               
                            </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>


          <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Australia</Text>
                </View>
          </View>
    

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '4'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '4'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                  <View style={[styles.row_2,{flex:0.40}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>
                                  <Text style={styles.img_des_retir} >(with 5% Inflation)</Text>

                               
                            </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>




                <View style={styles.retire_lable}>
                <View style={styles.retire_con}>
                <Text style={styles.imgs_lable_txt} numberOfLines={1}>Asia</Text>
                </View>
          </View>
    

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
                  
                  data={this.state.images.filter(function(itemx){return itemx.gp_type == '5'})}

                  keyExtractor={(item, index) => item.id}

                  horizontal={true}

                  ListEmptyComponent={this.emptymsgFun()}

                  contentContainerStyle={styles.cal_this_flat}

                  //snapToAlignment={'center'}
                    
                  initialNumToRender={1}

                  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '5'}).length  > 1 ? 1 : null}

                  showsHorizontalScrollIndicator={false}

                  getItemLayout={(data, index) => (
                    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                  )}

                  renderItem={({ item, index }) =>

                  <View style={styles.cal_this_item_body}>

                  <View style={styles.row_1}>
                  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
                  </View>

                  <View style={[styles.row_2,{flex:0.40}]}>
                                     <Image
                                            style={styles.cal_this_img}
                                            source={{uri : item.img_url}}
                                        />
                            </View>
  
                            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
                            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_1)}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >2018 Tuition and fees : </Text>
                                  <Text style={styles.img_des_val} >${this.th_sp(item.image_value_2)}</Text>
                                  </View>
                                  <Text style={styles.img_des_retir} >(with 5% Inflation)</Text>

                               
                            </View>

                    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>
       
                      <Text style={styles.btn_title}>Read more</Text>
                  
                    </TouchableOpacity>

                    
                  </View>
                  
                }
                
                />
                </View>

                </View>
  
     
      )

    
  }else if(cat_id === '8'){
    return(
<View>
<View style={[styles.retire_lable,{marginTop:hp('1.5%')}]}>
<View style={styles.retire_con}>
<Text style={styles.imgs_lable_txt} numberOfLines={1}>HK side</Text>
  </View>
</View>
<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
          
          data={this.state.images.filter(function(itemx){return itemx.gp_type == '1'})}

          keyExtractor={(item, index) => item.id}

          horizontal={true}

          ListEmptyComponent={this.emptymsgFun()}

          contentContainerStyle={styles.cal_this_flat}

          //snapToAlignment={'center'}
            
          initialNumToRender={1}

         initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '1'}).length  > 1 ? 1 : null }

          showsHorizontalScrollIndicator={false}

          getItemLayout={(data, index) => (
            {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
          )}

          renderItem={({ item, index }) =>

          <View style={styles.cal_this_item_body}>

          <View style={styles.row_1}>
          <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
          </View>

            <View style={[styles.row_2,{flex:0.40}]}>
                     <Image
                            style={styles.cal_this_img}
                            source={{uri : item.img_url}}
                        />
            </View>

            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_1}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Semi-Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_2}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >ward : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_3}</Text>
                                  </View>
            </View>

            <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>

              <Text style={styles.btn_title}>Read more</Text>
          
            </TouchableOpacity>

            
          </View>
          
        }
        
        />
        </View>






<View style={styles.retire_lable}>
<View style={styles.retire_con}>
<Text style={styles.imgs_lable_txt} numberOfLines={1}>Kowloon</Text>
</View>
</View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
  
  data={this.state.images.filter(function(itemx){return itemx.gp_type == '2'})}

  keyExtractor={(item, index) => item.id}

  horizontal={true}

  ListEmptyComponent={this.emptymsgFun()}

  contentContainerStyle={styles.cal_this_flat}

  //snapToAlignment={'center'}
    
  initialNumToRender={1}

  initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '2'}).length  > 1 ? 1 : null }

  showsHorizontalScrollIndicator={false}

  getItemLayout={(data, index) => (
    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
  )}

  renderItem={({ item, index }) =>

  <View style={styles.cal_this_item_body}>

  <View style={styles.row_1}>
  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
  </View>

  <View style={[styles.row_2,{flex:0.40}]}>
                     <Image
                            style={styles.cal_this_img}
                            source={{uri : item.img_url}}
                        />
  </View>

            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_1}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Semi-Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_2}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >ward : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_3}</Text>
                                  </View>
            </View>

    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>

      <Text style={styles.btn_title}>Read more</Text>
  
    </TouchableOpacity>

    
  </View>
  
}

/>
</View>



<View style={styles.retire_lable}>
<View style={styles.retire_con}>
<Text style={styles.imgs_lable_txt} numberOfLines={1}>NT</Text>
</View>
</View>

<View style={[styles.cal_this,{marginTop:hp('1%'),marginBottom:hp('2%'),}]}>
<FlatList 
  
  data={this.state.images.filter(function(itemx){return itemx.gp_type == '3'})}

  keyExtractor={(item, index) => item.id}

  horizontal={true}

  ListEmptyComponent={this.emptymsgFun()}

  contentContainerStyle={styles.cal_this_flat}

  //snapToAlignment={'center'}
    
  initialNumToRender={1}

 initialScrollIndex={this.state.images.filter(function(itemx){return itemx.gp_type == '3'}).length  > 1 ? 1 : null }

  showsHorizontalScrollIndicator={false}

  getItemLayout={(data, index) => (
    {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
  )}

  renderItem={({ item, index }) =>

  <View style={styles.cal_this_item_body}>

  <View style={styles.row_1}>
  <Text style={styles.img_title} numberOfLines={1}>{item.img_title}</Text>
  </View>

  <View style={[styles.row_2,{flex:0.40}]}>
                     <Image
                            style={styles.cal_this_img}
                            source={{uri : item.img_url}}
                        />
            </View>

            <View style={[styles.row_3,{flex:0.30,paddingLeft:wp('2%')}]}>
            <View style={{flexDirection:'row'}}>
                                  <Text style={styles.img_des_retir} >Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_1}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >Semi-Private room : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_2}</Text>
                                  </View>

                                  <View style={{flexDirection:'row',marginTop:hp('1%')}}>
                                  <Text style={styles.img_des_retir} >ward : </Text>
                                  <Text style={styles.img_des_val} >${item.image_value_3}</Text>
                                  </View>
            </View>

    <TouchableOpacity style={styles.row_4} onPress ={() =>this.oprenReadMore(item.img_url,item.img_title,item.img_des)}>

      <Text style={styles.btn_title}>Read more</Text>
  
    </TouchableOpacity>

    
  </View>
  
}

/>
</View>
</View>
                      
      )

    
  }
}

  render() {
    return (
        <Modal style = {{  margin: 0 }} isVisible={this.state.cmtModal} hasBackdrop={false} onRequestClose={()=>this.close()}>
         
        <View style={styles.container} >


          <View style={styles.cmntPad} >

              <ScrollView style={{width:'100%'}} contentContainerStyle={{alignItems:'center'}}>
                    <View style={styles.details_con}>
                         <Text style={styles.br_title}>{this.state.briefing_title}</Text>

                         <View style={styles.des_con_st}>
                         <Icon name='ios-globe' style={styles.ico_st}/>
                         <Text style={styles.des_st}>{this.state.briefing_descrip_1}</Text>
                         </View>

                         <View style={styles.des_con_st}>
                         <Icon name='ios-globe' style={styles.ico_st}/>
                         <Text style={styles.des_st}>{this.state.briefing_descrip_2}</Text>
                         </View>

                         <View style={styles.des_con_st}>
                         <Icon name='ios-globe' style={styles.ico_st}/>
                         <Text style={styles.des_st}>{this.state.briefing_descrip_3}</Text>
                         </View>

                         <View style={styles.des_con_st}>
                         <Icon name='ios-globe' style={styles.ico_st}/>
                         <Text style={styles.des_st}>{this.state.briefing_descrip_4}</Text>
                         </View>

                     </View>


                     

                        {this.flatlist_comp()}

                 


                    <View style={styles.bottomBtn}>
                    <TouchableOpacity style={styles.btnCon} onPress={()=>this.navigate()}>
                    <Text style={styles.botm_btn_title}>Financial Planning</Text>
                    </TouchableOpacity>
                    </View>
              </ScrollView>

           

                </View> 
          



             



            <View style={styles.closeHeading} >

                    <TouchableOpacity style={styles.HeadRaw3} onPress ={() =>this.close()}>
                            <View style={styles.ttBtn} >
                            <Icon name="ios-arrow-back" style={styles.iconClose}/>
                                </View>
                    </TouchableOpacity>

                    <View style={styles.HeadRaw2}>
                            <Text  style={styles.UserName}>{this.state.cat_name}</Text>
                    </View>


            </View>



          
            <Modal style = {styles.ModalSt} isVisible={this.state.readMoreMdl} onRequestClose={()=>this.close()} onBackdropPress={()=>this.setState({readMoreMdl:false})}>
       
                 <View style={styles.read_more}>

                     <View style={styles.read_row_1}>
                                            <Image
                                                style={styles.cal_this_img}
                                                source={{uri : this.state.img_url}}
                                            />
                     </View>

                     <View style={styles.read_row_2}>
                       <ScrollView style={{width:'100%'}} contentContainerStyle={{paddingHorizontal:wp('5%')}}>
                            <Text style={styles.read_title}>{this.state.img_title}</Text>

                            <Text style={styles.read_des}>{this.state.img_des}</Text>

                       </ScrollView>
                     </View>

                     <TouchableOpacity style={styles.read_row_3} onPress ={() =>this.setState({readMoreMdl:false})}>
                     <Text style={styles.botm_btn_title}>Close</Text>
                     </TouchableOpacity>

                 </View>
            </Modal>


           


            

        </View>
      
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
      flex:1,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#fbfbfc',
    
  },
  imagePad:{
    width:'100%',
    height:'100%',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: hp('4%'),
  },
 



ttBtn:{
   
    justifyContent: 'center',
    alignItems: 'center',
},

iconClose:{
    color:'#fff',
    fontSize:hp('5%'),
},

closeHeading:{
    position:'absolute',
    top:0,
    width:'100%',
    height:hp('10%'),
    backgroundColor: '#D21044',
    flexDirection: 'row',
    //justifyContent: 'flex-end',
    alignItems: 'center',
    

},


HeadRaw1:{
height:'100%',
width:'20%',
justifyContent: 'center',
alignItems:'center'
},

HeadRaw2:{
    height:'100%',
    width:'85%',
    justifyContent: 'center',
    paddingLeft:wp('5%')
    },

    HeadRaw3:{
        justifyContent: 'center',
        alignItems: 'center',
        height:'100%',
        width:'15%',
        },


UserName:{
    color:'#fff',
    fontSize:hp('2.7%'),

},




cmntPad:{

width:'100%',
height:'100%',
paddingTop:hp('13%'),
},

  emptyListPAD:{
    height:hp('45%'),
    width:wp('100%'),
    justifyContent:'center',
    alignItems:'center',
  },

  emptyTXT:{
    fontWeight:'bold',
    fontSize:hp('2.5%'),
    color:'#898989'
  },

  EmtyIco:{
    marginTop: hp('1%'),
    fontSize:hp('5%'),
    color:'#898989'
  },

  details_con:{
    width:wp('75%')
  },

  br_title:{
    fontSize:hp('3.3%'),
    fontWeight:'bold',
    marginBottom: hp('5%'),
  },

  des_st:{
    fontSize:hp('2%'),
    marginBottom:hp('2%')
  },

  des_con_st:{
    flexDirection:'row'
  },

  ico_st:{
    fontSize:hp('2.5%'),
    marginRight: wp('2%'),
    //color:''
  },

  cal_this:{
    height:hp('45%'),
    paddingVertical: hp('1%'),
    width:'100%',
    marginVertical:hp('2%'),

  },

  cal_this_flat:{
    height:'100%',
  },

  cal_this_item_body:{
    flex:1,
    height:'100%',
    width:wp('65%'),
    backgroundColor: '#fff',
    marginHorizontal: wp('2%'),
    borderRadius:hp('1%'),
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#ddd',
  },

  cal_this_img:{
    height:'100%',
    width:'100%'
  },

  imgs_lable_txt:{
    fontSize:hp('2.5%'),
    fontWeight:'bold',
    color:'#fff'
  },

  img_title:{
    fontSize:hp('2.5%'),
    fontWeight:'bold',
    marginLeft: wp('2%'),
  },

  img_des:{
    fontSize:hp('2%'),
    marginHorizontal: wp('2%'),
  },

  img_des_retir:{
    fontSize:hp('1.8%'),
    fontWeight:'700'
  },

  img_des_val:{
    fontSize:hp('1.8%'),
    fontWeight:'200',
    color:'red'
  },

  row_1:{
   flex:0.15,
   justifyContent: 'center',
  },
  row_2:{
    flex:0.45,
    paddingHorizontal:wp('1.5%')
  },
  row_3:{
    flex:0.25,
    justifyContent: 'center',
  },
  row_4:{
    flex:0.15,
    backgroundColor: '#f9f9f9',
    justifyContent: 'center',
    alignItems: 'center',
  },
  btn_row:{
    flex:0.5,
    backgroundColor: '#ddd',
    borderTopLeftRadius: hp('2%'),
    justifyContent: 'center',
    alignItems: 'center',
  },

  btn_title:{
    fontSize:hp('2.5%'),
    color:'#5b99ff',
    fontWeight:'500'
  },

  bottomBtn:{
    width:'100%',
    height:hp('7%'),
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom:hp('2%')
  },

  btnCon:{
    height:'100%',
    width:'90%',
    backgroundColor: '#D21044',
    borderRadius:hp('7'),
    justifyContent: 'center',
    alignItems: 'center',
  },

  botm_btn_title:{
    fontSize:hp('2%'),
    fontWeight:'500',
    color:'#fff'
  },

  read_more:{
    height:hp('75%'),
    width:wp('80%'),
    backgroundColor: '#fff',
    
  },

  ModalSt:{
    alignItems:'center',
    justifyContent: 'center',
  },

  read_row_1:{
 flex:0.3,
 paddingTop:hp('1%'),
 paddingHorizontal: hp('1%'),
  },
  read_row_2:{
    flex:0.6,
  },

  read_row_3:{
    flex:0.1,
    backgroundColor: '#D21044',
    justifyContent: 'center',
    alignItems: 'center',
  },

  read_title:{
    fontSize:hp('3.3%'),
    fontWeight:'bold',
    marginTop: hp('1%'),
    marginBottom: hp('2%'),
  },

  read_des:{
    fontSize:hp('2.3%'),
    marginBottom: hp('5%'),
  },

  retire_lable:{
    width:wp('100%'),
    height:hp('7%'),
    alignItems:'center',
    marginTop:hp('1%'),
    
  },

  retire_con:{
    width:'95%',
    height:'100%',
    borderRadius:hp('0.8%'),
    justifyContent: 'center',
    backgroundColor: '#ff3838',
    paddingLeft:wp('3%')
  }



});