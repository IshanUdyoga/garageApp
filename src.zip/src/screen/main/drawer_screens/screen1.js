import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions
} from 'react-native';

import Header from '../../main/header'


export default class Screen1 extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header _this={this} header_title={"Home"} />
            <Text>screen1</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  

});