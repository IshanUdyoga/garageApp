import React, {Component} from 'react';
import { createStackNavigator, createAppContainer } from 'react-navigation';

import Login from './src/screen/login/login';
import Register from './src/screen/login/register'
import FooterTab from './src/screen/main/footerTab'
import ManageUploads from './src/screen/main/ManageUploads'



const AppNavigator = createStackNavigator(
{

  Login: { screen: Login },
  Register: {screen: Register},
  FooterTab:{screen:FooterTab},
  ManageUploads:{screen:ManageUploads}
},
{
    initialRouteName: 'FooterTab',
}

);

const AppContainer = createAppContainer(AppNavigator);




export default class App extends Component {
  render() {
    return <AppContainer  />;
  }
}