import React, { Component } from 'react';
import {AsyncStorage,Alert,BackHandler,StatusBar,Easing,StyleSheet, View, TextInput,Text, ScrollView,Image,Button, Animated,TouchableOpacity, Keyboard, KeyboardAvoidingView,Platform,Dimensions,ImageBackground,ActivityIndicator } from 'react-native';

import { withNavigationFocus } from 'react-navigation';
import Icon from 'react-native-ionicons'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
const window = Dimensions.get('window');
import logo from '../../../src/img/logo.png';
import { GoogleSignin, GoogleSigninButton, statusCodes } from 'react-native-google-signin';
import * as firebase from 'react-native-firebase';


import stringsoflanguages from '../../screen/lng/stringsoflanguages';
const IMAGE_HEIGHT = hp('24%');
const IMAGE_HEIGHT_SMALL = hp('10%');
let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;

import { AccessToken, LoginManager,GraphRequest,GraphRequestManager } from 'react-native-fbsdk';


class Login extends Component {
  constructor(props) {
    super(props);
    this.state = { email: '', 
    password: '', 
    errorMessage: null,
    loading : false,
    userid:'',
    userType:'customer',
    keyBisOpen:false,
    showPassword:true
      }

    this.imageHeight = new Animated.Value(IMAGE_HEIGHT);
    this.back_3Anim = new Animated.Value(-hp('1%'));
    this.typePad = new Animated.Value(0);
  }

  static navigationOptions = {
     header: null
 
 };

  componentWillMount () {
  this.customFacebookLogout()
    this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
  }


  componentWillUnmount() {
    this.keyboardWillShowSub.remove();
    this.keyboardWillHideSub.remove();
   
  }


  onBackButtonPressed() {
    return true
  }

  
  componentWillReceiveProps(nextProps) {
    if(this.props.isFocused && nextProps.isFocused){
      //console.log('not running anything')
      
    }
    
    if(this.props.isFocused && !nextProps.isFocused){
     // console.log('ufocus')
    this.setState({email: '', password: '',showPassword:true})
    this.keyboardWillShowSub.remove();
    this.keyboardWillHideSub.remove();
    
    
    }
    
    if(!this.props.isFocused && nextProps.isFocused){
    //  console.log('focus')
    this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
    this.customFacebookLogout()
    }
        
          
  }






  keyboardDidShow = (event) => {
    Animated.timing(this.imageHeight, {
      toValue: IMAGE_HEIGHT_SMALL,
    }).start();


    
  };

  keyboardDidHide = (event) => {
    Animated.timing(this.imageHeight, {
      toValue: IMAGE_HEIGHT,
    }).start();

    
  };







  err(error){

    alert(error.message)
    this.setState({loading:false})
  }



  LL(){
    if(this.state.loading){
      return(<View style ={styles.Load} >

       <View style={styles.LoadSub}>
       <ActivityIndicator size="large"  color='#fff'/>
         </View>

    </View>)
    }else{
      return(<View />)
    }
  }

  showUserType(){
    Animated.timing(this.typePad, {
      toValue: 0,
      easing: Easing.out(Easing.circle),
        duration:500,
    }).start();
  }


hideUserType(){
  Animated.timing(this.typePad, {
    toValue: wp('100%'),
    easing: Easing.in(Easing.circle),
      duration:500,
  }).start();
}



  login(){
    Keyboard.dismiss()
    if(this.state.userType === 'customer'){
      this.customerLoginFunction()
    }else{
      this.sellerLoginFunction()
    }
  }







  customerLoginFunction = () => {
    const { email }   = this.state;
    const { password }   = this.state;
    
    this.setState({
        loading:true
      });

      if(this.state.email === "" || this.state.password === ""){
        alert(stringsoflanguages.login.login_warn_1);
        this.setState({
            loading:false
          });

      }else if(reg.test(this.state.email) === false)
                {
                alert(stringsoflanguages.login.login_warn_2);
                this.setState({
                    loading:false
                  });
                //return false;
                }else {

                  firebase

                  .auth()
            
                  .signInWithEmailAndPassword(email, password)
            
                  .then(() => this.props.navigation.navigate('FooterTab'))
            
                  .catch(error => 
                    this.err(error)
                    )
    }
}

err(error){
  this.setState({loading:false})
  alert(error)
}



custTypeBtn(val){
    if(val=== 1){
      this.setState({userType:'customer'})
      this.hideUserType()
    }else{
      this.setState({userType:'seller'})
      this.hideUserType()
    }
}



// facebookLoginOld= async()=>{
//   try {
//     const result = await LoginManager.logInWithReadPermissions(['public_profile', 'email']);

//     if (result.isCancelled) {
//       // handle this however suites the flow of your app
//       alert('User cancelled request'); 
//     }

//    // alert(`Login success with permissions: ${result.grantedPermissions.toString()}`);

//     // get the access token
//     const data = await AccessToken.getCurrentAccessToken();

//     if (!data) {
//       // handle this however suites the flow of your app
//       alert('Something went wrong obtaining the users access token');
//     }

//     // create a new firebase credential with the token
//     //const credential = firebase.auth.FacebookAuthProvider.credential(data.accessToken);

//     // login with credential
//     //const firebaseUserCredential = await firebase.auth().signInWithCredential(credential);

//     alert(JSON.stringify(data))

//   } catch (e) {
//     alert(e);
//   }

  
// }



facebookLogin= async()=> {
  this.setState({
    loading:true
  });
     
    LoginManager.logInWithReadPermissions(['public_profile', 'email']).then(
      function (result) {
        if (result.isCancelled) {
          alert('Login was cancelled !');
          this.setState({
            loading:false
          });
        } else {
  
          this.loadData()
                
         // result.grantedPermissions.toString()
        }
      }.bind(this),
      function (error) {
        this.setState({
          loading:false
        });
        alert('Login failed with error: ' + error);
      }
    );
    
    
    

  

  
}



customFacebookLogout = () => {

  AccessToken.getCurrentAccessToken().then((data) => {
    access_token = data.accessToken.toString();
    if(access_token == null){
  
    }else{
    
                  let logout =
                  new GraphRequest(
                    "me/permissions/",
                    {
                        accessToken: access_token,
                        httpMethod: 'DELETE'
                    },
                    (error, result) => {
                        if (error) {
                            alert('Error fetching data: ' + error.toString());
                        } else {
                            LoginManager.logOut();

                        }
                    });
                  new GraphRequestManager().addRequest(logout).start();
        
                   

    }

  })
    
  
}



async fetchProfile(callback) {
  return new Promise((resolve, reject) => {
    const request = new GraphRequest(
      '/me',
      {
        parameters: {
          'fields': {
              'string' : 'email,name'
          }
        }
      },
      (error, result) => {
        if (result) {
          const profile = result
          profile.avatar = `https://graph.facebook.com/${result.id}/picture`
          resolve(profile)
        } else {
          reject(error)
        }
      }
    )

    new GraphRequestManager().addRequest(request).start();
  })
}

loadData =async () =>{
  const profile = await this.fetchProfile()

  //alert(JSON.stringify(profile))

  this.UserRegistrationCustomer(profile.name,profile.email,profile.avatar,'fblogin')
}


UserRegistrationCustomer = (Fname,UserEmail,propic,loginType) =>{


  
 fetch('http://192.168.9.103:80/garage/social_registration.php', {
   method: 'POST',
   headers: {
     'Accept': 'application/json',
     'Content-Type': 'application/json',
   },
   body: JSON.stringify({
  
     name: Fname,
  
     email: UserEmail,
  
     password: null,

     propic : propic
  
   })
  
 }).then((response) => response.json())
       .then((responseJson) => {
  
            
            if(responseJson.status === 'true'){

              Alert.alert("User Registered Successfully ! ");

              AsyncStorage.multiSet([
               ['userID', responseJson.customer_id],
               ['isLoggedIn', 'true'],
               ['loginType', loginType],  
               ['userName', Fname],
               ['email', UserEmail]
              ]);

              this.props.navigation.navigate('FooterTab');

            }else{
              AsyncStorage.multiSet([
                ['userID', responseJson.customer_id],
                ['isLoggedIn', 'true'], 
                ['loginType', loginType], 
                ['userName', responseJson.username],
                ['email', responseJson.email]
               ]);
               this.props.navigation.navigate('FooterTab');
            }

            this.setState({
              loading:false
            });

       // 
  
       }).catch((error) => {
         alert(error);
              this.setState({
                loading:false
              });
       });
  
      
   }


   googleAuth() {
    this.setState({
      loading:true
    });
    GoogleSignin.signIn()
      .then((user) => {

        this.UserRegistrationCustomer(user.user.name,user.user.email,user.user.photo,'glogin')
        
      })
      .catch((err) => {
       alert('WRONG SIGNIN', err);
       this.setState({
        loading:false
      });
      })
      .done();
  }


  togglePasswordHide(){
    this.state.showPassword ? this.setState({showPassword:false}) : this.setState({showPassword:true})
    
  }


  render() {
    return (
      <ImageBackground style={{flex:1,alignItems:'center'}} source={{ uri: `asset:/images/img_backgrounds/login_back.jpg`}}>
       <View style={styles.main_container}>


       <Animated.Image source={logo} style={[styles.logo, { height: this.imageHeight }]} />

       <View style={styles.sub_container}>
       <ScrollView contentContainerStyle={{flexGrow:0.7,justifyContent: 'center',minHeight: hp('20%'),}}>
      
         <KeyboardAvoidingView
        style={styles.container}
        behavior="padding"
      >
    <View style={styles.container_pad}>
      <View style={styles.mainV}>
                  <View style={styles.iconV}>
                    <Image source={{ uri: `asset:/images/img_icons/ico_input_pers.png`}} style={styles.input_icon_St} />
                  </View>


                     <View style={styles.textV}>
                                 <TextInput
                                    placeholder={stringsoflanguages.login.login_input_1}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    value={this.state.email}
                                    autoCorrect={false}
                                    autoCapitalize="none"
                                    onChangeText={email => this.setState({ email })}
                                />
                    </View>

       </View>

   


          



<View style={styles.mainV}>
                <View style={styles.iconP}>
                 <Image source={{ uri: `asset:/images/img_icons/ico_input_lock.png`}} style={styles.input_icon_St} />
                </View>


                <View style={styles.textP}>
                                   
                                <TextInput
                                    placeholder={stringsoflanguages.login.login_input_2}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    value={this.state.password}
                                    autoCorrect={false}
                                    autoCapitalize="none"
                                    secureTextEntry={this.state.showPassword}
                                    onChangeText={password => this.setState({ password })}
                                />
                    </View>

                    <TouchableOpacity style={styles.eyeP} 
                          onPress={()=> this.togglePasswordHide()}>
                              <Image source={{ uri: `asset:/images/img_icons/ico_input_eye.png`}} style={[styles.eye_icon_St,{opacity:this.state.showPassword ? 0.5 : 1,}]} />
                  </TouchableOpacity>
          </View>
          
          <View style={styles.forgPass}>
                        <TouchableOpacity  onPress={()=> this.props.navigation.navigate('ResetPass')}>
                        <Text style={styles.forgPass_txt}>Forgot Password ?</Text>
                        </TouchableOpacity>
          </View>
        
      <TouchableOpacity style={styles.login}   onPress={()=> this.login()}>
        <Text style={styles.btnFont}
      >{stringsoflanguages.login.login_btn_1}</Text>
      </TouchableOpacity>

       {/* <TouchableOpacity style={styles.fbBtn} onPress={()=> this.facebookLogin()}>
         <Text style={styles.rePassTXT}>Login With Facebook</Text>
       </TouchableOpacity>
          */}

      <View style={styles.social_btn_con}>

          <TouchableOpacity style={styles.btn_con}  >
            <Image source={{ uri: `asset:/images/img_icons/ico_we.png`}} style={styles.social_icon_St_we} />
          </TouchableOpacity>

          <TouchableOpacity style={[styles.btn_con,{marginHorizontal:wp('2%')}]} >
          <Image source={{ uri: `asset:/images/img_icons/ico_fb.png`}} style={styles.social_icon_St} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.btn_con} >
          <Image source={{ uri: `asset:/images/img_icons/ico_g.png`}} style={styles.social_icon_St} />
          </TouchableOpacity>

      </View>

      <View style={styles.login_Wi_st}>
      <Text style={styles.login_w_txt}>Login with</Text>
      </View>

      
      
          
      </View>    
      </KeyboardAvoidingView>

                    <View style={styles.footer_logo}>
                    {/* <Image source={{ uri: `asset:/images/img_icons/logo.png`}} style={styles.footer_img} /> */}
                    </View>
      </ScrollView>

      
      

      

      </View>






            

            

                    </View>

                    <TouchableOpacity style={styles.backbtn}  >
                    <Image source={{ uri: `asset:/images/img_icons/ico_go_back.png`}} style={styles.back_icon_St} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.sign_up_con}  onPress= {() => this.props.navigation.navigate('Register') }>
                    <Text style={styles.sign_st}>Sign Up</Text>
                    </TouchableOpacity>

                {this.LL()}
                  
      </ImageBackground>
    );
  }
};


const styles = StyleSheet.create({
  main_container:{
    flex:1,
    alignItems:'center',
    backgroundColor: 'rgba(255, 255, 255, 0.90)',
  },

  sub_container:{
    flex:1,
    alignItems:'center',
  },

    container: {
        flex: 0.7,
        alignItems: 'center',
        width: wp('100%'),
      },

      container_pad: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: '85%',
      },


      input: {
        height: hp('8%'),
        width:'90%',
        paddingBottom: 0,
        paddingLeft: wp('5%'),
        fontSize:hp('3.3%'),
        fontFamily: 'seg_light',
        color:'#383838',
        
        
      },
      logo: {
        height: IMAGE_HEIGHT,
        resizeMode: 'contain',
        marginTop:hp('11%'),
        marginBottom:hp('3%'),
        borderRadius: hp('2%'),
      },
      login:{
        marginVertical:hp('1.2%'), 
        width:'100%',
        alignItems:'center',
        justifyContent:'center',
        borderRadius:hp('3.25%'),
        height:hp('6%'),
        backgroundColor: '#7b7b7b',
      },


        register:{
          marginTop: hp('1.2%'),
          marginBottom: hp('2%'),
          width:window.width -50,
          alignItems:'center',
          justifyContent:'center',
          borderRadius: window.height/26,
          height:window.height/13,
          backgroundColor: 'rgba(249, 249, 249, 0.40)',
        },



        mainV:{
            flex:0.2,
            flexDirection:'row',
            width:'100%',
            marginBottom: hp('1.2%'),
            borderBottomWidth: 1,
            borderColor: '#cccccc',
        },

        iconV:{
            flex:0.2,
            justifyContent: 'flex-end',
            alignItems: 'center',
        },
        textV:{
            flex:0.8,
            justifyContent: 'flex-end',
        },


        iconP:{
          flex:0.2,
          justifyContent: 'flex-end',
          alignItems: 'center',
      },
      textP:{
          flex:0.6,
          justifyContent: 'flex-end',
      },
      eyeP:{
          flex:0.2,
          justifyContent: 'flex-end',
          alignItems: 'flex-end',
      },


        iconSty:{
            color:'#fff'
        },

        tttop:{
          position:'absolute',
      top:-window.height/2.5
        },


  Load:{
    position:'absolute',
  },

  LoadSub:{
    height:hp('100%'),
    width:window.width,
    backgroundColor:'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',

  },
  btnFont:{
    color:'#fff',
    fontFamily: 'seg_sem_light',
    fontSize: hp('2.5%'),
    paddingBottom:hp('0.5%')
  },

  btnFont2:{
    color:'#fff',
    fontWeight:'bold',
    fontSize: hp('2%')
  },


  back_3Pad:{
    position:'absolute',
    
    
  },
  back_3:{
    height:hp('15%'),
    width:wp('100%'),
    resizeMode: 'contain',
  },
  userType:{
    position:'absolute',
    height:hp('100%'),
    width:wp('100%'),
  },

  imageTypeBack:{
    height:'100%',
    width:'100%',
    justifyContent: 'center',
    alignItems:'center'
  },

  backbtn:{
    position:'absolute',
    left:-wp('2%'),
    padding:hp('1%')
  },

  sign_up_con:{
    position:'absolute',
    right:wp('5%'),
    top:'2.5%',
  },

  backbtnIco:{
    fontSize:hp('8%'),
    color:'#fff'
  },
  rePassTXT:{
    color:'#fff'
  },

  fbBtn:{
    height:50,
    paddingHorizontal: 20,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: 'green',
  },

  back_icon_St:{
    height:hp('11%'),
    width:hp('11%')
  },

  sign_st:{
    fontSize:hp('4.3%'),
    fontFamily: 'seg_light',
    color:'#8e8f8f'
  },

  input_icon_St:{
    height:hp('6%'),
    width:hp('6%'),
    opacity:0.8
  },

  eye_icon_St:{
    height:hp('5%'),
    width:hp('5%'),
    marginBottom:hp('0.5%')
  },

  forgPass:{
    width:'100%',
    alignItems:'flex-end',
    marginBottom:hp('3%')
  },
  forgPass_txt:{
    fontSize:hp('2%'),
    color:'#979797',
    textDecorationLine:'underline'
  },

  social_btn_con:{
    marginTop:hp('4%'),
    flexDirection:'row',
    justifyContent: 'center',
    width:'100%'
  },

  btn_con:{
    height:hp('6.3%'),
    width:hp('6.3%'),
    borderRadius:hp('5%'),
    backgroundColor: '#949494',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  social_icon_St:{
    width:'90%',
    height:'90%'
  },

  social_icon_St_we:{
    width:'80%',
    height:'80%'
  },

  login_Wi_st:{
    width:'100%',
    alignItems: 'center',
    marginBottom:hp('5%')
  },

  login_w_txt:{
   // marginBottom:hp('8%'),
    fontSize:hp('2%'),
    color:'#979797',
  },

  footer_logo:{
    position:'absolute',
    bottom:0,
    right:'3%'
  },

  footer_img:{
    height:hp('6%'),
    width:hp('18%'),
  }

  });

  
  export default withNavigationFocus(Login);