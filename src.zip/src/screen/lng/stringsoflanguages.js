import React from 'react';
import LocalizedStrings from 'react-native-localization';
const strings = new LocalizedStrings({
  "en": {
    "home": {
      "cat1": "Top Rated",
      "cat2": "Discount",
      "cat3": "Free Delivery",
      "cat4": "Low Cost",
      "cat5": "Pharmacy",
      "visitBtn":"VISIT",
      "loading":"Please Wait..",
      "loading2":"No Results Found.."
    },
    "drawer": {
      "btn1": "Locations",
      "btn2": "Share",
      "btn3_login": "Login",
      "btn3_logout": "Log Out",
    },
    "pharView":{
      "upBtnTitle":"UPLOAD",
      "upBtnTitle2":"Prescription"
    },
    "imgUpModal":{
      "upModalTitle1":"Take Photo",
      "upModalTitle2":"Choose from Library",
      "upModalTitle3":"Cancel",
    },
    "login":{
      "login_warn_1":"Please Enter Your Details",
      "login_warn_2":"Email is Not properly formed",
      "login_input_1":"Email Address",
      "login_input_2":"Password",
      "login_btn_1":"Login",
      "login_btn_2":"REGISTER",
      "login_userTypeBtn_1":"CUSTOMER LOGIN",
      "login_userTypeBtn_2":"SELLER LOGIN",
    },
    "register":{
      "register_warn_1":"Please Enter Your Details",
      "register_warn_2":"User Name must be at least 4 characters",
      "register_warn_3":"Password must be at least 4 characters",
      "register_warn_4":"Password not matched",
      "register_warn_5":"Phone Number must be at least 10 Numbers",
      "register_accType_1":"FREE ACCOUNT",
      "register_accType_2":"PAID ACCOUNT",
      "register_input_1":"User Name",
      "register_input_2":"Email address",
      "register_input_3":"Password",
      "register_input_4":"Re enter password",
      "register_input_5":"Mobile number",
      "register_btn_1":"Sign Up",
    },
    "msgModal": {
      "seller_content": "Sell globally with multi-currency support, over 40 international payment options, support for 45 languages.",
      "buyer_content": "Top global Pharmacies are just a tap away,  Pay By Cash Or Paytm. Service You Love.",
      "seller_btn": "I'm a Seller",
      "buyer_btn": "I'm a Buyer",
    },
    "sellerHome": {
      "head_tag_1" : "Dashboard",
      "head_tag_2" : "My Sellings",
      "head_tag_3" : "Revenue",
      "head_tag_4" : "Selling",
      "title_1" : "My Pharmacy",
      "title_2" : "New Orders",
      "title_3" : "Ongoing Orders",
      "img_up_txt":"Upload Image",
      "placeHold_1": "Pharmacy Title",
      "placeHold_2": "Loaction",
      "placeHold_3": "Discount",
      "placeHold_4": "Enter Description",
      "up_btn": "UPDATE",
      "loading_full":"Loading..",
      "loading_1":"Please Wait..",
      "loading_2":"Empty Orders..",
      "alert_1":"Update Successful !",
      "alert_2":"Update Error Try Again !",
    },
  },




  "tc":{
    "home": {
      "cat1": "ඉහළ ශ්රේණිගත",
      "cat2": "වට්ටම්",
      "cat3": "නොමිලේ සැපයුම",
      "cat4": "අඩු වියදම",
      "cat5": "ඖෂධ",
      "visitBtn":"බලන්න",
      "loading":"රැඳී සිටින්න..",
      "loading2":"ප්රතිඵල සොයාගත නොහැක.."
    },
    "drawer": {
      "btn1": "ස්ථාන",
      "btn2": "බෙදාගන්න",
      "btn3_login": "පිවිසෙන්න",
      "btn3_logout": "ඉවත්වෙන්න",
    },
    "pharView":{
      "upBtnTitle":"උඩුගත කරන්න",
      "upBtnTitle2":"බෙහෙත් වට්ටෝරුව"
    },
    "imgUpModal":{
      "upModalTitle1":"ඡායාරූප ගන්න",
      "upModalTitle2":"ගැලරිය වෙතින් තෝරන්න",
      "upModalTitle3":"අවලංගු කරන්න",
    },
    "login":{
      "login_warn_1":"請輸入您的詳細信息",
      "login_warn_2":"電子郵件未正確形成",
      "login_input_1":"電子郵件地址",
      "login_input_2":"密碼",
      "login_btn_1":"登錄",
      "login_btn_2":"寄存器",
      "login_userTypeBtn_1":"客戶登錄",
      "login_userTypeBtn_2":"賣家登錄",
    },
    "register":{
      "register_warn_1":"請輸入您的詳細信息",
      "register_warn_2":"用戶名必須至少為4個字符",
      "register_warn_3":"密碼必須至少為4個字符",
      "register_warn_4":"密碼不匹配",
      "register_warn_5":"電話號碼必須至少為10個號碼",
      "register_accType_1":"නිදහස් ගිණුම",
      "register_accType_2":"ගෙවූ ගිණුම",
      "register_input_1":"用戶名",
      "register_input_2":"電子郵件地址",
      "register_input_3":"密碼",
      "register_input_4":"重新輸入密碼",
      "register_input_5":"手機號碼",
      "register_btn_1":"註冊",
    },
    "msgModal": {
      "seller_content": "බහු මුදලේ සහාය සමග ගෝලීයව විකුණා, ජාත්යන්තර ගෙවීම් විකල්ප 40 කට වැඩි, භාෂා 45 සඳහා සහාය.",
      "buyer_content": "ගෝලීය ඖෂධ පැළෑටි යනු එකකින්, මුදල් ගෙවීම හෝ Paytm පමණි. ඔබ ආදරය කරන.",
      "seller_btn": "විකුණුම්කරු",
      "buyer_btn": "ගැනුම්කරු",
    },
    "sellerHome": {
      "head_tag_1" : "උපකරණ පුවරුව",
      "head_tag_2" : "මගේ විකුණුම්",
      "head_tag_3" : "ආදායම",
      "head_tag_4" : "විකිණීම",
      "title_1" : "මගේ ෆාමසිය",
      "title_2" : "මගේ ඇණවුම්",
      "img_up_txt":"උඩුගත කරන්න",
      "placeHold_1": "ඖෂධ අංශයේ හිමිකම්",
      "placeHold_2": "ස්ථානය",
      "placeHold_3": "වට්ටම්",
      "placeHold_4": "විස්තරය ඇතුළත් කරන්න",
      "up_btn": "අලුත් කරන්න",
      "loading_full":"රැඳී සිටින්න..",
      "loading_1":"රැඳී සිටින්න..",
      "loading_2":"ඇණවුම් නැත..",
      "alert_1":"යාවත්කාලීන කිරීම සාර්ථකයි !",
      "alert_2":"යාවත්කාලීන කිරීමේ දෝෂයක් යළි උත්සාහ කරන්න !",
    },
  },




  "sc":{
    "home": {
      "cat1": "மதிப்பிடப்பட்டது",
      "cat2": "தள்ளுபடி",
      "cat3": "இலவச விநியோக",
      "cat4": "குறைந்த செலவு",
      "visitBtn":"வருகை",
      "loading":"தயவு செய்து காத்திருங்கள்..",
      "loading2":"முடிவுகள் எதுவும் இல்லை.."
    },
    "drawer": {
      "btn1": "இடங்கள்",
      "btn2": "பகிர்",
      "btn3_login": "உள்நுழைக",
      "btn3_logout": "வெளியேறு",
    },
    "pharView": {
            "upBtnTitle": "பதிவேற்ற",
            "upBtnTitle2": "பரிந்துரை"
          },
          "imgUpModal": {
            "upModalTitle1": "ஃபோட்டோ எடுத்து",
            "upModalTitle2": "நூலகத்திலிருந்து தேர்வு செய்",
            "upModalTitle3": "ரத்து",
          },
          "login":{
      "login_warn_1":"请输入您的详细信息",
      "login_warn_2":"电子邮件未正确形成",
      "login_input_1":"电子邮件地址",
      "login_input_2":"密码",
      "login_btn_1":"登录",
      "login_btn_2":"寄存器",
      "login_userTypeBtn_1":"客户登录",
      "login_userTypeBtn_2":"卖家登录",
          },
          "register":{
      "register_warn_1":"请输入您的详细信息",
      "register_warn_2":"用户名必须至少为4个字符",
      "register_warn_3":"密码必须至少为4个字符",
      "register_warn_4":"密码不匹配",
      "register_warn_5":"电话号码必须至少为10个号码",
      "register_accType_1":"නිදහස් ගිණුම",
      "register_accType_2":"ගෙවූ ගිණුම",
      "register_input_1":"用户名",
      "register_input_2":"电子邮件地址",
      "register_input_3":"密码",
      "register_input_4":"重新输入密码",
      "register_input_5":"手机号码",
      "register_btn_1":"注册",
          },
          "msgModal": {
            "seller_content": "உலகளாவிய நாணய ஆதரவுடன் 40 க்கும் மேற்பட்ட சர்வதேச கட்டணச் சலுகைகள், 45 மொழிகளுக்கு..",
            "buyer_content": "சிறந்த உலக மருந்துகள் ஒரு தட்டையானது, பணம் செலுத்துதல் அல்லது பணம் செலுத்துதல்...",
            "seller_btn": "விற்பனையாளர்",
            "buyer_btn": "வாங்குபவர்",
          },
          "sellerHome": {
            "head_tag_1": "டாஷ்போர்டு",
            "head_tag_2": "எனது விற்பனைகள்",
            "head_tag_3": "வருவாய்",
            "head_tag_4": "விற்பனை",
            "title_1": "என் பார்மசி",
            "title_2": "எனது ஆணைகள்",
            "img_up_txt": "படத்தை பதிவேற்று",
            "placeHold_1": "பார்மசி தலைப்பு",
            "placeHold_2": "லோக்கல்",
            "placeHold_3": "தள்ளுபடி",
            "placeHold_4": "விளக்கம் உள்ளிடவும்",
            "up_btn": "புதுப்பிப்பு",
            "loading_full": "ஏற்றுகிறது ..",
            "loading_1": "காத்திருங்கள் ..",
            "loading_2": "காலி ஆணைகள் ..",
            "alert_1": "புதுப்பிப்பு வெற்றிகரமாக!",
            "alert_2": "புதுப்பிப்பு பிழை மீண்டும் முயற்சிக்கவும்!",
          },
  },





});
export default strings;