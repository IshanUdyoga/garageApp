import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  LayoutAnimation,
  UIManager,
  Image
} from 'react-native';
import Slideshow from 'react-native-image-slider-show';
import Icon from 'react-native-ionicons';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';

UIManager.setLayoutAnimationEnabledExperimental && UIManager.setLayoutAnimationEnabledExperimental(true);

export default class SlideshowTest extends Component {
    constructor(props) {
      super(props);
   
      this.state = {
        position: 1,
        interval: null,
        dataSource: [
          {
            title: 'Title 1',
            caption: 'Caption 1',
            url: 'http://placeimg.com/640/480/any',
          }, {
            title: 'Title 2',
            caption: 'Caption 2',
            url: 'https://t3.ftcdn.net/jpg/01/64/52/86/500_F_164528699_Y4zvv84fjX79C6ZTrAd8YbsOsEFuZzMy.jpg',
          }, {
            title: 'Title 3',
            caption: 'Caption 3',
            url: 'https://www.desktop-background.com/t/2011/02/12/156608_book-taxi-with-la-checker-cab-24-hours-7-days-week-800-300-5007_1600x900_h.jpg',
          },
        ],
      };
    }
   
    componentWillMount() {
      this.setState({
        interval: setInterval(() => {
          this.setState({
            position: this.state.position === this.props.image_slider.length ? 0 : this.state.position + 1
          });
        }, 2000)
      });
    }
   
    componentWillUnmount() {
      clearInterval(this.state.interval);
    }
   
    render() {
      return (
      <Slideshow 
          dataSource={this.props.image_slider}
          position={this.state.position}
          arrowLeft={<View style={styles.ic_con}><Image source={{ uri: `asset:/images/img_icons/icon_back.png`}} style={{marginLeft:-wp('5%'), height:hp('10%'),width:hp('10%')}} /></View>}
          arrowRight={<View style={styles.ic_con}><Image source={{ uri: `asset:/images/img_icons/icon_for.png`}} style={{marginLeft:wp('2.5%'), height:hp('10%'),width:hp('10%')}} /></View>}
          scrollEnabled={false}
          onPositionChanged={position => this.setState({ position })} />
      );
    }
  }

  const styles = StyleSheet.create({
    ic_con:{
      height:'100%',
      width:wp('15%'),
      justifyContent: 'center',
      //alignItems: 'flex-start',
    }
  })
  