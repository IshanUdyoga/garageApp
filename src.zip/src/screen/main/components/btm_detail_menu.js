import * as React from 'react';
import { Text, View, StyleSheet,Slider,TouchableOpacity,AsyncStorage } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons'

export default class Btm_detail_menu extends React.Component {

  constructor(props) {
  
    super(props);
            this.state={
                is_in_bookmark:false,
                bookmarks:[]
            };

  }

  componentDidMount(){
    this.is_available()
  }

  add_remove_bookmark(cat_id,prod_uid){
    var arr = []
    arr = this.state.bookmarks;
    if(this.state.is_in_bookmark){
                     arr = arr.filter(function(el) { return el.prod_uid != prod_uid; });
                     this.setState({bookmarks:arr,is_in_bookmark:false})
                     AsyncStorage.setItem('bookmarks', JSON.stringify(arr))
                     this.props.show_toast('remove')
    }else{
      const obj = {cat_id,prod_uid}
      arr.push(obj)
      this.setState({is_in_bookmark:true,bookmarks:arr})
      AsyncStorage.setItem('bookmarks', JSON.stringify(arr))
      this.props.show_toast('add')
    }
  }


  is_available(){
    AsyncStorage.getItem("bookmarks").then((value) => {
      if(value !== null){
        this.setState({bookmarks:JSON.parse(value)})
      }else{
        this.setState({bookmarks:[],})
      }

    })
    .then(res => {
        var arr = []
        arr = this.state.bookmarks
        
        var is_available=this.containsObject(this.props.prod_uid,arr)
        if(is_available){
          this.setState({is_in_bookmark:true})
        }else{
          this.setState({is_in_bookmark:false})
        }

    });
  }

  containsObject(obj, list) {
    var i;
    for (i = 0; i < list.length; i++) {
        if (list[i].prod_uid === obj) {
            return true;
        }
    }

    return false;
}


  render() {
    return (
        <View style={styles.menu_con}>
               <TouchableOpacity style={styles.rows}>
               <Icon name='ios-download' style={styles.icoSt} />
               </TouchableOpacity>

               <TouchableOpacity style={styles.rows} onPress={()=> this.add_remove_bookmark(this.props.cat_id,this.props.prod_uid)}>
               <Icon name={this.state.is_in_bookmark ? 'ios-star' : 'ios-star-outline'} style={styles.icoSt} />
               </TouchableOpacity>

               <TouchableOpacity style={styles.rows}>
               <Icon name='ios-chatboxes' style={styles.icoSt} />
               </TouchableOpacity>

               <TouchableOpacity style={styles.rows}>
               <Icon name='ios-shuffle' style={styles.icoSt} />
               </TouchableOpacity>

               <TouchableOpacity style={styles.rows}>
               <Icon name='ios-list' style={styles.icoSt} />
               </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({

    menu_con:{
        height:hp('8%'),
        width:'100%',
        //marginBottom: hp('2%'),
        backgroundColor: '#4E8CA5',
        flexDirection: 'row',
      },
      rows:{
        flex:0.2,
        justifyContent: 'center',
        alignItems: 'center',
      },
      btm_m_col2:{
        flex:0.8,
        justifyContent: 'center',
        alignItems:'center'
       
      },
      drag_txt:{
        color:'red',
        fontSize:hp('1.5%'),
        textAlign:'center'
      },

      icoSt:{
          fontSize:hp('4%'),
          color:'#fff'
      },

      policy_txt:{
        fontSize:hp('2%'),
      }
 
});
