import * as React from 'react';
import {StatusBar, Text, View, StyleSheet,Dimensions,TouchableOpacity,Image,AsyncStorage,ScrollView,FlatList,ImageBackground,TextInput,Keyboard,LayoutAnimation,UIManager } from 'react-native';

import Modal from "react-native-modal";
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import ImagePicker from 'react-native-image-crop-picker';

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width



export default class ImgUpModal extends React.Component {

  constructor(props) {

    super(props);



            }


    componentDidMount () {


    }

  componentWillMount(){
 
  }


openPicker(val){
    if(val === 1){
            this.props.openPickerCam()
    }else{
        this.props.openPickerLib()
    }
}


close(){
    this.props._this.setState({ upmodal: false })
    ImagePicker.clean().then(() => {
      }).catch(e => {
      });
}


  render() {
    return (
        <Modal isVisible={this.props.visible} avoidKeyboard={true}  onBackdropPress= {() =>this.props._this.setState({ upmodal: false })}  >
          <StatusBar
     backgroundColor="rgba(0, 0, 0, 20)"
     barStyle="light-content"
     translucent={false}
   />
        <View style={styles.container} >

            <View style={styles.pad}>
                    <View style={[styles.btnPad,{borderBottomWidth:1,borderBottomColor:'#cef2ff'}]}>
                    <TouchableOpacity style={styles.ttBtn} onPress ={() => this.openPicker(1) }>
                    <Text style={styles.fontTT}>Take Photo...</Text>
                    </TouchableOpacity>
                        </View>

                        <View style={styles.btnPad}>
                        <TouchableOpacity style={styles.ttBtn} onPress ={() => this.openPicker(2) }>
                        <Text style={styles.fontTT}>Choose from Library...</Text>
                        </TouchableOpacity>
                            </View>
            </View>


            <View style={styles.pad2} >
            <TouchableOpacity style={styles.ttBtn} onPress ={() =>this.close()}>
                <Text style={styles.fontTT}>Cancel</Text>
                </TouchableOpacity>
            </View>

          

        </View>
      
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems:'center',
    justifyContent:'flex-end' ,
    height:'100%'
  },
 

pad:{
    height:hp('20%'),
    width:deviceWidth/1.1,
    backgroundColor:'#fff',
    borderRadius: hp('5%'),
    justifyContent: 'center',
    alignItems: 'center',
},

pad2:{
    height:hp('8%'),
    width:deviceWidth/1.1,
    backgroundColor:'#fff',
    borderRadius: hp('3%'),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: hp('2%'),
},

fontTT:{
    color:'#4dcbf9',
    fontSize: hp('3%'),
},

btnPad:{
    height:hp('10%'),
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
},
ttBtn:{
    height:'100%',
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
}


});
