import React from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  Button,
  View, processColor,
  Dimensions
} from 'react-native';
import update from 'immutability-helper';

import {LineChart} from 'react-native-charts-wrapper';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';


const screenWidth = Dimensions.get('window').width
const screenHeight = Dimensions.get('window').height

class Multi_line_chart extends React.Component {

  constructor() {
    super();
    this.state = {
      data: {},
    
      marker: {
        enabled: true,
        digits: 2,
        backgroundTint: processColor('teal'),
        markerColor: processColor('#F0C0FF8C'),
        textColor: processColor('white'),
      },
      xAxis: {
        granularityEnabled: true,
        granularity: 1,
      },

      yAxis : {
        left: {
          valueFormatter: "#.#'%'",
          granularityEnabled: true,
          granularity: 1
        },
        right: {
          valueFormatter: "#.#'%'",
          granularityEnabled: true,
          granularity: 1,
          enabled:true
        }
        }
      // visibleRange: {x: {min: 1, max: 2}}
    }
  }

  componentDidMount() {

    this.setState(
      update(this.state, {
        data: {
          $set: {
            dataSets: [{
              values: [{x: 4, y: 8}, {x: 5, y: 5}, {x: 6, y: 5}, {x: 7, y: 8}], label: 'A', config: { color: processColor('red'),drawFilled: true,fillColor: processColor('red'), },
            }, {
              values: [{x: 4, y: 105}, {x: 5, y: 90}, {x: 6, y: 130}, {x: 7, y: 100}], label: 'B',config: { color: processColor('blue'),drawFilled: true,fillColor: processColor('blue'), }
            }, ],
          }
        }
      })
    );

// if(this.props.isRightYEnabled){
//   this.setState({
//     right: {
//       valueFormatter: "#.#'%'",
//       granularityEnabled: true,
//       granularity: 1,
//       enabled:true
//     }
//   })
// }else{
//   this.setState({
//     right: {
//       valueFormatter: "#.#'%'",
//       granularityEnabled: true,
//       granularity: 1,
//       enabled:false
//     }
//   })
// }
  }

  onPressLearnMore() {

    this.refs.chart.setDataAndLockIndex({
      dataSets: [{
        values: [
          {x: 1, y: 0.88},
          {x: 2, y: 0.77},
          {x: 3, y: 105},
          {x: 4, y: 135},
          {x: 5, y: 0.88},
          {x: 6, y: 0.77},
          {x: 7, y: 105},
          {x: 8, y: 135}
        ],
        label: 'A',
        config: { color: processColor('red'), }
      }, {
        values: [
          {x: 1, y: 90},
          {x: 2, y: 130},
          {x: 3, y: 100},
          {x: 4, y: 105},
          {x: 5, y: 90},
          {x: 6, y: 130},
          {x: 7, y: 100},
          {x: 8, y: 105}
        ],
        label: 'B',
      }, {
        values: [
          {x: 1, y: 110},
          {x: 2, y: 105},
          {x: 3, y: 115},
          {x: 4, y: 110},
          {x: 5, y: 110},
          {x: 6, y: 105},
          {x: 7, y: 115},
          {x: 8, y: 110}],
        label: 'C',
      }],
    })
  }

  handleSelect(event) {
    let entry = event.nativeEvent
    if (entry == null) {
      this.setState({...this.state, selectedEntry: null})
    } else {
      this.setState({...this.state, selectedEntry: JSON.stringify(entry)})
    }

    console.log(event.nativeEvent)
  }

  render() {
    
    const yAxis = {
      left: {
        valueFormatter: "#.#'%'",
        granularityEnabled: true,
        granularity: 1
      },
      right: {
        valueFormatter: "#.#'%'",
        granularityEnabled: true,
        granularity: 1,
        enabled:this.props.isRightYEnabled
      }
      }
       
    return (
      <View style={{height:screenHeight/2,width:wp('86%')}}>
        

        <View style={styles.container}>
          <LineChart
            style={styles.chart}
            data={this.props.chart_data}
            chartDescription={{text: ''}}
            legend={this.state.legend}
            marker={this.state.marker}
            xAxis={this.state.xAxis}
            yAxis = {yAxis}          

            drawGridBackground={false}
            borderColor={processColor('teal')}
            borderWidth={1}
            drawBorders={true}
            autoScaleMinMaxEnabled={false}
            touchEnabled={true}
            dragEnabled={true}
            scaleEnabled={true}
            scaleXEnabled={true}
            scaleYEnabled={true}
            pinchZoom={true}
            doubleTapToZoomEnabled={true}
            highlightPerTapEnabled={true}
            highlightPerDragEnabled={false}
            // visibleRange={this.state.visibleRange}
            
            dragDecelerationEnabled={true}
            dragDecelerationFrictionCoef={0.99}
            ref="chart"
            keepPositionOnRotation={false}
            onSelect={this.handleSelect.bind(this)}
            onChange={(event) => console.log(event.nativeEvent)}
          />
        </View>

      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5FCFF'
  },
  chart: {
    flex: 1
  }
});

export default Multi_line_chart;