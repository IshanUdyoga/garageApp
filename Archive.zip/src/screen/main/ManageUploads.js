import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Image,
  Animated,
  Alert,
  ScrollView,
  StatusBar,
  Dimensions,
  TouchableOpacity,
  FlatList
} from 'react-native';


let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width


import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import * as firebase from 'react-native-firebase';



import {Content, Accordion , ActionSheet, Button ,Header , Card,Thumbnail, Tab, Tabs, Left,CardItem,DatePicker,  Form, Item, Picker,Badge, Fab ,Body, Icon, Right,ListItem,List, CheckBox, Footer, FooterTab} from "native-base";

export default class ManageUploads extends Component {

  static navigationOptions = {
    title:"",
    headerTintColor: 'black',

    headerStyle: {
        backgroundColor: 'transparent',
     
        },

    }




    constructor(props) {
  
      super(props);
      
      this.drawer = React.createRef();
      this.modalDetails = React.createRef();
              this.state={

                  image_slider:[],
                  cat_Data:[],
                  deals_Data:[],
                  sub_cat_Data:[],
                  hot_news_Data:[],
                  prod_Data: [],
                  word_Data: [],
                  req_data:[],
                  choosenLabel: '', 
                  choosenindex: '',
                  photo: null,

                  refreshing:false,
                  isLoading:false,
          

                  msgKey:'',

                  cat_id:'',

                  
        
              };
  
              
  
    }

    


    componentDidMount(){
      this.fetch_real_time_data()

            }



    fetch_real_time_data(){
       this.unsubscribe= firebase.database().ref('app_data');
      this.unsubscribe.once('value', snapshot => {

        let categories = snapshot.child("categories");

        const cat_Data = [];
        
        categories.forEach((doc) => {
          cat_Data.push({
            key:doc.key,
            ...doc.toJSON(),
          })
        })
    
        this.setState({
          cat_Data:cat_Data,
       
        })
      });
    }



  render() {


    

    return (
      <View style={styles.container}>
                
                <ScrollView style={styles.scrollSS}>
                            

                <View style={{
                  marginLeft:wp('3%'),
                  marginRight:wp('3%'),
                  marginTop:hp('1%')
                }}>
                            

                <Text style={styles.TopicText}>Category item changes</Text>


                <View style={{margin:5,marginBottom:deviceHeight/40,marginTop:deviceHeight/40,borderRadius:3,borderWidth:1,borderColor:'#40B043'}}>
                    <Picker    style={styles.PickerStyle} 

                            iosIcon={<Icon name="md-arrow-dropdown" />}
                    
                    
                        selectedValue={this.state.choosenLabel}
 
                        onValueChange={(itemValue, itemIndex) => this.setState({
                        choosenLabel: itemValue, 
                        choosenindex:itemIndex})} >
 
                        { this.state.cat_Data.map((item, key)=>(
                        <Picker.Item label={item.cat_name} value={item.cat_id} key={key} />)
                        )}

    
                    </Picker>
        
                    </View>

                      </View>


          


                <View>


                
              <FlatList
                        
                        data={this.state.cat_Data}
                        keyExtractor={(x, i) => i}
                        renderItem={({ item }) =>(
         
              
                          <List>
                          <ListItem avatar>
                            <Left>
                              <Thumbnail source={{ uri: item.cat_image_url }} />
                            </Left>
                            <Body>
                              <Text>{item.cat_name}</Text>

                              <View style={{marginLeft:wp('3%'),marginRight:wp('3%')}}>

                              <View style={{flexDirection:'row'}}>
                                
                                <View style={{flex:0.50,margin:5}}>          
                                <TouchableOpacity style={styles.login}   onPress={() => this.props.navigation.navigate("TamilLanguage")}>
                                      <Text style={styles.btnFont}
                                        >Add</Text>
                                      </TouchableOpacity>      
                                </View>
          
                                <View style={{flex:0.50,margin:5}}>  
                                      <TouchableOpacity style={styles.login}   onPress={() => this.props.navigation.navigate("TamilLanguage")}>
                                      <Text style={styles.btnFont}
                                        >Update</Text>
                                      </TouchableOpacity>  
                                      </View> 
          
          
                                <View style={{flex:0.50,margin:5}}>  
                                      <TouchableOpacity style={styles.login}   onPress={() => this.props.navigation.navigate("TamilLanguage")}>
                                      <Text style={styles.btnFont}
                                        >Delete</Text>
                                      </TouchableOpacity>  
                                      </View> 
                                        
                                      </View>
                                      </View>
                              
                            </Body>
                          
                          </ListItem>
                        </List>
         
                     )}
                     />









                </View>


     
                
                
                
                
                
                </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  body:{
    flex:1
  },
  scrollSS:{
    width:'100%',
  },
  top_slider:{
    width:'100%',
    height:hp('28%'),
    backgroundColor: '#898989',
  },
  
  btnFont:{
    color:'#fff',
    fontSize: hp('2.5%'),
    fontWeight:'bold',
    paddingBottom:hp('0.5%')
    },

  
  login:{
    marginVertical:hp('1.0%'), 
    width:'100%',
    alignItems:'center',
    justifyContent:'center',
    height:hp('5%'),
    backgroundColor: '#40B043',
  },
  login_btn_pad:{
    height:hp('11%'),
    width:'100%',
    marginTop:-hp('2.3%'),
    paddingHorizontal:wp('5%'),
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5
  },
  btn: {
    borderWidth: 1,
    paddingLeft: 20,
    paddingRight: 20,
    paddingTop: 10,
    paddingBottom: 10,
    borderRadius: 20,
    borderColor: 'rgba(0,0,0,0.3)',
    backgroundColor: 'rgb(68, 99, 147)'
  },
  btnTxt: {
    color: '#fff'
  },
  image: {
    marginTop: 20,
    minWidth: 200,
    height: 200
  },

  login_btn:{
    height:'65%',
    width:'40%',
    borderRadius:hp('1.5%'),
    backgroundColor:'#40B043',
    justifyContent: 'center',
    alignItems:'center'

  },
  PickerStyle:{
    //borderBottomWidth:1, 
   // borderColor: '#ccc600',
    width:'100%',

   
  
  

},
  login_txt:{
    fontSize:hp('2.5%'),
    fontFamily: 'seg_light',
    color:'#fff',
    marginTop:-hp('2%')
  },
  UploadText:{
      
    fontSize:hp('2.5%'),
    fontWeight:'bold',
    color:'#000',
    padding:hp('2%'),


  },
  

  SildeShowUploads:{

    flexDirection:'row'


  },
  TopicText:{

    fontWeight:'bold',
    margin:3,
    color:'#000'


  },


  button: {

    marginBottom: deviceHeight/50,
    height: deviceHeight/15,
    width:100,
  
    backgroundColor:'#38D252',
    
    borderWidth: 1,
    borderColor:'#38D252',



    shadowColor: '#000',
    shadowOffset: {
        width: 0,
        height: 0.5
    },
    shadowOpacity: 0.2,
    shadowRadius: 2,

},

buttonbox: {
      
        
    alignItems: 'center',
    //flex: 0.3,
   backgroundColor: 'transparent',
    padding: deviceHeight/50,
    marginBottom: deviceHeight/50,

},
});