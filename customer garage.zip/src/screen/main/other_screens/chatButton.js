import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions,
  TouchableOpacity,
  Image
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import MsgBox from '../other_screens/msgBox'

export default class ChatButton extends Component {

    constructor(props) {
  
        super(props);
        this.message = React.createRef();
                this.state={
                    
                };
    
      }


      openCmnts(){
        const msgKey = this.props.uid
        this.message.current.mainFunc(msgKey);
      }


  render() {
    return (
        <TouchableOpacity style={styles.chat_con} onPress={()=> this.openCmnts()}><View style={styles.chat_con_view}>
        <Image source={{ uri: `asset:/images/img_icons/ico_chat.png`}} style={styles.icoChat} /></View>
        
        <MsgBox uid={this.props.uid} ref={this.message}/>
        </TouchableOpacity>
    );
  }
}

const styles = StyleSheet.create({

chat_con:{
  position:'absolute',
  bottom:hp('7.5%'),
  right:hp('1%'),
},

chat_con_view:{
  height:hp('7%'),
  width:hp('7%'),
  borderRadius:hp('15%') ,
  backgroundColor: '#f96092',
  justifyContent: 'center',
  alignItems: 'center',

  elevation:2,
  //shadowOffset: { width: 5, height: 5 },
  shadowColor: "grey",
  shadowOpacity: 0.5,
  shadowRadius: 10,
},

icoChat:{
  height:hp('5%'),
  width:hp('5%'),
}

});