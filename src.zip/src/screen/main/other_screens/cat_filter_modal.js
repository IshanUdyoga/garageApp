import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions,
  Modal,
  TouchableOpacity,
  FlatList
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';


export default class Cat_filter_modal extends Component {
  render() {
    return (
        <Modal visible={this.props.visible} avoidKeyboard={true} 
        animationType={'slide'}
        transparent={true}>
   
       <View style={styles.container}>
       <TouchableOpacity style={{height:50,width:50,backgroundColor: 'blue',}} onPress={()=>this.props._this.setState({is_modal_visible:false}) }>
           </TouchableOpacity>
       <FlatList 
                          
                          data={this.props.all_main_cat}

                          keyExtractor={(item, index) => item.id}

                        //ListEmptyComponent={this.emptymsgFun()}
                          //contentContainerStyle={styles.main_cat_LIST}

                          

                          renderItem={({ item, index }) =>
<View>
                                <TouchableOpacity style={styles.main_cat_pad}   onPress={()=>alert(JSON.stringify(this.props.all_main_cat))}>
                                    
                                    <Text>{item.p_name}</Text>
                                </TouchableOpacity>
</View>
                        }
                      //refreshing={this.state.refreshing}
                      // onRefresh={() => this.handleRefresh()}
                        />

       </View>


       </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  main_cat_pad:{
    height:hp('10%'),
    width:wp('100%'),
    marginBottom: hp('5'),
    backgroundColor: '#ddd',

  }

});