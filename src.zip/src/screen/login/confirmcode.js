import React from 'react';
import {
    StyleSheet,
    View,
    ImageBackground,
    TouchableOpacity,
    Image,
    Text,
    KeyboardAvoidingView,
    AsyncStorage,
    Alert,
    ActivityIndicator,
    Dimensions,
    Easing,
    ScrollView,
    Animated,
    Keyboard,
    TextInput
} from 'react-native';
import stringsoflanguages from '../../screen/lng/stringsoflanguages';

import {
    Container, Header, Title, InputGroup, Content, Footer, FooterTab, Button, Icon, Left, Right, Body, Input, Form, Item, Label
} from 'native-base';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import logo from '../../../src/img/logo.png';
import { withNavigationFocus } from 'react-navigation';

let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;

const IMAGE_HEIGHT = hp('24%');
const IMAGE_HEIGHT_SMALL = hp('10%');

let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width



class ConfirmCode extends React.Component {
    static navigationOptions = {
        header: null
    };
    constructor(props) {
        super(props)
        this.state = ({
            randomcode: '',
            userMail:'',
            
            userID:'',
            loading:false
        })

        this.imageHeight = new Animated.Value(IMAGE_HEIGHT);

    }


    


      
    componentWillMount () {
        AsyncStorage.getItem('emailid').then((value) => {
            this.setState({userMail:value});
         });
  
        this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
        this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
       
      }
   

      componentWillReceiveProps(nextProps) {
        if(this.props.isFocused && nextProps.isFocused){
          //console.log('not running anything')
          
        }
        
        if(this.props.isFocused && !nextProps.isFocused){
         // console.log('ufocus')
        this.setState({UserEmail: '',})
        this.keyboardWillShowSub.remove();
        this.keyboardWillHideSub.remove();
        
        }
        
        if(!this.props.isFocused && nextProps.isFocused){
        //  console.log('focus')
        this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
        this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
        
       }
            
              
      }



      keyboardDidShow = (event) => {
        Animated.timing(this.imageHeight, {
          toValue: IMAGE_HEIGHT_SMALL,
        }).start();
    
     
        
      };
    
      keyboardDidHide = (event) => {
        Animated.timing(this.imageHeight, {
          toValue: IMAGE_HEIGHT,
        }).start();
    
       
      };
    


      

    resetpasswordFunction = () => {

        const { randomcode }   = this.state;
        const {  userMail }   = this.state;
        
        this.setState({
            loading:true
          });

        fetch('https://www.foodapp.enricharcane.com/mobileapp/confirmcode.php', {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({

                code: randomcode,
                email: userMail,
               

            })

        }).then((response) => response.json())
            .then((responseJson) => {

           
                if (responseJson.DataMatched=='true') {

                    
                    
                      

                        this.setState({
                           
                            loading:false
                          });
                
                        
                   alert('Code Matched !')
                   this.props.navigation.navigate('Setnewpw');
                    
                }
                else {
                    this.setState({
                        loading:false
                      });
                    Alert.alert('login', responseJson);
                }

            }).catch((error) => {
                console.error(error);
            });

    }

    LL(){
        if(this.state.loading){
          return(<View style ={styles.Load} >
    
           <View style={styles.LoadSub}>
           <ActivityIndicator size="large"  color='#fff'/>
             </View>
    
        </View>)
        }else{
          return(<View />)
        }
      }

    


    render() {
        return (
          <ImageBackground style={{flex:1,alignItems:'center'}} source={{ uri: `asset:/images/img_backgrounds/login_back.png`}}>
           <View style={styles.main_container}>
    
    
           <Animated.Image source={logo} style={[styles.logo, { height: this.imageHeight }]} />
    
           <View style={styles.sub_container}>
           <ScrollView contentContainerStyle={{flexGrow:1,justifyContent: 'center',minHeight: hp('20%'),}}>
          
             <KeyboardAvoidingView
            style={styles.container}
            behavior="padding"
          >
        <View style={styles.container_pad}>
    
                             <View  >
                            <Text style={styles.forgPass_txt}>Reset Your Password</Text>
                            </View>
    
    
          <View style={styles.mainV}>
                      <View style={styles.iconV}>
                        <Image source={{ uri: `asset:/images/img_icons/ico_input_lock.png`}} style={styles.input_icon_St} />
                      </View>
    
    
                         <View style={styles.textV}>
                                     <TextInput
                                        placeholder="Password reset code"
                                        placeholderTextColor="#979797"
                                        style={styles.input}
                                        value={this.state.randomcode}
                                        autoCorrect={false}
                                        autoCapitalize="none"
                                        onChangeText={randomcode => this.setState({ randomcode })}
                                    />
                        </View>
    
           </View>
    
       
    
    
    
             
            
          <TouchableOpacity style={styles.login}  onPress= {() => this.props.navigation.navigate('Setnewpw') }>
            <Text style={styles.btnFont}
          >Confirm</Text>
          </TouchableOpacity>
    
              
          </View>    
          </KeyboardAvoidingView>
    
                        <View style={styles.footer_logo}>
                        {/* <Image source={{ uri: `asset:/images/img_icons/logo.png`}} style={styles.footer_img} /> */}
                        </View>
          </ScrollView>
    
          
          
    
          
    
          </View>
    
                        </View>
    
                        <TouchableOpacity style={styles.backbtn}  onPress= {() =>this.props.navigation.goBack()}>
                        <Image source={{ uri: `asset:/images/img_icons/ico_go_back.png`}} style={styles.back_icon_St} />
                        </TouchableOpacity>
    
    
                    {this.LL()}
                      
          </ImageBackground>
        );
      }
    };
    
    
    const styles = StyleSheet.create({
      main_container:{
        flex:1,
        alignItems:'center',
        backgroundColor: 'rgba(255, 255, 255, 0.73)',
      },
    
      sub_container:{
        flex:1,
        alignItems:'center',
      },
    
        container: {
            flex: 0.7,
            alignItems: 'center',
            width: wp('100%'),
          },
    
          container_pad: {
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            width: '85%',
          },
    
    
          input: {
            height: hp('8%'),
            width:'90%',
            paddingBottom: 0,
            paddingLeft: wp('5%'),
            fontSize:hp('3.3%'),
            fontFamily: 'seg_light',
            color:'#383838',
            
            
          },
          logo: {
            height: IMAGE_HEIGHT,
            resizeMode: 'contain',
            marginTop:hp('11%'),
            marginBottom:hp('3%'),
            borderRadius: hp('2%'),
          },
          login:{
            marginTop:hp('5%'), 
            marginBottom:hp('10%'),
            width:'100%',
            alignItems:'center',
            justifyContent:'center',
            borderRadius:hp('3.25%'),
            height:hp('6%'),
            backgroundColor: '#7b7b7b',
          },
    
    
            register:{
              marginTop: hp('1.2%'),
              marginBottom: hp('2%'),
              width:window.width -50,
              alignItems:'center',
              justifyContent:'center',
              borderRadius: window.height/26,
              height:window.height/13,
              backgroundColor: 'rgba(249, 249, 249, 0.40)',
            },
    
    
    
            mainV:{
                flex:0.2,
                flexDirection:'row',
                width:'100%',
                //marginBottom: hp('3%'),
                borderBottomWidth: 1,
                borderColor: '#cccccc',
            },
    
            iconV:{
                flex:0.2,
                justifyContent: 'flex-end',
                alignItems: 'center',
            },
            textV:{
                flex:0.8,
                justifyContent: 'flex-end',
            },
    
    
            iconP:{
              flex:0.2,
              justifyContent: 'flex-end',
              alignItems: 'center',
          },
          textP:{
              flex:0.6,
              justifyContent: 'flex-end',
          },
          eyeP:{
              flex:0.2,
              justifyContent: 'flex-end',
              alignItems: 'flex-end',
          },
    
    
            iconSty:{
                color:'#fff'
            },
    
            tttop:{
              position:'absolute',
          top:-window.height/2.5
            },
    
    
      Load:{
        position:'absolute',
      },
    
      LoadSub:{
        height:hp('100%'),
        width:window.width,
        backgroundColor:'rgba(0, 0, 0, 0.8)',
        justifyContent: 'center',
        alignItems: 'center',
    
      },
      btnFont:{
        color:'#fff',
        fontFamily: 'seg_sem_light',
        fontSize: hp('2.5%'),
        paddingBottom:hp('0.5%')
      },
    
      btnFont2:{
        color:'#fff',
        fontWeight:'bold',
        fontSize: hp('2%')
      },
    
    
      back_3Pad:{
        position:'absolute',
        
        
      },
      back_3:{
        height:hp('15%'),
        width:wp('100%'),
        resizeMode: 'contain',
      },
      userType:{
        position:'absolute',
        height:hp('100%'),
        width:wp('100%'),
      },
    
      imageTypeBack:{
        height:'100%',
        width:'100%',
        justifyContent: 'center',
        alignItems:'center'
      },
    
      backbtn:{
        position:'absolute',
        left:-wp('2%'),
        padding:hp('1%')
      },
    
      sign_up_con:{
        position:'absolute',
        right:wp('5%'),
        top:'2.5%',
      },
    
      backbtnIco:{
        fontSize:hp('8%'),
        color:'#fff'
      },
      rePassTXT:{
        color:'#fff'
      },
    
      fbBtn:{
        height:50,
        paddingHorizontal: 20,
        justifyContent: 'center',
        alignItems:'center',
        backgroundColor: 'green',
      },
    
      back_icon_St:{
        height:hp('11%'),
        width:hp('11%')
      },
    
      sign_st:{
        fontSize:hp('4.3%'),
        fontFamily: 'seg_light',
        color:'#8e8f8f'
      },
    
      input_icon_St:{
        height:hp('6%'),
        width:hp('6%'),
        opacity:0.8
      },
    
      eye_icon_St:{
        height:hp('5%'),
        width:hp('5%'),
        marginBottom:hp('0.5%')
      },
    
      forgPass:{
        width:'100%',
        alignItems:'flex-end',
        marginBottom:hp('3%')
      },
      forgPass_txt:{
        marginTop:-hp('5%'),
        fontSize:hp('2%'),
        color:'#979797',
      },
    
      social_btn_con:{
        marginTop:hp('4%'),
        flexDirection:'row',
        justifyContent: 'center',
        width:'100%'
      },
    
      btn_con:{
        height:hp('6.3%'),
        width:hp('6.3%'),
        borderRadius:hp('5%'),
        backgroundColor: '#949494',
        justifyContent: 'center',
        alignItems: 'center',
        overflow: 'hidden',
      },
    
      social_icon_St:{
        width:'90%',
        height:'90%'
      },
    
      social_icon_St_we:{
        width:'80%',
        height:'80%'
      },
    
      login_Wi_st:{
        width:'100%',
        alignItems: 'center',
        marginBottom:hp('5%')
      },
    
      login_w_txt:{
       // marginBottom:hp('8%'),
        fontSize:hp('2%'),
        color:'#979797',
      },
    
      footer_logo:{
        position:'absolute',
        bottom:0,
        right:'3%'
      },
    
      footer_img:{
        height:hp('6%'),
        width:hp('18%'),
      }
    
      });
    
    
      export default withNavigationFocus(ConfirmCode);