import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions,
  FlatList,
  ScrollView,
  ActivityIndicator,
  TouchableOpacity,
  Image,
  ImageBackground,
  Linking
} from 'react-native';

import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import SlideshowTest from '../slider'
import sort from 'fast-sort';


var ITEM_WIDTH = wp('65%')
var offSET = wp('7.5%')
export default class Tab_1 extends Component {

  constructor(props) {
    super(props);
 
    this.state = {
      is_modal_visible:false,
    
    };
  }
 
  componentDidMount() {
 
  }


navigate_from(id){
  this.props._this.props.navigation.navigate('Product_list',{CatId:id})
}


sort_gp_1(){
  var arr=this.props.cat_Data.filter(function(itemx){return itemx.group_type == 'gp1' || itemx.group_type == 'gp1/gp2';})

  return  sort(arr).desc(s => s.firstName);
}


openLink(link){
  if(link !== null){
      Linking.openURL(link)
      }else{
      
      }
}

  render() {
    if(!this.props.isLoading){
    return (
      <View style={styles.container}>
        <ScrollView style={styles.scrollSS}>

        <View style={styles.top_slider}>
                <SlideshowTest image_slider={this.props.image_slider}/>
            </View>

  


            <View style={styles.main_cat}>
          
                      <FlatList 
                          
                          data={this.props.cat_Data.filter(function(itemx){return itemx.group_type == 'gp1' || itemx.group_type == 'gp1/gp2';})}

                          keyExtractor={(item, index) => item.sell_uid}

                        //ListEmptyComponent={this.emptymsgFun()}
                        contentContainerStyle={styles.main_cat_LIST}

                        numColumns={3}


                          renderItem={({ item, index }) =>
                              <View>
                                <TouchableOpacity style={styles.main_cat_item_pad} 
                                 onPress={()=> this.navigate_from(item.cat_id)}>
                                    <Image
                                                style={styles.cat_icon_img}
                                                source={{uri : item.cat_image_url}}
                                            />
                                    
                                </TouchableOpacity>
                                  <Text style={styles.cat_txt}>{item.cat_name}</Text>
                                </View>

                        }
                      //refreshing={this.state.refreshing}
                      // onRefresh={() => this.handleRefresh()}
                        />
                   
            </View>

           



                <View style={{flexDirection:'row'}}>
                                
                                <View style={{flex:1,marginLeft:wp('2%'),marginRight:wp('2%')}}>          
                                <TouchableOpacity style={styles.login}   onPress={()=> this.props._this.props.navigation.navigate('ManageUploads')}>
                                      <Text style={styles.btnFont}
                                        >Manage Categories</Text>
                                      </TouchableOpacity>      
                                </View>
          
                                      </View>

          <View />
                        
            

            <Text style={styles.deals_txt}>New Parts</Text>
            <View style={styles.cal_this}>

                <FlatList 
                        
                        data={this.props.deals_Data}

                        keyExtractor={(item, index) => item.deals_id}

                        horizontal={true}
                      //ListEmptyComponent={this.emptymsgFun()}
                        contentContainerStyle={styles.cal_this_flat}

                        //snapToAlignment={'center'}
                          
                        initialNumToRender={2}
                        initialScrollIndex={2}

                        showsHorizontalScrollIndicator={false}

                        getItemLayout={(data, index) => (
                          {length:ITEM_WIDTH, offset: (ITEM_WIDTH * index)-offSET, index}
                        )}

                        renderItem={({ item, index }) =>

                              <TouchableOpacity style={styles.cal_this_item_body} onPress={()=> this.openLink(item.deals_link)}>
                                <Image
                                                style={styles.cal_this_img}
                                                source={{uri : item.deals_url}}
                                            />
                              </TouchableOpacity>
                        
                      }
                      
                      />

            </View>

          


                      <View style={[styles.head_pad_st,{marginTop:hp('2%'),marginBottom:-hp('2.8')}]}>
                      <View style={styles.header_what_u_Con}>
                        <View style={styles.header_icon_con}>
                            <View style={styles.header_icon_con_2}>
                            <Image source={{ uri: `asset:/images/img_icons/ico_news.png`}} style={styles.title_icon_St} />
                            </View>
                        </View>

                        <View style={styles.header_txt_con}>
                           <Text style={styles.what_u_txt}>Offers</Text>
                        </View>

                      
                      </View>
            </View>


                      <View style={styles.news_body}>
                      <FlatList 
                          
                          data={this.props.hot_news_Data}

                          keyExtractor={(item, index) => item.sell_uid}

                        //ListEmptyComponent={this.emptymsgFun()}
                        contentContainerStyle={styles.news_body_flat}


                          renderItem={({ item, index }) =>

                                <View style={styles.prod_main_st} onPress={()=> this.openLink(item.news_link)}>
                                <ImageBackground
                                                style={styles.img_back_st}
                                                source={{uri : item.news_url}}
                                            >
                                    <View style={styles.background} o>
                                    <Text style={styles.news_chin_txt}>{item.news_title}</Text>
                                    </View>
                                    </ImageBackground>
                                </View>

                        }
                        />
                        </View>





                        <View style={styles.about_wordings}>
                      <FlatList 
                          
                          data={this.props.word_Data}

                          keyExtractor={(item, index) => item.word_id}

                        //ListEmptyComponent={this.emptymsgFun()}


                          renderItem={({ item, index }) =>

                                <View style={styles.wordings_main_st}>
                                      <View style={styles.main_word_con}>
                                            <View style={styles.col_1}>
                                              <View style={styles.imgCon}>
                                                <Image source={{ uri: item.img_ico_url}} style={styles.word_icon_St} />
                                              </View>
                                              </View>

                                              <View style={styles.col_2}>
                                                      <View style={styles.row_1}>
                                                        <Text numberOfLines={1} style = {styles.title_txt}>{item.word_title}</Text>
                                                        </View>

                                                        <View style={styles.row_2}>
                                                        <Text numberOfLines={2} style = {styles.des_txt}>{item.word_descrip}</Text>
                                                        </View>
                                                </View>
                                        </View>
                                </View>

                        }
                        />
                        </View>


  

          
        </ScrollView>
      </View>
    )
  }else{
    return(
    <View style={styles.loading}>
         <ActivityIndicator size="small" color="#777" />
    </View>)
  }

  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fbfbfc',
  },
  body:{
    flex:1,
    width:'100%',
    backgroundColor: 'blue',
    paddingTop: hp('2%'),
  },
  prod_main_st:{
    height:hp('16%'),
    width:'100%',
    marginBottom: hp('2%'),
    backgroundColor: '#ddd',
    borderRadius:hp('1%'),
    overflow: 'hidden',

  },

  scrollSS:{
    width:'100%',
  },

  background:{

    backgroundColor: 'rgba(0, 0, 0, 0.38)',
    height:hp('5%'),


  },

  top_slider:{
    width:'100%',
    height:hp('28%'),
    backgroundColor: '#898989',
  },

  main_cat:{

    width:'100%',
    marginTop:hp('2%')
  },

  login_btn_pad:{
    height:hp('11%'),
    width:'100%',
    marginTop:-hp('2.3%'),
    paddingHorizontal:wp('5%'),
    justifyContent: 'center',
    alignItems: 'center',
  },

  login_btn:{
    height:'65%',
    width:'100%',
    borderRadius:hp('1.5%'),
    backgroundColor:'#40B043',
    justifyContent: 'center',
    alignItems:'center'
  },


  cal_this:{
    height:hp('22%'),
    paddingVertical: hp('1%'),
    width:'100%',
    //backgroundColor: '#5b5b5b',
  },
  head_pad_st:{
    paddingHorizontal:wp('5%'),
    height:hp('8.5%'),
    width:'100%',
    marginTop:hp('3%'),
    marginBottom:-hp('1.5%')
  },

  header_what_u_Con:{
    height:'100%',
    width:'100%',
    borderRadius:hp('1%'),
    backgroundColor: '#f04545',
    flexDirection: 'row',
  },

header_icon_con:{
  width:hp('9.5%'),
  height:'100%',
  padding: hp('0.9%'),
},

header_icon_con_2:{
  width:'100%',
  height:'100%',
  borderRadius: hp('1%'),
  backgroundColor: '#fff',
},

header_txt_con:{
height:'100%',
width:'100%',
justifyContent: 'center',

},
login:{
  marginVertical:hp('1.0%'), 
  width:'100%',
  alignItems:'center',
  justifyContent:'center',
  height:hp('7%'),
  backgroundColor: '#40B043',
},

what_u_txt:{
  marginTop:-hp('1%'),
  marginLeft: wp('2%'),
  fontSize:hp('3.3%'),
  color:'#fff',
  fontFamily: 'seg_light',
},

  news_body:{
    marginTop:hp('5%'),
    paddingHorizontal:wp('5%')
  },

  main_cat_LIST:{
    flex:1,
    width:'100%',
    paddingTop: hp('2%'),
    alignItems:'center',
  },

  main_cat_item_pad:{
    height:hp('9.5%'),
    width:hp('9.5%'),
    borderRadius: hp('5%'),
    marginHorizontal: hp('3.5%'),
    borderWidth: 1,
    borderColor: '#2cba5b',
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignItems: 'center',
  },

  cat_txt:{
    marginTop:hp('0.8%'),
    marginBottom:hp('2.8%'),
    fontSize:hp('1.8%'),
    textAlign:'center'
  },

  loading:{
    flex:1,
    width:'100%',
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#fbfbfc',
  },

  login_txt:{
    fontSize:hp('3%'),
    fontFamily: 'seg_light',
    color:'#fff',
    marginTop:-hp('1%')
  },

  cat_icon_img:{
    height:hp('5.4%'),
    width:hp('5.4%'),
  },

  cal_this_flat:{
    height:'100%',
  },

  cal_this_item_body:{
    height:'100%',
    width:wp('65%'),
    backgroundColor: '#ddd',
    marginHorizontal: wp('2%'),
    borderRadius:hp('1%'),
    overflow: 'hidden',
  },

  cal_this_img:{
    height:'100%',
    width:'100%'
  },
  sub_cat_container:{
    paddingHorizontal:wp('3.5%'),
  },

  sub_cat_flat:{
    flex:1,
    width:'100%',
    paddingVertical: hp('2%'),
    //alignItems:'center',
  },

  sub_cat_st:{
    height:hp('20%'),
    width:'50%',
    paddingTop: hp('1.5%'),
    paddingHorizontal:wp('1.5%'),
    //paddingHorizontal: wp('2%'),
    
  },

  sub_cat_bd:{
    height:'100%',
    width:'100%',
    borderRadius:hp('1%'),
    justifyContent: 'center',
    alignItems:'center'
    
  },

  sub_cat_img:{
    height:hp('10%'),
    width:hp('10%'),
  },

  sub_txt:{
    fontSize:hp('2.2%'),
    color:'#fff',
    marginTop:-hp('1%'),
    fontFamily: 'seg_light',
    textAlign:'center'
  },

  news_body_flat:{

  },

  img_back_st:{
height:'100%',
width:'100%',
justifyContent: 'flex-end',
  },

  news_chin_txt:{
    color:'#fff',
    fontSize:hp('2.7%'),
    paddingLeft:hp('2%'),
    fontWeight: 'bold',
  },

  deals_txt:{
    fontSize:hp('2.8%'),
    marginTop:-hp('1%'),
    marginLeft: wp('5%'),
    color:'#000',
    fontFamily: 'seg_light',
  },

  title_icon_St:{
    width:'100%',
    height:'100%'
  },

  about_wordings:{
    marginTop:hp('3.5%'),
    marginBottom:hp('3%'),
    paddingHorizontal:wp('5%')
  },

  wordings_main_st:{
    height:hp('13%'),
    width:'100%',
    //marginBottom:hp('5%')
  },

  main_word_con:{
    height:'100%',
    width:'100%',
    flexDirection:'row'
  },
  col_1:{
    width:wp('12%'),
    height:'100%',
  },

  col_2:{
    width:'100%',
    height:'100%',
  },

  row_1:{
    height:wp('7%'),
    width:'100%',
  },

  btnFont:{
    color:'#fff',
    fontSize: hp('2.5%'),
    fontWeight:'bold',
    paddingBottom:hp('0.5%')
    },

  row_2:{
    height:'100%',
    width:'100%'
  },

  word_icon_St:{
    width:wp('6%'),
    height:wp('6%'),
  },

  imgCon:{
    width:wp('8%'),
    height:wp('8%'),
    borderRadius:wp('9%'),
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#d8d8d8',
  },

  title_txt:{
    fontSize:hp('2.7%'),
    color:'#747476'
  },

  des_txt:{
    fontSize:hp('2%'),
    color:'#b2b2b2'
  }

});