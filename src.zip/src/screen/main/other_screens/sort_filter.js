import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  StatusBar,
  Dimensions,
  Modal,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Picker,
  Slider,
  TextInput,
  AsyncStorage
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons'
import RadioForm, {RadioButton, RadioButtonInput, RadioButtonLabel} from 'react-native-simple-radio-button';
import Header from '../../main/header'
import { TextInputMask } from 'react-native-masked-text';
import NumberFormat from 'react-number-format';
import Drawer from '../../main/drawer'


var radio_props_gender = [
    {label: 'Male', value: 1 },
    {label: 'Female', value: 2 }
  ];

  var radio_smk_stat = [
    {label: 'Smoking', value: 1 },
    {label: 'Non-Smoking', value: 2 }
  ];

  var radio_benefit = [
    {label: 'Basic Benefit', value: 1 },
    {label: 'Supplementary Major Medical Benefit', value: 2 }
  ];

  var radio_deductible = [
    {label: 'None', value: 1 },
    {label: '10000 - 20000', value: 2 },
    {label: '20001 - Up', value: 3 }
  ]; 

  var radio_props_no_of_child = [
    {label: '0', value: '0' },
    {label: '1', value: '1' },
    {label: '2', value: '2' },
    {label: '3', value: '3' },
  ];



export default class Sort_filter extends Component {


    setValues(val){
        this.setState({sort_by: val})
        alert(val)
    }

    constructor(props) {
      super(props);
      this.drawer = React.createRef();
  
      var paym_tmVal = '';
      var cat_idVal = '0';
      var grp2_cntryVal = '';

      if (this.props.navigation.state.params) {
        const { params } = this.props.navigation.state;
        paym_tmVal= params.pay_term;
        cat_idVal = params.id;
        grp2_cntryVal = params.grp2_cntry_or_other;
    }
      this.state = {

        age:0,
        childAge:0,
        retireAge:0,
        gender_value:1,
        no_child:'0',
        smk_value:1,
        benefit_value:1,
        deductible_value:1,
        sum_insured:30000,
        annual_premium:30000,
        paym_tm_s_val:'10',
        sort_by:'',
        paym_tm:paym_tmVal == null ? '' : paym_tmVal,
        cat_id_s:cat_idVal == null ? '1' : cat_idVal,
        paym_tm_arr:[],

        grp2_cntry:grp2_cntryVal == null ? '' : grp2_cntryVal,
        grp2_s_value:null,
        grp2_cntry_arr:[],

        login_btn_active:true,
        isOpen:false,
        loginTXT:'Login',
      };
    }

    toggleDrawer=()=>{
      if(this.state.isOpen){
         this.drawer.current.closeDrawer();
        
      }else{
         this.drawer.current.openDrawer();
        
  
      }
  }


  componentDidMount (){
      this.getGrp2_cntry_or_other()
      this.getPaymentTerms()
     this.set_sum_ann()

     AsyncStorage.getItem("isLoggedIn").then((value) => {
      if(value === 'true'){
        this.setState({login_btn_active:true,loginTXT:'Sign-out',})
      }else{
        this.setState({login_btn_active:false,loginTXT:'Login',})
      }

    })
    .then(res => {
        
    });
  }

 set_sum_ann(){
   const cat_id_s = this.state.cat_id_s
   if(cat_id_s === '1'){
    this.setState({
      sum_insured:null,
      annual_premium:30000
    })
   }else if(cat_id_s === '2'){
    this.setState({
      sum_insured:30000,
      annual_premium:null
    })
   }else if(cat_id_s === '3'){
    this.setState({
      sum_insured:null,
      annual_premium:30000
    })
   }else if(cat_id_s === '4'){
    this.setState({
      sum_insured:30000,
      annual_premium:null
    })
   }else{
    this.setState({
      sum_insured:null,
      annual_premium:null
    })
  }

 }


  getPaymentTerms(){
    var paytm = this.state.paym_tm
    var PaymentArr = paytm.split(",");
    var yrVal ;
      if(this.state.cat_id_s === '6' || this.state.cat_id_s === '5' || this.state.cat_id_s === '8'){
        yrVal = ''
      }else{
        yrVal = ' Years'
      }
    var arr =[]
   
   PaymentArr.forEach((doc) => {
          arr.push({label: doc + yrVal, value: doc })
        })

        this.setState({paym_tm_arr:arr,paym_tm_s_val:arr[0].value})

  }



  getGrp2_cntry_or_other(){
    var grp2_cntry = this.state.grp2_cntry
    var grp2_cntryArr = grp2_cntry.split(",");

    var arr =[]
   
    grp2_cntryArr.forEach((doc) => {
          arr.push({label: doc, value: doc })
        })

        this.setState({grp2_cntry_arr:arr,grp2_s_value:arr[0].value})
 
  }

  onSubmit(){
    const { 
      age,
      childAge,
      gender_value,
      smk_value,
      paym_tm_s_val,
      sum_insured,
      annual_premium,
      benefit_value,
      deductible_value,
      cat_id_s,
      grp2_s_value,
      no_child,
      retireAge,
    }   = this.state;

if(cat_id_s === '1' || cat_id_s === '3'){
  if(annual_premium<30000){
    alert('Annual Premium must be greater than $30,000 !')
  }else{
    this.props.navigation.navigate('Product_list',
    { age,
      childAge,
      gender_value,
      smk_value,
      benefit_value,
      paym_tm_s_val,
      sum_insured,
      annual_premium,
      deductible_value,

      grp2_s_value,
      no_child,
      retireAge,
    });

  }
}else{

  if(cat_id_s === '2' || cat_id_s === '4'){
    if(sum_insured<30000){
      alert('Sum Insured must be greater than $30,000 !')
    }else{
      this.props.navigation.navigate('Product_list',
      { age,
        childAge,
        gender_value,
        smk_value,
        benefit_value,
        paym_tm_s_val,
        sum_insured,
        annual_premium,
        deductible_value,
  
        grp2_s_value,
        no_child,
        retireAge,
      });
  
    }
  }else{
    this.props.navigation.navigate('Product_list',
    { age,
      childAge,
      gender_value,
      smk_value,
      benefit_value,
      paym_tm_s_val,
      sum_insured,
      annual_premium,
      deductible_value,
  
      grp2_s_value,
      no_child,
      retireAge,
    });
  }

  


}
    
    
  }


  lastItem(cat_id){
    if(cat_id === '5'){
      return(<View style={styles.sort_row_1}>
        <Text style={styles.title_txt}>Benefit:</Text>
        <View style={styles.select_continer_radio}>
        <View style={styles.radio_row}>
                <RadioForm
                    radioStyle={styles.radio_st}
                    radio_props={radio_benefit}
                    animation={false}
                    labelStyle={styles.radio_lbl_st}
                    buttonSize={hp('2.7%')}
                    buttonOuterSize={hp('4.2%')}
                    initial={0}
                    onPress={(value) => {this.setState({benefit_value:value})}}
                    />           
        </View>
                
                
            </View>                   
        </View>)
    }else if(cat_id === '6'){
      return(<View style={styles.sort_row_1}>
        <Text style={styles.title_txt}>Deductible:</Text>
        <View style={styles.select_continer_radio}>
        <View style={styles.radio_row}>
                <RadioForm
                    radioStyle={styles.radio_st}
                    radio_props={radio_deductible}
                    animation={false}
                    labelStyle={styles.radio_lbl_st}
                    buttonSize={hp('2.7%')}
                    buttonOuterSize={hp('4.2%')}
                    initial={0}
                    onPress={(value) => {this.setState({deductible_value:value})}}
                    />           
        </View>
                
                
            </View>                   
        </View>)
    }
    else{

      if(cat_id === '2' || cat_id === '4'){
      return(<View style={styles.sort_row_1}>
        <Text style={styles.title_txt}>Sum Insured:</Text>
        

            <View style={styles.select_continer_age}>

            <View style={styles.inputCon}>
                <Text style={styles.dollorTxt}>$</Text>
                <View style={styles.onTextVal}><Text style={styles.ttIn}>{this.state.sum_insured.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</Text></View>
                      <TextInput
                            style={[styles.inputCus,{width:wp('28%'),}]}
                            onChangeText={(sum_insured) => this.validate_sum_insured(sum_insured) }
                            keyboardType="numeric"
                            maxLength={8}
                            textAlign={'right'}
                            value={this.state.sum_insured.toString()}
                                        
                  />
            </View>

                      <View>
                        <Slider
                            style={{ width: '100%' }}
                            step={10000}
                            minimumValue={30000}
                            maximumValue={500000}
                            value={this.state.sum_insured}
                            onValueChange={val => this.setState({ sum_insured: val })}
                            thumbTintColor='#e842d6'
                            minimumTrackTintColor='#448aff'
                            />
                        </View> 
                
            </View>

            </View>)
      }else{
           return(
            <View style={styles.sort_row_1}>
            <Text style={styles.title_txt}>Annual Premium:</Text>
            

                <View style={styles.select_continer_age}>

                <View style={styles.inputCon}>
                    <Text style={styles.dollorTxt}>$</Text>
                    <View style={styles.onTextVal}><Text style={styles.ttIn}>{this.state.annual_premium.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</Text></View>
                          <TextInput
                                style={[styles.inputCus,{width:wp('28%'),}]}
                                onChangeText={(annual_premium) => this.validate_annual_pre(annual_premium)}
                                keyboardType="numeric"
                                maxLength={8}
                                textAlign={'right'}
                                
                                value={this.state.annual_premium.toString()}
                                //placeholder={this.state.annual_premium.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}
                      />
                     
                </View>

                          <View>
                            <Slider
                                style={{ width: '100%' }}
                                step={10000}
                                minimumValue={30000}
                                maximumValue={500000}
                                value={this.state.annual_premium}
                                onValueChange={val => this.setState({ annual_premium: val })}
                                //onSlidingComplete={ val => this.getVal(val)}
                                thumbTintColor='#e842d6'
                                minimumTrackTintColor='#448aff'
                                />
                            </View> 
                    
                </View>

                
            </View>
           )
      }
    }
            
       
    
  }


  validate_Age_cat_1(age){
    const cat_id_s = this.state.cat_id_s

      if(cat_id_s === '5' || cat_id_s === '6' || cat_id_s === '8'){
        if(age > 70){
          this.setState({age:age === "" ? 0 : parseInt(70) })
        }else{
          this.setState({age:age === "" ? 0 : parseInt(age) })
        }

      }else if(cat_id_s === '7'){
        if(age > 12){
          this.setState({age:age === "" ? 0 : parseInt(12) })
        }else{
          this.setState({age:age === "" ? 0 : parseInt(age) })
        }

      }else if( cat_id_s === '9' || cat_id_s === '10' || cat_id_s === '11' || cat_id_s === '12'){
        if(age > 50){
          this.setState({age:age === "" ? 0 : parseInt(50) })
        }else{
          this.setState({age:age === "" ? 0 : parseInt(age) })
        }

      }else{
        if(age > 65){
          this.setState({age:age === "" ? 0 : parseInt(65) })
        }else{
          this.setState({age:age === "" ? 0 : parseInt(age) })
        }
      }
    
        
    
  }


  validate_child_Age(age){
    const cat_id_s = this.state.cat_id_s

    if( cat_id_s === '9'){
        if(age > 12){
          this.setState({childAge:age === "" ? 0 : parseInt(12) })
        }else{
          this.setState({childAge:age === "" ? 0 : parseInt(age) })
        }

      }
     
  }


  validate_ret_Age(age){
    const cat_id_s = this.state.cat_id_s

    if( cat_id_s === '11'){
        if(age > 75){
          this.setState({retireAge:age === "" ? 0 : parseInt(75) })
        }else{
          this.setState({retireAge:age === "" ? 0 : parseInt(age) })
        }

      }
     
  }


  validate_annual_pre(annual_premium){
    if(annual_premium > 500000){
      this.setState({annual_premium:annual_premium === "" ? 0 : parseInt(500000) })
    }else{
      this.setState({annual_premium:annual_premium === "" ? 0 : parseInt(annual_premium) })
    }
    
  }


  validate_sum_insured(sum_insured){
    
    if(sum_insured > 500000){
      this.setState({sum_insured:sum_insured === "" ? 0 : parseInt(500000) })
    }else{
      this.setState({sum_insured:sum_insured === "" ? 0 : parseInt(sum_insured) })
    }
  }


  


  render() {
    const cat_id_s = this.state.cat_id_s

    if(cat_id_s === '1' || cat_id_s === '2' || cat_id_s === '3' || cat_id_s === '4' || cat_id_s === '5'|| cat_id_s === '6'){
    return (
   
       <View style={styles.container}>
        <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />

        <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>

                
                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Age:</Text>
                

                    <View style={styles.select_continer_age}>

                    <View style={styles.inputCon}>
                              <TextInput
                                    textAlign={'center'}
                                    style={styles.inputAge}
                                    onChangeText={(age) => this.validate_Age_cat_1(age)}
                                    keyboardType="numeric"
                                    maxLength={2}
                                    value={this.state.age.toString()}
                          />
                    </View>

                              <View>
                                <Slider
                                    style={{ width: '100%' }}
                                    step={5}
                                    minimumValue={0}
                                    maximumValue={cat_id_s === '5' || cat_id_s === '6' ? 70 : 65}
                                    value={this.state.age}
                                    onValueChange={val => this.setState({ age: val })}
                                    thumbTintColor='#e842d6'
                                    minimumTrackTintColor='#448aff'
                                    
                                    //onSlidingComplete={ val => this.getVal(val)}
                                    />
                                </View> 
                        
                    </View>

                    
                </View>

                
                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Gender:</Text>
                <View style={styles.select_continer_radio}>
                      
                        <View style={styles.radio_row}>
                        <RadioForm
                                labelStyle={styles.radio_lbl_st}
                                radioStyle={styles.radio_st}
                                radio_props={radio_props_gender}
                                animation={false}
                                buttonSize={hp('2.7%')}
                                buttonOuterSize={hp('4.2%')}
                                initial={0}
                                onPress={(value) => {this.setState({gender_value:value})}}
                                />           
                        </View>
                        
                    </View>                  
                </View>

                
                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Smoking Status:</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={radio_smk_stat}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({smk_value:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>



                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>{cat_id_s === '5' || cat_id_s === '6' ? 'Room Type:' : 'Payment Terms:'}</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.paym_tm_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>

                
               {this.lastItem(cat_id_s)}



            <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                <Text style={styles.btn_title}>COMPLETE</Text>
            </TouchableOpacity>

        </ScrollView>

        <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>

       </View>

     );
    }else if(cat_id_s === '9'){
      return(<View style={styles.container}>
        <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />

        <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>
                
                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Kind of wealth inherited :</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.grp2_cntry_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({grp2_s_value:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>

                
                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Current Age:</Text>
                

                    <View style={styles.select_continer_age}>

                    <View style={styles.inputCon}>
                              <TextInput
                                    textAlign={'center'}
                                    style={styles.inputAge}
                                    onChangeText={(age) => this.validate_Age_cat_1(age)}
                                    keyboardType="numeric"
                                    maxLength={2}
                                    value={this.state.age.toString()}
                          />
                    </View>

                              <View>
                                <Slider
                                    style={{ width: '100%' }}
                                    step={5}
                                    minimumValue={0}
                                    maximumValue={50}
                                    value={this.state.age}
                                    onValueChange={val => this.setState({ age: val })}
                                    thumbTintColor='#e842d6'
                                    minimumTrackTintColor='#448aff'
                                    
                                    //onSlidingComplete={ val => this.getVal(val)}
                                    />
                                </View> 
                        
                    </View>

                    
                </View>



                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>No of child:</Text>
                <View style={styles.select_continer_radio}>
                      
                        <View style={styles.radio_row}>
                        <RadioForm
                                labelStyle={styles.radio_lbl_st}
                                radioStyle={styles.radio_st}
                                radio_props={radio_props_no_of_child}
                                animation={false}
                                buttonSize={hp('2.7%')}
                                buttonOuterSize={hp('4.2%')}
                                initial={0}
                                onPress={(value) => {this.setState({no_child:value})}}
                                />           
                        </View>
                        
                    </View>                  
                </View>


                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Age of child:</Text>
                <View style={styles.select_continer_age}>
<View style={styles.inputCon}>
          <TextInput
                textAlign={'center'}
                style={styles.inputAge}
                onChangeText={(age) => this.validate_child_Age(age)}
                keyboardType="numeric"
                maxLength={2}
                value={this.state.childAge.toString()}
      />
</View>

          <View>
            <Slider
                style={{ width: '100%' }}
                step={1}
                minimumValue={0}
                maximumValue={12}
                value={this.state.childAge}
                onValueChange={val => this.setState({ childAge: val })}
                thumbTintColor='#e842d6'
                minimumTrackTintColor='#448aff'
                
                //onSlidingComplete={ val => this.getVal(val)}
                />
            </View> 
    
</View>
</View>





                <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Payment Terms:</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.paym_tm_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>

                
               {/* {this.lastItem(cat_id_s)} */}



            <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                <Text style={styles.btn_title}>COMPLETE</Text>
            </TouchableOpacity>

        </ScrollView>

        <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>

       </View>)
    } else if(cat_id_s === '11'){
        return(<View style={styles.container}>
          <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />
  
          <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>
                  
                  <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Country area for retirement :</Text>
                  <View style={styles.select_continer_radio}>
                  <View style={styles.radio_row}>
                          <RadioForm
                              radioStyle={styles.radio_st}
                              radio_props={this.state.grp2_cntry_arr}
                              animation={false}
                              labelStyle={styles.radio_lbl_st}
                              buttonSize={hp('2.7%')}
                              buttonOuterSize={hp('4.2%')}
                              initial={0}
                              onPress={(value) => {this.setState({grp2_s_value:value})}}
                              />           
                  </View>
                          
                          
                      </View>                   
                  </View>
  
                  
                  <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Current Age:</Text>
                  
  
                      <View style={styles.select_continer_age}>
  
                      <View style={styles.inputCon}>
                                <TextInput
                                      textAlign={'center'}
                                      style={styles.inputAge}
                                      onChangeText={(age) => this.validate_Age_cat_1(age)}
                                      keyboardType="numeric"
                                      maxLength={2}
                                      value={this.state.age.toString()}
                            />
                      </View>
  
                                <View>
                                  <Slider
                                      style={{ width: '100%' }}
                                      step={5}
                                      minimumValue={0}
                                      maximumValue={50}
                                      value={this.state.age}
                                      onValueChange={val => this.setState({ age: val })}
                                      thumbTintColor='#e842d6'
                                      minimumTrackTintColor='#448aff'
                                      
                                      //onSlidingComplete={ val => this.getVal(val)}
                                      />
                                  </View> 
                          
                      </View>
  
                      
                  </View>




                  <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Retirement Age:</Text>
                  
  
                      <View style={styles.select_continer_age}>
  
                      <View style={styles.inputCon}>
                                <TextInput
                                      textAlign={'center'}
                                      style={styles.inputAge}
                                      onChangeText={(age) => this.validate_ret_Age(age)}
                                      keyboardType="numeric"
                                      maxLength={2}
                                      value={this.state.retireAge.toString()}
                            />
                      </View>
  
                                <View>
                                  <Slider
                                      style={{ width: '100%' }}
                                      step={5}
                                      minimumValue={0}
                                      maximumValue={75}
                                      value={this.state.retireAge}
                                      onValueChange={val => this.setState({ retireAge: val })}
                                      thumbTintColor='#e842d6'
                                      minimumTrackTintColor='#448aff'
                                      
                                      //onSlidingComplete={ val => this.getVal(val)}
                                      />
                                  </View> 
                          
                      </View>
  
                      
                  </View>
  
  

  
                  <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Payment Terms:</Text>
                  <View style={styles.select_continer_radio}>
                  <View style={styles.radio_row}>
                          <RadioForm
                              radioStyle={styles.radio_st}
                              radio_props={this.state.paym_tm_arr}
                              animation={false}
                              labelStyle={styles.radio_lbl_st}
                              buttonSize={hp('2.7%')}
                              buttonOuterSize={hp('4.2%')}
                              initial={0}
                              onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                              />           
                  </View>
                          
                          
                      </View>                   
                  </View>
  
                  
                 {/* {this.lastItem(cat_id_s)} */}
  
  
  
              <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                  <Text style={styles.btn_title}>COMPLETE</Text>
              </TouchableOpacity>
  
          </ScrollView>

          <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>
  
         </View>)
    }else if(cat_id_s === '12'){
      return (
   
        <View style={styles.container}>
         <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />
 
         <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Age:</Text>
                 
 
                     <View style={styles.select_continer_age}>
 
                     <View style={styles.inputCon}>
                               <TextInput
                                     textAlign={'center'}
                                     style={styles.inputAge}
                                     onChangeText={(age) => this.validate_Age_cat_1(age)}
                                     keyboardType="numeric"
                                     maxLength={2}
                                     value={this.state.age.toString()}
                           />
                     </View>
 
                               <View>
                                 <Slider
                                     style={{ width: '100%' }}
                                     step={5}
                                     minimumValue={0}
                                     maximumValue={50}
                                     value={this.state.age}
                                     onValueChange={val => this.setState({ age: val })}
                                     thumbTintColor='#e842d6'
                                     minimumTrackTintColor='#448aff'
                                     
                                     //onSlidingComplete={ val => this.getVal(val)}
                                     />
                                 </View> 
                         
                     </View>
 
                     
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Gender:</Text>
                 <View style={styles.select_continer_radio}>
                       
                         <View style={styles.radio_row}>
                         <RadioForm
                                 labelStyle={styles.radio_lbl_st}
                                 radioStyle={styles.radio_st}
                                 radio_props={radio_props_gender}
                                 animation={false}
                                 buttonSize={hp('2.7%')}
                                 buttonOuterSize={hp('4.2%')}
                                 initial={0}
                                 onPress={(value) => {this.setState({gender_value:value})}}
                                 />           
                         </View>
                         
                     </View>                  
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Smoking Status:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={radio_smk_stat}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({smk_value:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>
 
 
 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Payment Terms:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={this.state.paym_tm_arr}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>
 
 
             <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                 <Text style={styles.btn_title}>COMPLETE</Text>
             </TouchableOpacity>
 
         </ScrollView>

         <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>
 
        </View>
 
      );
    }else if(cat_id_s === '10'){
      return (
   
        <View style={styles.container}>
         <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />
 
         <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>


         <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Type of liability :</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.grp2_cntry_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({grp2_s_value:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Age:</Text>
                 
 
                     <View style={styles.select_continer_age}>
 
                     <View style={styles.inputCon}>
                               <TextInput
                                     textAlign={'center'}
                                     style={styles.inputAge}
                                     onChangeText={(age) => this.validate_Age_cat_1(age)}
                                     keyboardType="numeric"
                                     maxLength={2}
                                     value={this.state.age.toString()}
                           />
                     </View>
 
                               <View>
                                 <Slider
                                     style={{ width: '100%' }}
                                     step={5}
                                     minimumValue={0}
                                     maximumValue={50}
                                     value={this.state.age}
                                     onValueChange={val => this.setState({ age: val })}
                                     thumbTintColor='#e842d6'
                                     minimumTrackTintColor='#448aff'
                                     
                                     //onSlidingComplete={ val => this.getVal(val)}
                                     />
                                 </View> 
                         
                     </View>
 
                     
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Gender:</Text>
                 <View style={styles.select_continer_radio}>
                       
                         <View style={styles.radio_row}>
                         <RadioForm
                                 labelStyle={styles.radio_lbl_st}
                                 radioStyle={styles.radio_st}
                                 radio_props={radio_props_gender}
                                 animation={false}
                                 buttonSize={hp('2.7%')}
                                 buttonOuterSize={hp('4.2%')}
                                 initial={0}
                                 onPress={(value) => {this.setState({gender_value:value})}}
                                 />           
                         </View>
                         
                     </View>                  
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Smoking Status:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={radio_smk_stat}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({smk_value:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>
 
 
 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Payment Terms:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={this.state.paym_tm_arr}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>
 
 
             <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                 <Text style={styles.btn_title}>COMPLETE</Text>
             </TouchableOpacity>
 
         </ScrollView>

         <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>
 
        </View>
 
      );
    }else if(cat_id_s === '7'){
      return (
   
        <View style={styles.container}>
         <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />
 
         <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>


         
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Age:</Text>
                 
 
                     <View style={styles.select_continer_age}>
 
                     <View style={styles.inputCon}>
                               <TextInput
                                     textAlign={'center'}
                                     style={styles.inputAge}
                                     onChangeText={(age) => this.validate_Age_cat_1(age)}
                                     keyboardType="numeric"
                                     maxLength={2}
                                     value={this.state.age.toString()}
                           />
                     </View>
 
                               <View>
                                 <Slider
                                     style={{ width: '100%' }}
                                     step={1}
                                     minimumValue={0}
                                     maximumValue={12}
                                     value={this.state.age}
                                     onValueChange={val => this.setState({ age: val })}
                                     thumbTintColor='#e842d6'
                                     minimumTrackTintColor='#448aff'
                                     
                                     //onSlidingComplete={ val => this.getVal(val)}
                                     />
                                 </View> 
                         
                     </View>
 
                     
                 </View>
 
 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Payment Terms:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={this.state.paym_tm_arr}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>



                 <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Country :</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.grp2_cntry_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({grp2_s_value:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>
 
 
             <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                 <Text style={styles.btn_title}>COMPLETE</Text>
             </TouchableOpacity>
 
         </ScrollView>

         <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>
 
        </View>
 
      );
    }else if(cat_id_s === '8'){
      return (
   
        <View style={styles.container}>
         <Header _this={this} header_title={"Home"} toggleDrawer={this.toggleDrawer} />
 
         <ScrollView style={{width:'100%',}} contentContainerStyle={styles.scroll_container}>


         <View style={styles.sort_row_1}>
                <Text style={styles.title_txt}>Type of hospital :</Text>
                <View style={styles.select_continer_radio}>
                <View style={styles.radio_row}>
                        <RadioForm
                            radioStyle={styles.radio_st}
                            radio_props={this.state.grp2_cntry_arr}
                            animation={false}
                            labelStyle={styles.radio_lbl_st}
                            buttonSize={hp('2.7%')}
                            buttonOuterSize={hp('4.2%')}
                            initial={0}
                            onPress={(value) => {this.setState({grp2_s_value:value})}}
                            />           
                </View>
                        
                        
                    </View>                   
                </View>



                <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Type of coverage with upper limit : </Text>
                  <View style={styles.select_continer_radio}>
                  <View style={styles.radio_row}>
                          <RadioForm
                              radioStyle={styles.radio_st}
                              radio_props={this.state.paym_tm_arr}
                              animation={false}
                              labelStyle={styles.radio_lbl_st}
                              buttonSize={hp('2.7%')}
                              buttonOuterSize={hp('4.2%')}
                              initial={0}
                              onPress={(value) => {this.setState({paym_tm_s_val:value})}}
                              />           
                  </View>
                          
                          
                      </View>                   
                  </View>




                <View style={styles.sort_row_1}>
                  <Text style={styles.title_txt}>Full coverage : </Text>
                  <View style={styles.select_continer_radio}>
                  <View style={styles.radio_row}>
                          <RadioForm
                              radioStyle={styles.radio_st}
                              radio_props={radio_deductible}
                              animation={false}
                              labelStyle={styles.radio_lbl_st}
                              buttonSize={hp('2.7%')}
                              buttonOuterSize={hp('4.2%')}
                              initial={0}
                              onPress={(value) => {this.setState({deductible_value:value})}}
                              />           
                  </View>
                          
                          
                      </View>                   
                  </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Age:</Text>
                 
 
                     <View style={styles.select_continer_age}>
 
                     <View style={styles.inputCon}>
                               <TextInput
                                     textAlign={'center'}
                                     style={styles.inputAge}
                                     onChangeText={(age) => this.validate_Age_cat_1(age)}
                                     keyboardType="numeric"
                                     maxLength={2}
                                     value={this.state.age.toString()}
                           />
                     </View>
 
                               <View>
                                 <Slider
                                     style={{ width: '100%' }}
                                     step={5}
                                     minimumValue={0}
                                     maximumValue={70}
                                     value={this.state.age}
                                     onValueChange={val => this.setState({ age: val })}
                                     thumbTintColor='#e842d6'
                                     minimumTrackTintColor='#448aff'
                                     
                                     //onSlidingComplete={ val => this.getVal(val)}
                                     />
                                 </View> 
                         
                     </View>
 
                     
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Gender:</Text>
                 <View style={styles.select_continer_radio}>
                       
                         <View style={styles.radio_row}>
                         <RadioForm
                                 labelStyle={styles.radio_lbl_st}
                                 radioStyle={styles.radio_st}
                                 radio_props={radio_props_gender}
                                 animation={false}
                                 buttonSize={hp('2.7%')}
                                 buttonOuterSize={hp('4.2%')}
                                 initial={0}
                                 onPress={(value) => {this.setState({gender_value:value})}}
                                 />           
                         </View>
                         
                     </View>                  
                 </View>
 
                 
                 <View style={styles.sort_row_1}>
                 <Text style={styles.title_txt}>Smoking Status:</Text>
                 <View style={styles.select_continer_radio}>
                 <View style={styles.radio_row}>
                         <RadioForm
                             radioStyle={styles.radio_st}
                             radio_props={radio_smk_stat}
                             animation={false}
                             labelStyle={styles.radio_lbl_st}
                             buttonSize={hp('2.7%')}
                             buttonOuterSize={hp('4.2%')}
                             initial={0}
                             onPress={(value) => {this.setState({smk_value:value})}}
                             />           
                 </View>
                         
                         
                     </View>                   
                 </View>
 
 
 
 
             <TouchableOpacity style={styles.submit_btn} onPress={()=> this.onSubmit()}>
                 <Text style={styles.btn_title}>COMPLETE</Text>
             </TouchableOpacity>
 
         </ScrollView>

         <Drawer _this={this} isOpen={this.state.isOpen} userName={''} ref={this.drawer}  screen={'buyer'} loginTXT={this.state.loginTXT}
          isLoggedIn={this.state.login_btn_active} loginType={this.state.loginType}/>
 
        </View>
 
      );
    }else{
      return(<View></View>)
    }
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    width:'100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fbfbfc',
  },
  main_cat_pad:{
    height:hp('10%'),
    width:wp('100%'),
    marginBottom: hp('5'),
    backgroundColor: '#ddd',

  },


  sort_row_1:{
    width:'85%',
    
    marginBottom:hp('1.7%')
},

sort_row_2:{
    width:'85%',
    height:hp('15%'),
    backgroundColor: '#ddd',
  marginBottom:hp('5%')
},

sort_row_3:{
    width:'85%',
    height:hp('15%'),
    backgroundColor: '#ddd',
  marginBottom:hp('5%')
},

sort_row_4:{
    width:'85%',
    height:hp('15%'),
    backgroundColor: '#ddd',
  marginBottom:hp('5%')
},

scroll_container:{
    paddingTop: hp('2%'),
    alignItems: 'center',
},

select_continer:{
    flex:1,
    flexDirection: 'row',
    width:'100%',
    height:hp('10%'),
    borderRadius: hp('2%'),
    backgroundColor: '#bbb',
},


select_continer_age:{
    width:'100%',
    height:hp('8%'),
    marginLeft: wp('1%'),
    borderRadius:hp('0.7%'),
    justifyContent: 'center',
    backgroundColor: '#e8e8e8',
},

inputCon:{
  flexDirection:'row',
  width:'100%',
  justifyContent: 'flex-end',
  paddingRight:wp('2')
},


select_continer_radio:{
    flex:1,
    width:'100%',
},

select_row1:{
    flex:1,
    paddingHorizontal: wp('5%'),
    justifyContent: 'center',
},

radio_row:{
    flex:1,
    justifyContent: 'center',
    paddingLeft: wp('1%'),
    
},

submit_btn:{
  height:hp('7.7%'),
  width:'95%',
  backgroundColor: '#505050',
  marginTop: hp('2.7%'),
  marginBottom:hp('1.3%'),
  borderRadius:hp('0.7%'),
  justifyContent: 'center',
  alignItems: 'center',
},

btn_title:{
  color:'#fff',
  fontSize:hp('2.7%'),
  marginTop:-hp('0.5%'),
  fontFamily:'seg_sem_light'
},

title_txt:{
  fontSize:hp('2.5%'),
  fontFamily: 'seg_sem_light',
  color:'#363636',
  marginBottom:hp('0.5%')
},

inputAge:{
  height: hp('3.5%'),
  width:wp('12%'),
  backgroundColor: '#fff', 
  borderColor: 'gray', 
  borderWidth: 0.5,
  paddingTop:0,
  paddingBottom: 0,
  fontSize:hp('2.5%'),
  color:'#e842d6',
  fontWeight: 'bold',
  alignItems:'center'
},

radio_st:{
  backgroundColor: '#ddd',
  marginBottom:hp('1.5%'),
  paddingLeft:wp('4%'),
  paddingVertical:hp('1.6%'),
  borderRadius:hp('0.7%'),
  backgroundColor: '#e8e8e8',

},

radio_lbl_st:{
  fontSize:hp('2.4%'),
  marginRight: wp('10%'),
  paddingTop:hp('0.5%'),
 fontFamily: 'seg_light',
  color:'#767676'
},

dollorTxt:{
  fontSize:hp('2.5%'),
  fontWeight:'bold',
  paddingRight:wp('1%')
},

onTextVal:{
  position: 'absolute',
  right:wp('2.6%'),
  height: hp('3.5%'),
  width:wp('27%'),
  backgroundColor: '#fff',
}
,
ttIn:{
  fontSize:hp('2.5%'),
  color:'#e842d6',
  fontWeight: 'bold',
  textAlign:'right'
},

inputCus:{
  height: hp('3.5%'),
  width:wp('12%'),
  backgroundColor: 'rgba(255, 255, 255, 0)', 
  borderColor: 'gray', 
  borderWidth: 0.5,
  paddingTop:0,
  paddingBottom: 0,
  fontSize:hp('2.5%'),
  color:'rgba(255, 255, 255, 0)',
  fontWeight: 'bold',
  alignItems:'center'
},

});