import * as React from 'react';
import { Text, View, StyleSheet,ScrollView,FlatList,Slider,processColor } from 'react-native';
import Modal from "react-native-modal";
import Header from '../header'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Multi_line_chart from '../charts/multi_line_chart'
import update from 'immutability-helper';
import Policy_slider from '../components/policy_slider'

export default class Product_compare extends React.Component {

    constructor(props) {

        super(props);
       
        
    
        this.state = {
          all_prod_data:[],
          policy_year:10,
          product_compare:false,
          refreshing:true,

          data:{
            $set: {
                  dataSets: [{
                    values: [{x: 4, y: 8}, {x: 5, y: 5}, {x: 6, y: 5}, {x: 7, y: 8}], label: 'A', config: { color: processColor('red'),drawFilled: true,fillColor: processColor('red'), },
                  }, {
                    values: [{x: 4, y: 105}, {x: 5, y: 90}, {x: 6, y: 130}, {x: 7, y: 100}], label: 'B',config: { color: processColor('blue'),drawFilled: true,fillColor: processColor('blue'), }
                  }, ],
                }
          }
        }
    
    }


    open=(prod_ids)=>{
        this.setState({ product_compare: true })
        this.fetch_prod_data(prod_ids)
  }
  
  close=()=>{
      this.setState({
        policy_year:10,
        product_compare: false
      })
  
       
  }


  th_sp(val){
    //separate number with comma
    try{
     return(val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
    }catch(e){
      return('')
    }
  }



  fetch_prod_data= async(prod_ids)=>{
   
    var prod_1 = prod_ids[0]
    var prod_2 = prod_ids[1]
    var prod_3 = prod_ids[2] 


    this.setState({refreshing:true})
    fetch(`http://192.168.9.103:80/garage/get_compare_prod_data.php?prod_id_1=${prod_1}&prod_id_2=${prod_2}&prod_id_3=${prod_3}`, {
      method: 'GET'
        })
        .then((response) => response.json())
        .then((responseJson) => {
              
        if(responseJson !== 'No'){
          this.setState({all_prod_data:responseJson,refreshing:false})
         // this.filter_data(10)
         this.set_chart_data(prod_ids)
        }else{
          this.setState({all_prod_data:[],refreshing:false}) 
        }
         
        })
        .catch((error) => {
          alert('Something went wrong please check your internet connection !')
            this.setState({refreshing:false})
        });

        
}


set_Policy=(val)=>{
  this.setState({policy_year:val})
}

filter_data=()=>{

}

set_chart_data =async (prod_ids) =>{
// alert(responseJson.length)

var chart_vals = await this.get_chart_values(prod_ids)
var prod_1_arr_irr = chart_vals[0]
var prod_2_arr_irr = chart_vals[1]
var prod_3_arr_irr = chart_vals[2]

//alert(JSON.stringify(prod_1_arr_irr))
 
      this.setState(
        update(this.state, {
          data: {
            $set: {
              dataSets: [
                    {
                    values: prod_1_arr_irr, label: 'Product 1 IRR', config: { color: processColor('red'),drawFilled: true,fillColor: processColor('red'),fillAlpha: 0, },
                  },
                  {
                    values: prod_2_arr_irr, label: 'Product 2 IRR',config: { color: processColor('blue'),drawFilled: true,fillColor: processColor('blue'),fillAlpha: 0, }
                                 },
                                 {
                                  values: prod_3_arr_irr, label: 'Product 3 IRR',config: { color: processColor('green'),drawFilled: true,fillColor: processColor('green'),fillAlpha: 0, }
                                         },  ],
            }
          }
        })
      ); 
}



get_chart_values = async (prod_ids) =>{
  var prod_1_arr_irr = []
  var prod_2_arr_irr = []
  var prod_3_arr_irr = []

  var prod_1 = prod_ids[2]
  var prod_2 = prod_ids[1]
  var prod_3 = prod_ids[0]

  var arr_length = 120
  var i;
  var a= 1;
  var b= 5;
       for(i=0; i < arr_length ; i++){
       var lbl_val = 5*a;
       var real_age = b;

       var arr_prod_1 = this.state.all_prod_data.filter(function(itemx){return itemx.age == real_age && itemx.product_id == prod_1;})
       var arr_prod_2 = this.state.all_prod_data.filter(function(itemx){return itemx.age == real_age && itemx.product_id == prod_2;})
       var arr_prod_3 = this.state.all_prod_data.filter(function(itemx){return itemx.age == real_age && itemx.product_id == prod_3;})

       if(arr_prod_1.length !== 0){
             const val_irr_1 = {x: real_age, y: parseFloat(arr_prod_1[0].irr_amt)}
             prod_1_arr_irr.push(val_irr_1)
       }else{}

       if(arr_prod_2.length !== 0){
        const val_irr_2 = {x: real_age, y: parseFloat(arr_prod_2[0].irr_amt)}
        prod_2_arr_irr.push(val_irr_2)
  }else{}

  if(arr_prod_3.length !== 0){
    const val_irr_3 = {x: real_age, y: parseFloat(arr_prod_3[0].irr_amt)}
    prod_3_arr_irr.push(val_irr_3)
}else{}
        a++
        b++
   }
   return [prod_1_arr_irr,prod_2_arr_irr,prod_3_arr_irr]
}



  titles_tab(){
      return(
        <View style={styles.row_main}>
        <View style={[styles.rows_body,{backgroundColor: '#5A5A5A',}]}>
            <Text style={styles.head_txt}>Feature</Text>
            </View>
          
            <View style={[styles.rows_body,{backgroundColor: '#FFAEAD',}]}>
            <Text style={styles.main_sub_txt}>Total Premium</Text>
            </View>

            <View style={[styles.rows_body,{backgroundColor: '#FFC1C2',}]}>
            <Text style={styles.main_sub_txt}>Guarantee Value</Text>
            <Text style={styles.main_sub_txt}>(A)</Text>
            </View>

            <View style={[styles.rows_body,{backgroundColor: '#FFAEAD',}]}>
            <Text style={styles.main_sub_txt}>Non-Guarantee Value</Text>
            <Text style={styles.main_sub_txt}>(B)</Text>
            </View>

            <View style={[styles.rows_body,{backgroundColor: '#FFC1C2',}]}>
            <Text style={styles.main_sub_txt}>Total Return</Text>
            <Text style={styles.main_sub_txt}>(A+B)</Text>
            <Text style={styles.main_sub_txt}>IRR</Text>
            </View>
    </View>
      )
  }


  render() {
    const policy_year = this.state.policy_year

    return (
        <Modal style = {{  margin: 0 }} isVisible={this.state.product_compare} 
        animationIn={'slideInRight'} animationOut={'slideOutLeft'} hasBackdrop={false} onRequestClose={()=>this.close()}>
            <Header screen={'prod_comp'} close={this.close}/>

            <View style={styles.container} >
          
                    <ScrollView style={{width:'100%'}}>


                    <Text style={styles.com_txt}>Compare</Text>

                    <View style={{width:'100%'}}>
                             
                    <FlatList 
                          
                          data={this.state.all_prod_data.filter(function(itemx){return itemx.policy_year == policy_year;})}

                          keyExtractor={(item, index) => item.word_id}

                          horizontal={true}
                        //ListEmptyComponent={this.emptymsgFun()}
                         ListHeaderComponent={this.titles_tab()}

                          renderItem={({ item, index }) =>

                                <View style={styles.row_main}>
                                    <View style={[styles.rows_body,{backgroundColor: '#D1D1D1',}]}>
                                     <Text style={styles.prod_title_txt} numberOfLines={3}>{item.p_name}</Text>
                                        </View>
                                      
                                        <View style={[styles.rows_body,{backgroundColor: '#E6E6E6',}]}>
                                        <Text style={styles.prod_value_txt} numberOfLines={3}>${this.th_sp(item.total_pre)}</Text>
                                        </View>

                                        <View style={[styles.rows_body,{backgroundColor: '#EDEDED',}]}>
                                        <Text style={styles.prod_value_txt} numberOfLines={3}>${this.th_sp(item.guaran_amt)}</Text>
                                        </View>

                                        <View style={[styles.rows_body,{backgroundColor: '#E6E6E6',}]}>
                                        <Text style={styles.prod_value_txt} numberOfLines={3}>${this.th_sp(item.nonguaran_amt)}</Text>
                                        </View>

                                        <View style={[styles.rows_body,{backgroundColor: '#EDEDED',}]}>
                                        <Text style={styles.prod_value_txt} numberOfLines={2}>${item.total_return}</Text>
                                        <Text style={[styles.prod_value_txt,{fontWeight:'bold'}]} numberOfLines={2}>5%</Text>
                                        <Text style={[styles.prod_value_txt,{fontWeight:'bold'}]} numberOfLines={2}>{item.irr_amt}%</Text>
                                        </View>
                                </View>

                        }
                        />


                    </View>   



                        <View style={styles.descrip}>
                        <View style={styles.des_row_1}>
                        <Text style={styles.com_btm_txt}>*%: Precentage of Total Premium</Text>
                        </View>

                        <View style={styles.des_row_2}>
                        <Text style={[styles.com_btm_txt,{textAlign:'right'}]}>Add remark</Text>
                        </View>
                        </View>
                    

                        <Policy_slider  
                        policy_year={this.state.policy_year} 
                        steps={5} 
                        minimumValue={10} 
                        maximumValue={85}
                        set_Policy={this.set_Policy}
                        filter_data={this.filter_data}/>


                        <View style={styles.chart_con}>
                        <Multi_line_chart  chart_data = {this.state.data} isRightYEnabled={false}/>         
                        </View>



                    </ScrollView>

            </View>
  
        </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#fbfbfc',
  },
  row_main: {
     flex:1,
    height:hp('50%'),
    width:wp('24%'),
    marginRight: wp('1%'),
    borderRadius: hp('2%'),
  
  },

  row_title_main:{
    height:hp('50%'),
    width:wp('24%'),
    marginRight: wp('1%'),
  },

  rows_body:{
      flex:0.2,
      justifyContent: 'center',
      alignItems: 'center',
      padding: hp('0.4%'),
  },

  com_txt:{
      fontSize:hp('4.5%'),
        fontFamily: 'seg_sem_light',
        marginLeft: wp('4%'),
        marginBottom: hp('0.5%'),
        marginTop: hp('1%'),
  },
  head_txt:{
      fontSize:hp('2.1%'),
      color:'#fff',
      fontWeight: 'bold',
  },

  main_sub_txt:{
fontSize:hp('1.7%'),
textAlign:'center',
fontWeight:'500'
  },

  prod_title_txt:{
    fontSize:hp('1.8%'),
    textAlign:'center',
    fontWeight:'500' 
  },

  prod_value_txt:{
    fontSize:hp('1.8%'),
    textAlign:'center',
  },

  descrip:{
    flexDirection:'row',
    width:'100%',
    marginTop:hp('0.3%')
  },

  des_row_1:{
    flex:0.7,
    paddingLeft: wp('2%'),
  },

  des_row_2:{
    flex:0.3,
    paddingRight: wp('2%'),
  },

  com_btm_txt:{
    fontSize:hp('2.5%'),
    fontFamily: 'seg_sem_light',
  },

  btm_m_row3:{
    height:hp('12%'),
    flexDirection:'row',
    marginVertical: hp('2%'),
  },

  btm_m_col:{
    flex:0.1
  },
  
  btm_m_col2:{
    flex:0.8,
    justifyContent: 'center',
    alignItems:'center'
   
  },
  
  btm_m_col:{
    flex:0.1
  },

  drag_txt:{
    color:'red',
    fontSize:hp('1.5%'),
    textAlign:'center'
  },

  policy_txt:{
      fontSize:hp('2%')
  },

  chart_con:{
      width:'100%',
      alignItems: 'center',
  }
});
