import React, { Component } from 'react';
import {Alert,StatusBar,StyleSheet, View, TextInput,Text, ScrollView,Image,Button, Animated,TouchableOpacity, Keyboard, KeyboardAvoidingView,Platform,Dimensions,ImageBackground,ActivityIndicator } from 'react-native';

import Icon from 'react-native-ionicons'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import { withNavigationFocus } from 'react-navigation';
import logo from '../../../src/img/logo.png';
import * as firebase from 'react-native-firebase';

import stringsoflanguages from '../../screen/lng/stringsoflanguages';

const window = Dimensions.get('window');

const IMAGE_HEIGHT = hp('22%');
const IMAGE_HEIGHT_SMALL = hp('10%');



 let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;


class Register extends Component {
  constructor(props) {
    super(props);

    this.imageHeight = new Animated.Value(IMAGE_HEIGHT);
    this.back_3Anim = new Animated.Value(-hp('25%'));

    this.state = { 
     
      errorMessage: null ,
      Fname:'',
      UserEmail: '',
      UserPassword: '',
      rePassword:'',
      phone:'',
      revmodal:false,
      acti:true,
      type:'customer',
      typeTXT:'Who Im I',
      error:null,
      loading:false,
      activeBTN:'1'

    }
  }

  static navigationOptions = {
     header: null
 
 };

  componentWillMount () {
   
    this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);
   
    setTimeout(() => {this.setState({revmodal:true})}, 200)
  }

  componentWillUnmount() {
    this.keyboardWillShowSub.remove();
    this.keyboardWillHideSub.remove();
  }



  componentWillReceiveProps(nextProps) {
    if(this.props.isFocused && nextProps.isFocused){
      //console.log('not running anything')
      
    }
    
    if(this.props.isFocused && !nextProps.isFocused){
     // console.log('ufocus')
     this.keyboardWillShowSub.remove();
     this.keyboardWillHideSub.remove();

    this.setState({
    Fname:'',
    UserEmail: '',
    UserPassword: '',
    phone:'',
    rePassword:'',})
    
    }
    
    if(!this.props.isFocused && nextProps.isFocused){
    //  console.log('focus')
    this.keyboardWillShowSub = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    this.keyboardWillHideSub = Keyboard.addListener('keyboardDidHide', this.keyboardDidHide);

    }
        
          
    
      }




  keyboardDidShow = (event) => {
    Animated.timing(this.imageHeight, {
      toValue: IMAGE_HEIGHT_SMALL,
    }).start();

    Animated.timing(this.back_3Anim, {
      toValue: -hp('30%'),
    }).start();

  };

  keyboardDidHide = (event) => {
    Animated.timing(this.imageHeight, {
      toValue: IMAGE_HEIGHT,
    }).start();


    Animated.timing(this.back_3Anim, {
      toValue: -hp('25%'),
    }).start();
  };



  componentDidMount(){
 
  }







  handleSignUp = () => {

    const { UserEmail, UserPassword } = this.state
    this.setState({
      loading:true
    });



    if(this.state.UserEmail === "" || this.state.UserPassword === "" || this.state.rePassword === ""){
      alert(stringsoflanguages.register.register_warn_1);
      this.setState({
          loading:false
        });

      }else if(reg.test(this.state.UserEmail) === false)
      {
      alert(stringsoflanguages.login.login_warn_2);
      this.setState({
          loading:false
        });
      //return false;
      }else if(this.state.UserPassword.length < 4){
      alert(stringsoflanguages.register.register_warn_3);
      this.setState({
          loading:false
        });
      }else if(this.state.UserPassword != this.state.rePassword){
      alert(stringsoflanguages.register.register_warn_4);
      this.setState({
          loading:false
        });
      }else if(this.state.phone.length < 10){
        alert(stringsoflanguages.register.register_warn_5);
        this.setState({
            loading:false
      });
      }else{
      Keyboard.dismiss()
  
          this.SignUp()
       

    }
 

  }



 SignUp = () => {

    const { UserEmail, UserPassword } = this.state

    firebase

      .auth()

      .createUserWithEmailAndPassword(UserEmail, UserPassword)

      .then(user => this.addUser())

      .catch(error => this.err(error))

  }

addUser(){
        const { currentUser } = firebase.auth()
        const { phone }  = this.state.phone ;
        var str = currentUser.email;

        var Fname  = str.replace(/@.*$/,"");

        firebase.database().ref('users/'+currentUser.uid).set({
          name: Fname,
          email:currentUser.email,
          phone:phone
        
      }).then((data)=>{
          //success callback
                  this.setState({loading:false})
                  this.props.navigation.navigate('FooterTab')

      }).catch((error)=>{
        this.err(error)
      })

}

err(error){
  this.setState({loading:false})
  alert(error)
}











   LL(){
     if(this.state.loading){
       return(<View style ={styles.Load} >

        <View style={styles.LoadSub}>
        <ActivityIndicator size="large"  color='#fff'/>
          </View>

     </View>)
     }else{
       return(<View />)
     }
   }


   accTypeBtn(val){

        if(val === 1){
            this.setState({activeBTN:'1'})
        }else{
          this.setState({activeBTN:'2'})
        }

   }


   ACTbtn1(){
     if(this.state.activeBTN === '1'){
       return(<Icon name ='ios-checkmark-circle' style={styles.iconStyType}/>)
     }else{
      return(<Icon name ='ios-checkmark-circle-outline' style={styles.iconStyType}/>)
     }
   }

   ACTbtn2(){
    if(this.state.activeBTN === '2'){
      return(<Icon name ='ios-checkmark-circle' style={styles.iconStyType}/>)
    }else{
     return(<Icon name ='ios-checkmark-circle-outline' style={styles.iconStyType}/>)
    }
  }


  BTMaccTypeMain(){
    if(this.state.type !== 'customer'){
      return( <View style={styles.btnView}>
        <TouchableOpacity style={styles.userCatView} onPress={()=>this.accTypeBtn(1)}>
         

            <View style={styles.row2}>
            <Text style={styles.accTXT}>{stringsoflanguages.register.register_accType_1}</Text>
            </View>

            <View style={styles.row3}>
            {this.ACTbtn1()}
            </View>
       

        </TouchableOpacity>


        <TouchableOpacity style={styles.userCatView2} onPress={()=>this.accTypeBtn(2)}>
         
          

            <View style={styles.row2}>
            <Text style={styles.accTXT}>{stringsoflanguages.register.register_accType_2}</Text>
            </View>

            <View style={styles.row3}>
            {this.ACTbtn2()}
            </View>

        </TouchableOpacity>

        </View>)
    }else{
      return(<View/>)
    }
  }



  render() {
    return (
      <ImageBackground style={{flex:1,backgroundColor: '#35eaa8',alignItems:'center'}} source={{ uri: `asset:/images/img_backgrounds/login_back.jpg`}}> 
       <View style={styles.main_container}>
    
       <View style={styles.tttop}>
      
       </View>


       <Animated.Image source={logo} style={[styles.logo, { height: this.imageHeight }]} />
       <ScrollView contentContainerStyle={{flexGrow:1,justifyContent: 'center',minHeight: hp('20%'),}}>
      
         <KeyboardAvoidingView
        style={styles.container}
        behavior="padding"
      >

     



           
        <View style={styles.container_pad}>

            <View style={styles.mainV}>
                  <View style={styles.iconV}>
                    <Image source={{ uri: `asset:/images/img_icons/ico_input_pers.png`}} style={styles.input_icon_St} />
                  </View>


                     <View style={styles.textV}>
                                 <TextInput
                                    placeholder={stringsoflanguages.register.register_input_2}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    autoCorrect={false}
                                    autoCapitalize="none"
                                    onChangeText={UserEmail => this.setState({UserEmail})}
                                />
                    </View>

              </View>



              <View style={styles.mainV}>
                  <View style={styles.iconV}>
                    <Image source={{ uri: `asset:/images/img_icons/ico_input_lock.png`}} style={styles.input_icon_St} />
                  </View>


                     <View style={styles.textV}>
                                 <TextInput
                                     placeholder={stringsoflanguages.register.register_input_3}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    autoCorrect={false}
                                    secureTextEntry={true}
                                    autoCapitalize="none"
                                    onChangeText={UserPassword => this.setState({UserPassword})}
                                />
                    </View>

              </View>




              <View style={styles.mainV}>
                  <View style={styles.iconV}>
                    <Image source={{ uri: `asset:/images/img_icons/ico_re_lock.png`}} style={[styles.input_icon_St,{height:hp('7%'), width:hp('7%'),}]} />
                  </View>


                     <View style={styles.textV}>
                                 <TextInput
                                    placeholder={stringsoflanguages.register.register_input_4}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    autoCorrect={false}
                                    secureTextEntry={true}
                                    autoCapitalize="none"
                                    onChangeText={rePassword => this.setState({rePassword})}
                                />
                    </View>

              </View>




              <View style={styles.mainV}>
                  <View style={styles.iconV}>
                    <Image source={{ uri: `asset:/images/img_icons/ico_phone.png`}} style={styles.input_icon_St} />
                  </View>


                     <View style={styles.textV}>
                                 <TextInput
                                    placeholder={stringsoflanguages.register.register_input_5}
                                    placeholderTextColor="#979797"
                                    style={styles.input}
                                    keyboardType="numeric"
                                    maxLength={15}
                                    autoCorrect={false}
                                    autoCapitalize="none"
                                    onChangeText={phone => this.setState({phone})}
                                />
                    </View>

              </View>


              <TouchableOpacity style={styles.register}  onPress= {() => this.handleSignUp()}>
                <Text style={styles.btnFont}
              >{stringsoflanguages.register.register_btn_1}</Text>
              </TouchableOpacity>


        </View>





      </KeyboardAvoidingView>
                    <View style={styles.footer_logo}>
                    {/* <Image source={{ uri: `asset:/images/img_icons/logo.png`}} style={styles.footer_img} /> */}
                    </View>
      </ScrollView>

      



      </View>
            

              
                    <TouchableOpacity style={styles.backbtn} >
                    <Image source={{ uri: `asset:/images/img_icons/ico_go_back.png`}} style={styles.back_icon_St} />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.sign_up_con}  onPress= {() => this.props.navigation.navigate('Login')}>
                    <Text style={styles.sign_st}>Login</Text>
                    </TouchableOpacity>   
                   
                     {this.LL()}


      </ImageBackground>
    );
  }
};


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: wp('100%'),
      },

      main_container:{
        flex:1,
        alignItems:'center',
        backgroundColor: 'rgba(255, 255, 255, 0.90)',
      },


      container_pad: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        width: '85%',
      },


      input: {
        height: hp('8%'),
        width:'90%',
        paddingBottom: 0,
        paddingLeft: wp('5%'),
        fontSize:hp('3.3%'),
        fontFamily: 'seg_light',
        color:'#383838',

      },



      logo: {
        height: IMAGE_HEIGHT,
        resizeMode: 'contain',
        marginTop:hp('10%'),
        marginBottom:hp('1%'),
        borderRadius: hp('2%'),
      },

      registerMain:{ 
        flexDirection: 'row',
        width:window.width,
        paddingHorizontal: wp('1%'),
      },



      register:{
        marginTop:hp('5%'),
        marginBottom:hp('8%'),
        width:'100%',
        alignItems:'center',
        justifyContent:'center',
        borderRadius:hp('3.25%'),
        height:hp('6%'),
        backgroundColor: '#7b7b7b',
      },



        mainV:{
          flex:0.2,
          flexDirection:'row',
          width:'100%',
          marginBottom: hp('1.2%'),
          borderBottomWidth: 1,
          borderColor: '#cccccc',
        },

        iconV:{
            flex:0.2,
            justifyContent: 'flex-end',
            alignItems: 'center',
        },

        input_icon_St:{
          height:hp('6%'),
          width:hp('6%'),
          opacity:0.8
        },


        textV:{
            flex:0.8,
            justifyContent: 'flex-end',
        },

        textV2:{
          height: hp('8%'),
          width:'90%',
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius:hp('4%'),
          backgroundColor:'rgba(249, 249, 249, 0.60)'
      },


        iconSty:{
            color:'#fff'
        }
  ,

  tttop:{
    position:'absolute',
 top:-window.height/2.5
  },


  Load:{
    position:'absolute',
  },

  LoadSub:{
    height:hp('100%'),
    width:window.width,
    backgroundColor:'rgba(0, 0, 0, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',

  },


  btnFont:{
    color:'#fff',
    fontFamily: 'seg_sem_light',
    fontSize: hp('2.5%'),
    paddingBottom:hp('0.5%')
  },


  backbtn:{
    position:'absolute',
    left:-wp('2%'),
    padding:hp('1%')
  },


  back_icon_St:{
    height:hp('11%'),
    width:hp('11%')
  },


  sign_up_con:{
    position:'absolute',
    right:wp('5%'),
    top:'2.5%',
  },

  sign_st:{
    fontSize:hp('4.3%'),
    fontFamily: 'seg_light',
    color:'#8e8f8f'
  },

  backbtnIco:{
    fontSize:hp('8%'),
    color:'#fff'
  },

  back_3Pad:{
    position:'absolute',
    left:-wp('10%')
    
  },
  back_3:{
    height:hp('50%'),
    width:wp('50%'),
    resizeMode: 'contain',
  },

  txtType:{
    color:'#565656',
    fontWeight: 'bold',
    fontSize:hp('2%')
  },
  userCatView:{
    flexDirection:'row',
    height:hp('8%'),
    width:wp('40%'),
    borderRadius:hp('2%'),
    // borderTopLeftRadius:hp('5%'),
    // borderBottomRightRadius:hp('5%'),
    backgroundColor: '#6bea94',
   //opacity:0.8,
    marginBottom:hp('3%'),
    borderWidth:2,
    borderColor:'#fff',
    marginRight: wp('2%'),
  },

  userCatView2:{
    flexDirection:'row',
    height:hp('8%'),
    borderRadius:hp('2%'),
    width:wp('40%'),
    //opacity:0.8,
    // borderTopLeftRadius:hp('5%'),
    // borderBottomRightRadius:hp('5%'),
    backgroundColor: '#ff9077',
    marginBottom:hp('3%'),
    borderWidth:2,
    borderColor:'#fff',
    marginLeft: wp('2%'),
  },

  row1:{
    height:'100%',
    width:'20%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  row2:{
    height:'100%',
    width:'75%',
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingRight: wp('1%'),
  },

  row3:{
    height:'100%',
    width:'25%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  accTXT:{
    fontSize:hp('2%'),
    color:'#fff',
    fontFamily: 'ERASDEMI',
  },

  iconStyType:{
    fontSize:hp('4%'),
    color:'#fff'
  },

  iconSty2:{
    fontSize:hp('3%'),
    color:'#fff'
  },

  btnView:{
    marginTop: hp('2%'),
    flexDirection:'row'
  },


  footer_logo:{
    position:'absolute',
    bottom:0,
    right:'3%'
  },

  footer_img:{
    height:hp('6%'),
    width:hp('18%'),
  }


  });

  

  export default withNavigationFocus(Register);