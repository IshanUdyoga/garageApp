import React, { Component } from 'react';
import {
  Platform,
  StyleSheet,
  Text,
  View,
  Dimensions,
  TouchableOpacity,
  Picker
} from 'react-native';
import Icon from 'react-native-ionicons'
import { withNavigation, DrawerActions } from 'react-navigation'
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Image from 'react-native-scalable-image';

export default class Header extends Component {

  constructor(props) {
    super(props);
 
    this.state = {
      tab1Color:'#fff',
      tab2Color:'rgba(225, 136, 136, 0)',
    };
  }
 


  onSelectDrop(val){
    this.props.sortFunc(val)
  }
  


headerTypes(){
  const screen_type = this.props.screen;
  if(this.props.screen === 'prod_list'){
return(<View style={styles.headerContainerLong}>
<View style={styles.header_row_1} >
  <View style={styles.row1_col1}>
  <TouchableOpacity  onPress={()=> this.props.toggleDrawer()}>
      <Image source={{ uri: `asset:/images/img_icons/menu_white.png`}} style={styles.menu_icon_St} height={hp('4%')} />
    </TouchableOpacity>
  </View>

  <View style={styles.row1_col2}>
  <View style={styles.tabContainer}>
      <TouchableOpacity style={[styles.tabs1,{backgroundColor: this.state.tab1Color,}]} onPress={()=>this.headerTabs(1)}>
            <Text style={[styles.tabTitle,{color:this.state.tab1Color === '#fff' ? '#1caf4d' : '#fff'}]}>All</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.tabs2,{backgroundColor: this.state.tab2Color,}]} onPress={()=>this.headerTabs(2)}>
            <Text style={[styles.tabTitle,{color:this.state.tab2Color === '#fff' ? '#1caf4d' : '#fff'}]}>Company</Text>
      </TouchableOpacity>

        </View>
  </View>

  <View style={styles.row1_col3}>
  <Image source={{ uri: `asset:/images/img_icons/ico_filter.png`}} style={styles.menu_icon_St2} height={hp('5%')} />
  </View>
</View>

<View style={styles.header_row_2} >
    <View style={styles.row2_col1}>
      <Image source={{ uri: `asset:/images/img_icons/icon_sort.png`}} style={styles.menu_icon_St3} height={hp('5%')} />
      <Text style={styles.sortTxt}>Sort By</Text>
    </View>

    <View style={styles.row2_col2} >
          <View style={styles.selectSort}>
                <View style={styles.selectRow1}>
                
                 {this.dropDownItem()}
                
                </View>

                <View style={styles.selectRow2}>
                    <Icon name='ios-play' style={styles.iconSelect}/>
                </View>
          </View>

    </View>
</View>


</View>)
  }else if(screen_type ==='prod_comp'){

        return(<View style={styles.headerContainer}>
    
        <TouchableOpacity style={styles.row1} onPress={()=> this.props.close()}>
          <Icon name='ios-arrow-back' style={styles.icon_style} />
        </TouchableOpacity>
     

        <View style={styles.row2}>
            <Image source={{ uri: `asset:/images/img_icons/logo.png`}}  height={hp('7.5%')} />
        </View>

        <View style={styles.row3} >
       </View></View>)

  }else{
    return(<View style={styles.headerContainer}>
    
    <TouchableOpacity style={styles.row1} onPress={()=> this.props.toggleDrawer()}>
        {/* <Icon name = 'ios-menu' style={styles.Icon_style} /> */}
        <Image source={{ uri: `asset:/images/img_icons/menu.png`}} style={styles.menu_icon_St} height={hp('5%')} />

    </TouchableOpacity>

    <View style={styles.row2}>
        <Image source={{ uri: `asset:/images/img_icons/logo.png`}}  height={hp('7.5%')} />
    </View>

    <TouchableOpacity style={styles.row3} >
    <Image source={{ uri: `asset:/images/img_icons/search.png`}} style={styles.search_St} height={hp('6%')} />
    </TouchableOpacity></View>)
  }
}


dropDownItem(){
 const cat_id = this.props.cat_id
  if(cat_id === '1' || cat_id === '7' || cat_id === '9'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
                 selectedValue = {this.props.sortVal}
                 onValueChange ={(value) => {this.onSelectDrop(value)}} >
                  <Picker.Item label = "None" value = "1" />
                  <Picker.Item label = "Total Return @15th year" value = "2" />
                  <Picker.Item label = "Total Return @20th year" value = "3" />
                  <Picker.Item label = "Total Return @25th year" value = "4" />
                  <Picker.Item label = "Total Return @30th year" value = "5" />
                  <Picker.Item label = "Break-even" value = "6" />
      </Picker>
                 
    )
  }else if(cat_id === '2' || cat_id === '10'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
                 selectedValue = {this.props.sortVal}
                 onValueChange ={(value) => {this.onSelectDrop(value)}} >
                  <Picker.Item label = "None" value = "1" />
                  <Picker.Item label = "Annual Premium " value = "2" />
                  <Picker.Item label = "TR of Cash Value @20 year" value = "3" />
                  <Picker.Item label = "TR of Death Benefits @10 year" value = "4" />
                  <Picker.Item label = "TR of Death Benefits @20 year" value = "5" />
      </Picker>
                 
    )
  }else if(cat_id === '3' || cat_id === '11'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
                 selectedValue = {this.props.sortVal}
                 onValueChange ={(value) => {this.onSelectDrop(value)}} >
                  <Picker.Item label = "None" value = "1" />
                  <Picker.Item label = "Total Income" value = "2" />
                  <Picker.Item label = "Total Return @65 age" value = "3" />
                  <Picker.Item label = "Total Return @85 age" value = "4" />
      </Picker>
                 
    )
  }else if(cat_id === '4' || cat_id === '12'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
      selectedValue = {this.props.sortVal}
      onValueChange ={(value) => {this.onSelectDrop(value)}} >
       <Picker.Item label = "None" value = "1" />
       <Picker.Item label = "Annual Premium " value = "2" />
       <Picker.Item label = "TR of Cash Value @25 year" value = "3" />
       <Picker.Item label = "TR of Major Benefits @10 year" value = "4" />
       <Picker.Item label = "TR of Major Benefits @15 year" value = "5" />
</Picker>
                 
    )
  }else if(cat_id === '5' || cat_id === '8'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
      selectedValue = {this.props.sortVal}
      onValueChange ={(value) => {this.onSelectDrop(value)}} >
       <Picker.Item label = "None" value = "1" />
       <Picker.Item label = "Annual Premium" value = "2" />
       <Picker.Item label = "Surgery Benefit" value = "3" />
       <Picker.Item label = "Maximum Annual Limit" value = "4" />
</Picker>
                 
    )
  }else if(cat_id === '6'){
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
      selectedValue = {this.props.sortVal}
      onValueChange ={(value) => {this.onSelectDrop(value)}} >
       <Picker.Item label = "None" value = "1" />
       <Picker.Item label = "Annual Premium" value = "2" />
       <Picker.Item label = "Lifetime Limit" value = "3" />
       <Picker.Item label = "Maximum Annual Limit" value = "4" />
</Picker>
                 
    )
  }else{
    return(
      <Picker style={{flex:1,backgroundColor: '#f0f0f0'}} mode='dropdown' 
                 selectedValue = {this.props.sortVal}
                 onValueChange ={(value) => {this.onSelectDrop(value)}} >
                  <Picker.Item label = "None" value = "1" />
      </Picker>
                 
    )
  }
}


headerTabs(val){
  if(val == 1){
    this.setState({tab1Color:'#fff',tab2Color:'rgba(225, 136, 136, 0)'})
    this.props._this.setState({header_tab_val:'all'})
}else{
  this.setState({tab1Color:'rgba(225, 136, 136, 0)',tab2Color:'#fff'})
  this.props._this.setState({header_tab_val:'company'})
  }
}


  render() {
    return (
      <View style={[styles.container,{height: this.props.screen === 'prod_list' ? hp('16%') : hp('10%'),backgroundColor: '#fbfbfc', }]}>
                
        {this.headerTypes()}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    
    height:hp('9%'),
    width:'100%',
   // backgroundColor: '#fbfbfc',
    
  },

headerContainer:{
  flexDirection: 'row',
height:'100%',
width:'100%',
alignItems: 'center',
justifyContent: 'center' ,

},

headerContainerLong:{
flex:1,
width:'100%',
alignItems: 'center',
justifyContent: 'center' ,
backgroundColor: '#2cba5b',
paddingTop: hp('2%'),
},



  header_txt_style:{
        fontSize:hp('3%'),
        color:'#000',
  },
  row1:{
    flex:0.2,
    height:'100%',
    justifyContent: 'center',
  },
  row2:{
    flex:0.6,
    height:'100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  row3:{
    flex:0.2,
    height:'100%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  Icon_style:{
    fontSize:hp('6%'),
    color:'#000',
    paddingLeft:wp('3%')
  },

  header_row_1:{
  flex:0.55,
  flexDirection:'row',
  width:'100%',
  },


  header_row_2:{
    flex:0.45,
    flexDirection:'row',
    width:'100%',
    marginBottom: hp('1%'),
  
    },

  row1_col1:{
    flex:0.17,
  },

  row1_col2:{
    flex:0.699,
  },

  row1_col3:{
    flex:0.13,
    alignItems: 'center',

  },

  tabContainer:{
    flexDirection:'row',
    width:'100%',
    height:'60%',
    paddingHorizontal: wp('2%'),
  },
  tabs1:{
    flex:0.5,
    borderWidth: 1,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems:'center',
    borderBottomLeftRadius: hp('0.8%'),
    borderTopLeftRadius: hp('0.8%'),
    
  },

  tabs2:{
    flex:0.5,
    borderWidth: 1,
    borderColor: '#fff',
    justifyContent: 'center',
    alignItems:'center',
    borderBottomRightRadius: hp('0.8%'),
    borderTopRightRadius: hp('0.8%'),
    
  },


  tabTitle:{
    fontSize:hp('2.4%'),
    fontFamily: 'seg_sem_light',
    marginTop: -hp('0.5%'),
  },

  row2_col1:{
    flex:0.3,
    flexDirection:'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  row2_col2:{
    flex:0.7,
  },

  selectSort:{
    flexDirection:'row',
    width:'90%',
    height:'90%',
    borderRadius: hp('0.5%'),
    backgroundColor:'#f0f0f0'
  },

  selectRow1:{
    flex:0.85
  },

  selectRow2:{
    flex:0.15,
    justifyContent: 'center',
    alignItems:'center',
  },

  iconSelect:{
    color:'#939393',
    fontSize:hp('3.5%'),
    transform: [{ rotate: '90deg'}]
  },

  sortTxt:{
    color:'#fff',
    fontSize:hp('2.5%'),
    fontFamily: 'seg_light',
    marginRight:wp('2%'),
    marginTop:-hp('0.7')
  },

  menu_icon_St:{
    marginLeft:wp('4%')
  },

  menu_icon_St2:{
  },

  menu_icon_St3:{
    marginLeft:wp('1%')
  },
  search_St:{
    marginLeft:wp('2%')
  },

  icon_style:{
    color:'#666',
    fontSize:hp('5%'),
    paddingLeft:wp('4%')
  },

});