
import React, {Component} from 'react';
import {Dimensions,AsyncStorage,ActivityIndicator,Easing,Animated,Platform, StyleSheet, Text, View,TouchableOpacity,ImageBackground,StatusBar,Image} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import { withNavigationFocus } from 'react-navigation';
import LangSelect from '../main/langSelectModal';

import * as firebase from 'react-native-firebase';

let deviceH = Dimensions.get('screen').height;
let windowH = Dimensions.get('window').height;
let bottomNavBarH = deviceH - windowH;


 class Loading extends React.Component {


    static navigationOptions = {
         header: null
     
     };

     state = {
    
      LangSelect:false

    }


    componentDidMount() {
setTimeout(() => {this.Splash()}, 8000)

    
        }




        Splash =()=>{
         


          firebase.auth().onAuthStateChanged(user => {

            this.props.navigation.navigate(user ? 'FooterTab' : 'Login')
      
          })
                                  

          }









  componentWillReceiveProps(nextProps) {
if(this.props.isFocused && nextProps.isFocused){
  //console.log('not running anything')
  
}

if(this.props.isFocused && !nextProps.isFocused){
 // console.log('ufocus')


}

if(!this.props.isFocused && nextProps.isFocused){
//  console.log('focus')
}
    
      

  }





  render() {
    return (
      <View style={styles.container}>
      <StatusBar
     backgroundColor="rgba(63, 191, 123, 0)"
     barStyle="light-content"
     translucent={true}
   />
 
          <View >
                      <Text >Loading...</Text>
                      <ActivityIndicator size="small" color="#fff" />
          </View>


          <LangSelect visible={this.state.LangSelect} _this ={this} Splash={this.Splash} screen={"loading"}/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1ebab9',
  },
  



});


export default withNavigationFocus(Loading);