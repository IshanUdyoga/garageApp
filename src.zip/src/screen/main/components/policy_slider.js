import * as React from 'react';
import { Text, View, StyleSheet,Slider,TouchableOpacity } from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import Icon from 'react-native-ionicons'

export default class Policy_slider extends React.Component {


slider_btn(val){
        if(val === '+'){
            if(this.props.policy_year < this.props.maximumValue){
                this.props.set_Policy(this.props.policy_year + this.props.steps)
                this.props.filter_data(this.props.policy_year + this.props.steps)
            }
        }else{
            if(this.props.policy_year > this.props.minimumValue){
                this.props.set_Policy(this.props.policy_year - this.props.steps)
                this.props.filter_data(this.props.policy_year - this.props.steps)
            }
        }
    
}

  render() {
    return (
          <View style={styles.btm_m_row3}>
                                      <TouchableOpacity style={styles.btm_m_col} onPress={()=> this.slider_btn('-')}>
                                      <Icon name='ios-remove' style={styles.icoSt} />
                                      </TouchableOpacity>

                                      <View style={styles.btm_m_col2}>
                                      <Text style={styles.policy_txt}>At the {this.props.policy_year}th Policy Year</Text>
                                          <Slider
                                              style={{ width: '100%' }}
                                              step={this.props.steps}
                                              minimumValue={this.props.minimumValue}
                                              maximumValue={this.props.maximumValue}
                                              value={this.props.policy_year}
                                              onValueChange={val => this.props.set_Policy(val)}
                                              onSlidingComplete={ val => this.props.filter_data(val)}
                                              />   

                                              <Text style={styles.drag_txt} numberOfLines={2} >Drag the button to review the performance at different policy year</Text>        
                                      </View>

                                      <TouchableOpacity style={styles.btm_m_col} onPress={()=> this.slider_btn('+')}>
                                      <Icon name='ios-add' style={styles.icoSt} />
                                      </TouchableOpacity>
            </View>
    );
  }
}

const styles = StyleSheet.create({

    btm_m_row3:{
        height:hp('12%'),
        flexDirection:'row',
        marginVertical: hp('2%'),
      },
      btm_m_col:{
        flex:0.1,
        justifyContent: 'center',
        alignItems: 'center',
      },
      btm_m_col2:{
        flex:0.8,
        justifyContent: 'center',
        alignItems:'center'
       
      },
      drag_txt:{
        color:'red',
        fontSize:hp('1.5%'),
        textAlign:'center'
      },

      icoSt:{
          fontSize:hp('4%'),
          color:'#f442a1'
      },

      policy_txt:{
        fontSize:hp('2%'),
      }
 
});
