import * as React from 'react';
import {Modal,StatusBar, Text, View, StyleSheet,Dimensions,TouchableOpacity,Image,AsyncStorage,ScrollView,FlatList,ImageBackground,TextInput,Keyboard,LayoutAnimation,UIManager } from 'react-native';
import RNRestart from 'react-native-restart';
import stringsoflanguages from '../lng/stringsoflanguages';

import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';


let deviceHeight = Dimensions.get('window').height
let deviceWidth = Dimensions.get('window').width



export default class LangSelect extends React.Component {

  constructor(props) {

    super(props);
    const lang = [
      { shortform: 'en', longform: 'English' },
      { shortform: 'tc', longform: '中文 (Traditional)' },
      { shortform: 'sc', longform: '中文 (Simplified)' },
    ];
    global.lang = lang;




            }


    componentDidMount () {


    }

  componentWillMount(){
 
  }




close(){
    this.props._this.setState({ LangSelect: false })
    
}


settext(value) {
  if(this.props.screen === "loading"){
    stringsoflanguages.setLanguage(value);
    this.props._this.setState({ LangSelect: false })
    AsyncStorage.setItem('isLangSelected', value)
    this.props.Splash()
  }else{
    AsyncStorage.setItem('isLangSelected', value).then((value) => {
      this.props._this.setState({ LangSelect: false })
      setTimeout(() => { RNRestart.Restart()}, 500)
     
    })
  }
  
}


  render() {
    return (
        <Modal visible={this.props.visible} animationType={'slide'}   >
         
        <View style={styles.container} >
        <StatusBar
     backgroundColor="#fff"
     barStyle="light-content"
     translucent={false}
   />

        <View style={{ marginTop: hp('9%') }}>
          <Text style={styles.textHeading}>
            Please Select Preferred
          </Text>
          <Text style={styles.textHeading}>
          Language
          </Text>
        </View>
        <Image
          source={{
            uri:
              'https://aboutreact.com/wp-content/uploads/2018/09/language.png',
          }}
          style={styles.img}
        />
        <ScrollView style={{ marginTop: hp('4.5%'), width: '80%' }}>
          {global.lang.map((item, key) => (
            <View style={styles.elementContainer}>
              <Text
                ref={item.shortform}
                onPress={() => this.settext(item.shortform)}
                style={styles.text}>
                {item.longform}
              </Text>
              <View style={styles.saparator} />
            </View>
          ))}
        </ScrollView>

          

        </View>
      
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems:'center',
    
  },

  textHeading: { 
      color: '#7a7a7a',
      fontFamily: 'ERASDEMI',
   fontSize: hp('4.5%'), 
   textAlign: 'center' 
},

  img: { 
    width: hp('10%'), 
    height: hp('10%'), 
    marginTop: hp('4.5%')
},

  elementContainer: {
    width: '100%',
    marginTop: hp('4.5%'),
    alignItems: 'center',
  },

  text: 
  { 
    color: '#7a7a7a',
  fontSize: hp('3.5%') ,
  fontFamily: 'ERASDEMI',
},

  saparator: {
    height: 0.5,
    width: '60%',
    backgroundColor: '#C2C2C2',
    marginTop: hp('1.7%'),
  },

});
