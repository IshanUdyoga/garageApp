import React from 'react';
import {
  StyleSheet,
  TextInput,
  View
} from 'react-native';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import RNSpeedometer from 'react-native-speedometer'




export default class Meter_chart extends React.Component {
  state = {
    value: 20,
    labels : [
        {
          name: 'lOW',
          labelColor: '#14eb6e',
          activeBarColor: '#14eb6e',
        },
        {
          name: 'lOW',
          labelColor: '#00ff6b',
          activeBarColor: '#00ff6b',
        },
        {
          name: 'NORMAL',
          labelColor: '#f2cf1f',
          activeBarColor: '#f2cf1f',
        },
        {
          name: 'NORMAL',
          labelColor: '#f4ab44',
          activeBarColor: '#f4ab44',
        },
        {
          name: 'HIGH',
          labelColor: '#ff5400',
      activeBarColor: '#ff5400',
        },
        {
          name: 'HIGH',
          labelColor: '#ff2900',
      activeBarColor: '#ff2900',
        },
      ]
  };

  onChange = (value) => this.setState({ value: parseInt(value) });

  render() {
     return (
        <View style={styles.container}>
          <RNSpeedometer value={this.props.meter_val} size={hp('34%')} labels={this.state.labels}/>
        </View>
      );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height:hp('25%'),
marginTop: hp('5%'),
  },
});